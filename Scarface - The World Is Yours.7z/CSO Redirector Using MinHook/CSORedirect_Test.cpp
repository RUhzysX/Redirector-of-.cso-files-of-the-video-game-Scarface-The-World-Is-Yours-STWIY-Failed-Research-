/* ============================================================================
 * CSORedirect_Test.cpp
 * MINIMAL VERSION - Just to test if ASI loads!
 * ============================================================================
 */

#include <windows.h>
#include <stdio.h>

/* ========================================================================== */
/* TEST 1: DllMain with immediate log */
/* ========================================================================== */

BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason, LPVOID lpReserved)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hModule);
        
        // IMMEDIATE TEST - Write file from DllMain
        FILE* f = fopen("DLLMAIN_CALLED.txt", "w");
        if (f)
        {
            fprintf(f, "DllMain was called!\n");
            fprintf(f, "If you see this, the DLL is loading!\n");
            fclose(f);
        }
        
        // Also try message box
        MessageBoxA(NULL, 
            "DllMain called!\n\nIf you see this, the DLL loads!",
            "CSORedirect Test", 
            MB_OK | MB_ICONINFORMATION);
    }
    
    return TRUE;
}

/* ========================================================================== */
/* TEST 2: InitializeASI export */
/* ========================================================================== */

extern "C" __declspec(dllexport) void InitializeASI()
{
    // Write file from InitializeASI
    FILE* f = fopen("INITIALIZEASAI_CALLED.txt", "w");
    if (f)
    {
        fprintf(f, "InitializeASI was called!\n");
        fprintf(f, "This means ASI Loader is working!\n");
        fclose(f);
    }
    
    // Message box
    MessageBoxA(NULL,
        "InitializeASI called!\n\nASI Loader is working!",
        "CSORedirect Test - Success!",
        MB_OK | MB_ICONINFORMATION);
    
    // Also create the log file
    FILE* log = fopen("CSORedirect.log", "w");
    if (log)
    {
        fprintf(log, "========================================\n");
        fprintf(log, "CSORedirect Test Version\n");
        fprintf(log, "========================================\n\n");
        fprintf(log, "InitializeASI was called successfully!\n");
        fprintf(log, "This means your ASI loader is working!\n\n");
        fprintf(log, "Next step: Use the full version!\n");
        fclose(log);
    }
}

/* ============================================================================
 * COMPILATION:
 * 
 * g++ -shared -O2 -o CSORedirect.asi CSORedirect_Test.cpp -static-libgcc -static-libstdc++
 * 
 * WHAT TO EXPECT:
 * 
 * If ASI loads:
 *   1. DLLMAIN_CALLED.txt appears
 *   2. Message box pops up saying "DllMain called!"
 *   
 * If ASI Loader works:
 *   3. INITIALIZEASAI_CALLED.txt appears
 *   4. Message box pops up saying "InitializeASI called!"
 *   5. CSORedirect.log appears
 *   
 * RESULTS:
 * 
 * No files at all:
 *   → ASI not loading
 *   → Check d3d9.dll exists
 *   → Try plugins\ folder
 *   
 * Only DLLMAIN_CALLED.txt:
 *   → DLL loads but InitializeASI not called
 *   → ASI Loader doesn't support InitializeASI
 *   → Need different ASI Loader version
 *   
 * Both files:
 *   → Everything works!
 *   → Use full CSORedirect_Ultimate.cpp
 * ============================================================================
 */
