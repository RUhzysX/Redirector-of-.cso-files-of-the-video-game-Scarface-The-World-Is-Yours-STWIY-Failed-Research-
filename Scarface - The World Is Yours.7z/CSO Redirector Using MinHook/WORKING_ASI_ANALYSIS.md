# 🔥 ANALYSIS OF WORKING ASI MODS

## ✅ **What We Found:**

### 1. ScarfaceHook Uses:
- **MinHook library** for hooking
- **Pattern scanning** (not IAT hooks!)
- **Exported `InitializeASI()` function**
- **Pattern-based function finding**

### 2. GangstaPatch Uses:
- **CreateFileA and ReadFile** (it IS in their strings!)
- Built: October 13, 2024
- Successfully hooks file functions!

### 3. Key Discovery:
**They DON'T use IAT hooking - they use PATTERN SCANNING!**

---

## 💡 **Why Our Approach Failed:**

### We Tried:
```c
// IAT Hook approach
Find CreateFileA in Import Address Table
Hook it there
```

### They Do:
```cpp
// Pattern scanning approach
Find CreateFileA CALL in game code
Hook the actual function in memory
```

**The difference:**
- IAT = Import table (protected/null in Scarface)
- Pattern = Find actual function calls in code

---

## 🎯 **The Working Method:**

### From ScarfaceHook (dllmain.cpp):

```cpp
// They export InitializeASI for ASI loader
extern "C"
{
    __declspec(dllexport) void InitializeASI()
    {
        // Pattern scanning
        PatternSolver::Initialize();
        
        // Hook functions using patterns
        if (_pattern(PATID_Camera_SetPosition))
            InjectHook(_pattern(PATID_Camera_SetPosition), &Hook, PATCH_JUMP);
    }
}
```

### Pattern Example:
```cpp
// Find function by its byte pattern
ms_patterns[PATID_Camera_SetPosition] = GetPattern(
    "8B C1 8B 4C 24 04 8B 11 89 50 64 8B 51 04 89 50 68", 0
);
```

---

## 🔧 **What We Need To Do:**

### Step 1: Export InitializeASI()
```c
extern "C" __declspec(dllexport) void InitializeASI()
{
    // Our initialization code
}
```

### Step 2: Use MinHook (not IAT hooks)
```c
#include "MinHook.h"

MH_Initialize();
MH_CreateHook(targetFunction, hookFunction, &originalFunction);
MH_EnableHook(targetFunction);
```

### Step 3: Find Functions by Pattern (not IAT)
```c
// Don't scan IAT - scan game code!
DWORD_PTR FindCreateFileCall()
{
    // Scan for CALL instruction to CreateFileA
    // Pattern: E8 ?? ?? ?? ?? (call relative)
}
```

---

## 📊 **Comparison:**

| Approach | Our Try | Working Mods |
|----------|---------|--------------|
| **Hook Method** | IAT hooking | MinHook |
| **Find Function** | Import table | Pattern scanning |
| **Initialization** | DllMain only | InitializeASI() export |
| **Result** | ❌ Crashes | ✅ Works! |

---

## 🚀 **The Fix:**

### Our Current Code:
```c
BOOL WINAPI DllMain(...) {
    // Try to hook via IAT
    HookIAT();  // FAILS!
}
```

### Should Be:
```c
// Export for ASI loader
extern "C" __declspec(dllexport) void InitializeASI()
{
    MH_Initialize();
    
    // Find CreateFileA by pattern, not IAT!
    DWORD_PTR createFileAddr = FindCreateFilePattern();
    
    if (createFileAddr) {
        MH_CreateHook((LPVOID)createFileAddr, HookedCreateFile, &g_origCreateFile);
        MH_EnableHook((LPVOID)createFileAddr);
    }
}
```

---

## 💪 **Key Insights:**

### 1. ASI Loader Calls InitializeASI()
Ultimate ASI Loader looks for this exported function!

### 2. MinHook > IAT Hooks
MinHook can hook any function in memory, not just imports!

### 3. Pattern Scanning Works
Even with protected IAT, we can find function calls in code!

### 4. Game Code Has Patterns
Every function has unique byte patterns we can search for!

---

## 🔍 **How to Find Patterns:**

### Method 1: Use IDA/Ghidra
```
1. Open Scarface.exe in IDA
2. Find CreateFileA usage
3. Copy the byte pattern
4. Search for it in our code
```

### Method 2: Runtime Scanning
```cpp
// Scan memory for specific patterns
DWORD_PTR ScanPattern(BYTE* pattern, const char* mask, DWORD_PTR start, DWORD size)
{
    for (DWORD i = 0; i < size; i++)
    {
        bool found = true;
        for (size_t j = 0; j < strlen(mask); j++)
        {
            if (mask[j] != '?' && pattern[j] != *(BYTE*)(start + i + j))
            {
                found = false;
                break;
            }
        }
        if (found) return start + i;
    }
    return 0;
}
```

---

## 🎯 **Action Plan:**

### Immediate:
1. ✅ Add `InitializeASI()` export
2. ✅ Use MinHook instead of IAT hooks
3. ✅ Find CreateFileA by pattern scanning
4. ✅ Hook actual function, not import table

### Next:
1. Find byte patterns for file functions
2. Implement pattern scanner
3. Hook the found functions
4. Test redirection!

---

## 💡 **Why This Will Work:**

**GangstaPatch literally has CreateFileA and ReadFile** in its strings!

This means:
- ✅ File hooking IS possible
- ✅ They hook these functions successfully
- ✅ They probably use pattern scanning
- ✅ We can do the same!

---

## 🔥 **The Real Solution:**

```c
// 1. Export InitializeASI
extern "C" __declspec(dllexport) void InitializeASI()
{
    // 2. Initialize MinHook
    MH_Initialize();
    
    // 3. Find functions by pattern (not IAT!)
    LPVOID createFileA = (LPVOID)FindPattern_CreateFileA();
    
    if (createFileA)
    {
        // 4. Hook with MinHook
        MH_CreateHook(createFileA, &HookedCreateFileA, &g_origCreateFileA);
        MH_EnableHook(createFileA);
        
        Log("Hooked CreateFileA at 0x%p", createFileA);
    }
}
```

**THIS is how the working mods do it!** 💪🔥
