/* CSORedirect_SafeDiagnostic_GCC.c
 * GCC-compatible version (no __try/__except)
 */

#include <windows.h>
#include <stdio.h>
#include <setjmp.h>

#define LOG_FILE "CSORedirect_SAFE.log"

static FILE* g_log = NULL;
static jmp_buf g_errorJump;

/* Signal handler for crashes */
LONG WINAPI ExceptionHandler(EXCEPTION_POINTERS* ep)
{
    if (g_log)
    {
        fprintf(g_log, "\n!!! EXCEPTION CAUGHT: 0x%08X !!!\n", ep->ExceptionRecord->ExceptionCode);
        fflush(g_log);
    }
    longjmp(g_errorJump, 1);
    return EXCEPTION_EXECUTE_HANDLER;
}

void SafeLog(const char* format, ...)
{
    va_list args;
    
    if (!g_log)
    {
        g_log = fopen(LOG_FILE, "w");
        if (!g_log) return;
    }
    
    va_start(args, format);
    vfprintf(g_log, format, args);
    va_end(args);
    
    /* Flush after every write */
    fflush(g_log);
}

void SafeDumpImports(void)
{
    HMODULE hModule;
    PIMAGE_DOS_HEADER pDosHeader;
    PIMAGE_NT_HEADERS pNTHeaders;
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc;
    int dllCount = 0;
    
    SafeLog("=== STARTING IMPORT SCAN ===\n\n");
    
    hModule = GetModuleHandle(NULL);
    if (!hModule)
    {
        SafeLog("ERROR: GetModuleHandle failed!\n");
        return;
    }
    SafeLog("Module handle: 0x%p\n", hModule);
    
    pDosHeader = (PIMAGE_DOS_HEADER)hModule;
    if (pDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
    {
        SafeLog("ERROR: Invalid DOS signature (0x%04X)!\n", pDosHeader->e_magic);
        return;
    }
    SafeLog("DOS signature: OK (0x%04X)\n", pDosHeader->e_magic);
    
    pNTHeaders = (PIMAGE_NT_HEADERS)((BYTE*)hModule + pDosHeader->e_lfanew);
    if (pNTHeaders->Signature != IMAGE_NT_SIGNATURE)
    {
        SafeLog("ERROR: Invalid NT signature!\n");
        return;
    }
    SafeLog("NT signature: OK\n");
    
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    if (!pImportDesc)
    {
        SafeLog("ERROR: No import directory!\n");
        return;
    }
    SafeLog("Import directory: 0x%p\n\n", pImportDesc);
    
    /* Count DLLs */
    SafeLog("Counting DLLs...\n");
    for (; pImportDesc->Name; pImportDesc++)
    {
        dllCount++;
    }
    SafeLog("Total DLLs found: %d\n\n", dllCount);
    
    /* Reset pointer */
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    SafeLog("=== IMPORTED DLLs AND FUNCTIONS ===\n\n");
    
    /* Scan each DLL */
    dllCount = 0;
    for (; pImportDesc->Name; pImportDesc++)
    {
        const char* dllName;
        int funcCount = 0;
        PIMAGE_THUNK_DATA pOrigThunk;
        
        dllCount++;
        
        dllName = (const char*)((BYTE*)hModule + pImportDesc->Name);
        SafeLog("[%d] DLL: %s\n", dllCount, dllName);
        
        /* Check if OriginalFirstThunk exists */
        if (pImportDesc->OriginalFirstThunk != 0)
        {
            SafeLog("    Using OriginalFirstThunk (0x%08X)\n", pImportDesc->OriginalFirstThunk);
            pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
        }
        else
        {
            SafeLog("    Using FirstThunk (OriginalFirstThunk is NULL)\n");
            pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
        }
        
        /* Count functions first */
        {
            PIMAGE_THUNK_DATA p = pOrigThunk;
            while (p->u1.Function != 0)
            {
                funcCount++;
                p++;
            }
        }
        SafeLog("    Functions: %d\n", funcCount);
        
        /* List functions */
        funcCount = 0;
        while (pOrigThunk->u1.Function != 0)
        {
            funcCount++;
            
            if (pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)
            {
                SafeLog("      [%d] ORDINAL: %d\n", funcCount, pOrigThunk->u1.Ordinal & 0xFFFF);
            }
            else
            {
                PIMAGE_IMPORT_BY_NAME pImport = (PIMAGE_IMPORT_BY_NAME)((BYTE*)hModule + pOrigThunk->u1.AddressOfData);
                SafeLog("      [%d] %s\n", funcCount, pImport->Name);
            }
            
            pOrigThunk++;
        }
        
        SafeLog("\n");
    }
    
    SafeLog("=== SCAN COMPLETE ===\n\n");
    
    /* Now look specifically for file functions in kernel32 */
    SafeLog("=== CHECKING FOR FILE FUNCTIONS IN KERNEL32 ===\n\n");
    
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    for (; pImportDesc->Name; pImportDesc++)
    {
        const char* dllName = (const char*)((BYTE*)hModule + pImportDesc->Name);
        
        if (_stricmp(dllName, "kernel32.dll") == 0)
        {
            PIMAGE_THUNK_DATA pOrigThunk;
            int foundCount = 0;
            
            SafeLog("Scanning kernel32.dll for file-related functions:\n\n");
            
            if (pImportDesc->OriginalFirstThunk != 0)
            {
                pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
            }
            else
            {
                pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
            }
            
            while (pOrigThunk->u1.Function != 0)
            {
                if (!(pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG))
                {
                    PIMAGE_IMPORT_BY_NAME pImport = (PIMAGE_IMPORT_BY_NAME)((BYTE*)hModule + pOrigThunk->u1.AddressOfData);
                    const char* funcName = (const char*)pImport->Name;
                    
                    /* Check for file-related functions */
                    if (strstr(funcName, "File") || 
                        strstr(funcName, "Read") || 
                        strstr(funcName, "Write") ||
                        strstr(funcName, "Find") ||
                        strstr(funcName, "Open") ||
                        strstr(funcName, "Close") ||
                        strstr(funcName, "Get") ||
                        strstr(funcName, "Set"))
                    {
                        SafeLog("  FOUND: %s\n", funcName);
                        foundCount++;
                    }
                }
                
                pOrigThunk++;
            }
            
            SafeLog("\nTotal file-related functions found: %d\n\n", foundCount);
            
            if (foundCount == 0)
            {
                SafeLog("WARNING: No standard file functions found!\n");
                SafeLog("Game likely uses:\n");
                SafeLog("  - Custom file system\n");
                SafeLog("  - P3D package loading\n");
                SafeLog("  - Memory-mapped files\n\n");
            }
            
            break;
        }
    }
    
    SafeLog("=== ANALYSIS COMPLETE ===\n");
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    if (fdwReason == DLL_PROCESS_ATTACH)
    {
        LPTOP_LEVEL_EXCEPTION_FILTER oldHandler;
        
        DisableThreadLibraryCalls(hinstDLL);
        
        SafeLog("=== SAFE DIAGNOSTIC v3.0 (GCC) ===\n\n");
        
        /* Set up exception handler */
        oldHandler = SetUnhandledExceptionFilter(ExceptionHandler);
        
        if (setjmp(g_errorJump) == 0)
        {
            /* Normal execution */
            SafeDumpImports();
        }
        else
        {
            /* We jumped here from exception */
            SafeLog("\n!!! RECOVERED FROM EXCEPTION !!!\n");
            SafeLog("Diagnostic incomplete but partially succeeded.\n");
        }
        
        /* Restore old handler */
        SetUnhandledExceptionFilter(oldHandler);
        
        if (g_log)
        {
            SafeLog("\n=== DIAGNOSTIC FINISHED ===\n");
            fclose(g_log);
            g_log = NULL;
        }
        
        MessageBoxA(NULL,
            "Diagnostic complete!\n\n"
            "Check CSORedirect_SAFE.log\n\n"
            "This shows ALL imports and what we can hook.",
            "Safe Diagnostic Done", 
            MB_OK | MB_ICONINFORMATION);
    }
    
    return TRUE;
}

/*
COMPILE (GCC):
gcc -shared -O2 -o CSORedirect_Safe.asi CSORedirect_SafeDiagnostic_GCC.c -lkernel32

COMPILE (MinGW):
gcc -shared -O2 -o CSORedirect_Safe.asi CSORedirect_SafeDiagnostic_GCC.c -lkernel32 -static-libgcc

This version:
- No __try/__except (GCC compatible!)
- Uses setjmp/longjmp for exception handling
- Flushes after every write
- Handles both OriginalFirstThunk and FirstThunk
- Won't crash even if things go wrong
*/
