# 🔥 SILENTPATCH ANALYSIS + OUR MOD LOADER STRATEGY

## 📚 **What We Learned from SilentPatch:**

### 1. Pattern Matching System
```cpp
// From SilentPatchScarface.cpp
auto vblock = get_pattern( "52 6A 00 6A 00 50 FF 51 2C 50 E8 ? ? ? ? BA", -5 + 1 );
auto setAffinity = get_pattern( "56 8B 35 ? ? ? ? 8D 44 24 08", -3 );
```

**Uses ModUtils library**: https://github.com/CookiePLMonster/ModUtils
- `MemoryMgr.h` - Memory manipulation helpers
- `Patterns.h` - Byte pattern scanning
- `HookInit.hpp` - Hook initialization

### 2. Function Hooking
```cpp
ReadCall( alloc, orgMalloc );  // Read original function pointer
InjectHook( vb, &pure3d::d3dPrimBuffer::GetOrCreateVertexBuffer );  // Replace
```

### 3. Import Table Hooking
```cpp
// Hook CreateThread in kernel32.dll import table
PIMAGE_IMPORT_DESCRIPTOR pImports = ...;
ReplaceFunction(pAddress);
```

### 4. INI Configuration
```cpp
namespace INISettings
{
    int ReadSetting( const char* key )
    {
        return GetPrivateProfileIntA( "Scarface", key, -1, ".\\settings.ini" );
    }
}
```

---

## 🎯 **Our Mod Loader Architecture:**

Based on SilentPatch's proven approach:

### Strategy 1: Pattern-Based Script Hook (BEST!)

```cpp
// Find script loading function using pattern
auto scriptLoad = get_pattern("PATTERN_FROM_REVERSE_ENGINEERING");

// Hook it
ResourceLoad_t orgResourceLoad;
ReadCall(scriptLoad, orgResourceLoad);
InjectHook(scriptLoad, HookedResourceLoad);

// In hook:
void* HookedResourceLoad(const char* path, ...)
{
    if (ends_with(path, ".cso"))
    {
        // Try .cs version
        string csPath = replace(path, ".cso", ".cs");
        csPath = replace(csPath, "scriptc/", "script/");
        
        return orgResourceLoad(csPath, ...);
    }
    return orgResourceLoad(path, ...);
}
```

### Strategy 2: File System Hook (FALLBACK)

```cpp
// Hook CreateFileA (simpler, always works)
CreateFileA_t orgCreateFileA = CreateFileA;
InjectHook(&CreateFileA, HookedCreateFileA);

HANDLE HookedCreateFileA(const char* path, ...)
{
    if (ends_with(path, ".cso"))
    {
        // Try .cs alternative
        string csPath = ...;
        HANDLE h = orgCreateFileA(csPath, ...);
        if (h != INVALID_HANDLE_VALUE)
            return h;
    }
    return orgCreateFileA(path, ...);
}
```

---

## 🛠️ **Implementation Plan:**

### Phase 1: Basic File Redirection (Easy)
```cpp
// Hook CreateFileA only
// Redirect .cso → .cs
// Simple config file
```

**Pros**: Works immediately, no reverse engineering needed
**Cons**: Only redirects file loading, not in-memory compilation

### Phase 2: Script Function Hook (Advanced)
```cpp
// Find script loading function via patterns
// Hook at TorqueScript level
// Full control over script system
```

**Pros**: Complete control, can inject scripts directly
**Cons**: Requires finding the function pattern

### Phase 3: Full Mod System (Ultimate)
```cpp
// Multiple injection points
// Mod priority system
// Hot-reload support
// Script preprocessing
```

---

## 📦 **Required Libraries:**

### 1. ModUtils (from CookiePLMonster)
- `MemoryMgr.h` - Memory operations
- `Patterns.h` - Pattern scanning
- `HookInit.hpp` - Hook helpers

Get from: https://github.com/CookiePLMonster/ModUtils

### 2. Microsoft Detours (Optional)
Alternative to ModUtils for hooking:
```
https://github.com/microsoft/Detours
```

---

## 🎮 **Code Structure:**

```cpp
CSORedirect_Ultimate/
├── source/
│   ├── Main.cpp              ← Entry point
│   ├── ScriptHook.cpp        ← Script loading hooks
│   ├── FileHook.cpp          ← File system hooks
│   ├── Config.cpp            ← Configuration management
│   ├── Patterns.cpp          ← Game-specific patterns
│   └── Utils/                ← ModUtils submodule
│       ├── MemoryMgr.h
│       ├── Patterns.h
│       └── HookInit.hpp
├── config.ini                ← User configuration
└── redirects.txt             ← .cso → .cs mappings
```

---

## 🔍 **Patterns We Need to Find:**

### 1. Script Loading Function
**Likely signature:**
```cpp
void* LoadScript(const char* path, const char* type, const char* heap, int mode)
```

**Pattern hints from startup.cso.cs:**
```torquescript
stxfaflihej("script/config.cs", "Script", "ScriptHeap", stxonlakmem());
stxgcoimgjk("script/actionmaps.cs", "Script");
```

These call the actual C++ functions!

### 2. TorqueScript exec() Function
```cpp
void exec(const char* scriptPath)
```

### 3. Script Compilation Function
```cpp
void* CompileScript(const char* source)
```

---

## 🎯 **Finding Patterns (Step by Step):**

### Method 1: String References
```
1. Search for "script/" or ".cso" in exe
2. Find XREF (cross-references) to these strings
3. That's your script loading function!
4. Create byte pattern from function prologue
```

### Method 2: Debug Symbols
```
If game has PDB:
1. Load in IDA/Ghidra with symbols
2. Find ResourceManager::load or similar
3. Get function address
4. Create pattern
```

### Method 3: Runtime Analysis
```
1. Attach debugger
2. Set breakpoint on CreateFileA
3. Load game
4. When it breaks on .cso file, check call stack
5. Find the calling function
6. Create pattern
```

---

## 💡 **Our Three-Tiered Approach:**

### Tier 1: File System Hook (WORKING NOW)
```cpp
// Hook CreateFileA
// Works immediately
// No reverse engineering needed
```
**Status**: ✅ Can implement TODAY

### Tier 2: Script API Hook (BETTER)
```cpp
// Hook exec() or similar TorqueScript API
// Better integration
// Requires pattern finding
```
**Status**: ⏳ Need to find pattern

### Tier 3: Direct Bytecode Injection (BEST)
```cpp
// Modify startup.cso directly
// Guaranteed to work
// Python-based
```
**Status**: ✅ Already have startup_patcher_v2.py

---

## 🚀 **Recommended Implementation Order:**

### Step 1: CreateFileA Hook (TODAY)
```cpp
// Simple, reliable, works immediately
// Good for testing our infrastructure
```

### Step 2: Find Script Patterns (TOMORROW)
```cpp
// Use IDA/Ghidra to find functions
// Create patterns using SilentPatch style
// More robust, better performance
```

### Step 3: Full Mod System (NEXT WEEK)
```cpp
// Combine all approaches
// Add mod priority system
// Hot-reload support
// Preprocessing
```

---

## 🎓 **Key Lessons from SilentPatch:**

### 1. Pattern Matching is Robust
- Works across game versions
- Wildcards (?) for variable parts
- Offsets (-3, +1) for precise targeting

### 2. Multiple Hook Points
- Don't rely on one hook
- Have fallbacks
- Try-catch everything (TXN_CATCH)

### 3. Configuration Flexibility
- INI files for user settings
- Easy to modify without recompiling
- Clear, documented options

### 4. Clean Architecture
- Separate concerns (patterns, hooks, config)
- Use namespaces
- Good error handling

---

## 🔥 **Let's Build It!**

I'll create three versions:

### Version 1: Simple (CreateFileA hook)
- Works immediately
- No reverse engineering
- Good for testing

### Version 2: Advanced (Script function hook)
- Better performance
- Full control
- Requires pattern

### Version 3: Hybrid (Both + bytecode patching)
- Most reliable
- Multiple fallbacks
- Best of all worlds

**Which one should we start with?** 💪

I recommend **Version 1** (CreateFileA) because:
- ✅ Works NOW
- ✅ No reverse engineering needed
- ✅ Proven approach (SilentPatch uses IAT hooking)
- ✅ Can test immediately

Then we can enhance it with patterns later!
