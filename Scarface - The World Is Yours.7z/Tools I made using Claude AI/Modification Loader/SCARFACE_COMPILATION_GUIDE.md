# SCARFACE CSO COMPILATION GUIDE
## Complete Reference from Torque3D + stwiy-lib + BrokenFace

---

## CRITICAL COMPILATION PATTERNS

### 1. OBJECT CREATION

**Source: TorqueScript**
```javascript
%obj = new ClassName(param1: "value1", param2: "value2");
```

**Bytecode Sequence (from Torque3D astNodes.cpp):**

```
[If top-level object creation]:
   OP_LOADIMMED_UINT 0 0    // Push 0 to UINT stack (parent = none)

OP_PUSHFRAME                // Create argument frame

// Compile class name expression → STR stack
OP_LOADIMMED_IDENT <class_name_offset>
OP_PUSH                     // Push class name to argFrame

// Compile object name expression → STR stack (empty string for unnamed)
OP_LOADIMMED_STR <empty_string_offset>
OP_PUSH                     // Push object name to argFrame

// For each constructor parameter:
OP_LOADIMMED_IDENT <param_name_offset>
OP_PUSH
OP_LOADIMMED_STR <param_value_offset>
OP_PUSH

OP_CREATE_OBJECT
<parent_object_hash>        // 1 U32 (StringTableEntry)
<isDatablock>               // 1 U32 (0 or 1)
<isInternal>                // 1 U32 (0 or 1)
<isSingleton>               // 1 U32 (0 or 1)
<lineNumber>                // 1 U32
<failJump>                  // 1 U32 (IP to jump on failure - patched later)

[For each field assignment]:
   OP_SETCURFIELD <field_name>
   // Compile field value expression
   OP_SAVEFIELD_STR (or _UINT, _FLT)

OP_ADD_OBJECT
<placeAtRoot>               // 1 U32 (0 or 1)

[For each sub-object]:
   // Recursive object creation

OP_END_OBJECT
<placeAtRoot>               // 1 U32 (0 or 1)

[Torque3D has OP_FINISH_OBJECT here - SCARFACE REMOVED IT]

[If assigning to variable]:
   OP_SETCURVAR_CREATE <var_name>
   OP_SETCUROBJECT         // Make it current object
```

**KEY INSIGHTS:**

1. **argFrame structure after pushes**:
   ```
   argFrame = [
       parent_tag_string,    // From OP_TAG_TO_STR + OP_PUSH
       class_name,           // From OP_LOADIMMED_IDENT + OP_PUSH
       object_name,          // From OP_LOADIMMED_STR + OP_PUSH  
       param1_name,          // From OP_LOADIMMED_IDENT + OP_PUSH
       param1_value,         // From OP_LOADIMMED_STR + OP_PUSH
       param2_name,
       param2_value,
       ...
   ]
   ```

2. **BrokenFace's opCreateObject reads**:
   - `parent = getString()` → Reads class name from STR stack (which was loaded from argFrame[1])
   - `mystery = getCode()` → Reads isDatablock (or isInternal?)
   - `end = getCode()` → Reads failJump IP
   - `argv = argFrame.pop()` → Gets all constructor params

3. **Scarface differences from Torque3D**:
   - No `OP_FINISH_OBJECT` at end
   - No `OP_PUSH_THIS` opcode
   - Uses generic `OP_PUSH` instead of type-specific pushes

---

### 2. METHOD CALLS

**Source: TorqueScript**
```javascript
%obj.methodName("arg1", "arg2");
```

**Bytecode Sequence (from Torque3D astNodes.cpp):**

```
OP_PUSHFRAME                // Create argument frame

// Load object variable
OP_SETCURVAR <obj_var_name>
OP_LOADVAR_STR              // Load object to STR stack
OP_PUSH                     // Push to argFrame (first argument = 'this')

// For each method argument:
OP_LOADIMMED_STR <arg_value>
OP_PUSH

OP_CALLFUNC
<method_name>               // 1 U32 (StringTableEntry hash)
<namespace>                 // 1 U32 (usually 0)
<callType>                  // 1 U32 (1 = MethodCall)

[If return value not used]:
   OP_STR_TO_NONE           // Discard return value from STR stack
```

**CallType Values:**
- 0 = FunctionCall
- 1 = MethodCall
- 2 = ParentCall

**KEY INSIGHTS:**

1. **Method calls have implicit 'this' parameter**:
   - First argument in argFrame is ALWAYS the object
   - Object is loaded via SETCURVAR + LOADVAR_STR

2. **BrokenFace's opCallfunc reads**:
   - `fnName = getString()` → Method name from STR stack
   - `fnNamespace = getString()` → Namespace (usually empty)
   - `callType = getCode()` → 0/1/2
   - `argv = argFrame.pop()` → All arguments including 'this'

3. **Return value handling**:
   - Functions always push return to STR stack
   - Use OP_STR_TO_NONE if not needed
   - Use OP_STR_TO_FLT/UINT if type conversion needed

---

### 3. FUNCTION CALLS

**Source: TorqueScript**
```javascript
functionName("arg1", "arg2");
```

**Bytecode Sequence:**

```
OP_PUSHFRAME                // Create argument frame

// For each argument:
OP_LOADIMMED_STR <arg_value>
OP_PUSH

OP_CALLFUNC
<function_name>             // 1 U32
<namespace>                 // 1 U32 (usually 0)
<callType>                  // 1 U32 (0 = FunctionCall)

[Type conversion if needed]
```

---

### 4. VARIABLE ASSIGNMENT

**Source: TorqueScript**
```javascript
%var = "value";
```

**Bytecode Sequence:**

```
OP_LOADIMMED_STR <value_offset>    // Load to STR stack
OP_SETCURVAR_CREATE <var_name>     // Set as current var (create if needed)
OP_SAVEVAR_STR                     // Save from STR stack to variable
```

**Variable Operations:**
- `OP_SETCURVAR` - Set current variable for read/write (don't create)
- `OP_SETCURVAR_CREATE` - Set current variable (create if doesn't exist)
- `OP_LOADVAR_STR/FLT/UINT` - Load variable to type-specific stack
- `OP_SAVEVAR_STR/FLT/UINT` - Save from stack to variable

---

### 5. IF STATEMENTS

**Source: TorqueScript**
```javascript
if (condition) {
    // then block
} else {
    // else block
}
```

**Bytecode Sequence:**

```
// Evaluate condition → pushes to STR/FLT stack
[condition expression bytecode]

OP_JMPIFNOT <else_ip>       // Jump to else if false

// Then block bytecode
[then block bytecode]

OP_JMP <end_ip>             // Jump over else

<else_ip>:
// Else block bytecode
[else block bytecode]

<end_ip>:
// Continue...
```

**Jump Opcodes:**
- `OP_JMPIF` - Jump if STR stack top is true
- `OP_JMPIFNOT` - Jump if STR stack top is false
- `OP_JMPIFF` - Jump if FLT stack top is true
- `OP_JMPIFFNOT` - Jump if FLT stack top is false
- `OP_JMPIF_NP` - Jump if true (no pop)
- `OP_JMPIFNOT_NP` - Jump if false (no pop)
- `OP_JMP` - Unconditional jump

---

### 6. WHILE LOOPS

**Source: TorqueScript**
```javascript
while (condition) {
    // loop body
}
```

**Bytecode Sequence:**

```
<start_ip>:
// Evaluate condition
[condition expression bytecode]

OP_JMPIFNOT <end_ip>        // Exit loop if false

// Loop body
[body bytecode]

OP_JMP <start_ip>           // Loop back to condition

<end_ip>:
// Continue...
```

---

### 7. RETURN STATEMENTS

**Source: TorqueScript**
```javascript
return %value;
```

**Bytecode Sequence:**

```
// Load return value to STR stack
OP_SETCURVAR <value_var>
OP_LOADVAR_STR

OP_RETURN                   // Return (value on STR stack)
```

**Empty return:**
```
OP_LOADIMMED_STR 0 0        // Load empty string
OP_RETURN
```

**Note**: Torque3D has `OP_RETURN_VOID`, `OP_RETURN_FLT`, `OP_RETURN_UINT` but Scarface only has `OP_RETURN`.

---

### 8. EXPRESSIONS

**Arithmetic:**
```javascript
%result = %a + %b;
```

```
OP_SETCURVAR <a_var>
OP_LOADVAR_STR              // Load %a
OP_STR_TO_FLT               // Convert to float

OP_SETCURVAR <b_var>
OP_LOADVAR_STR              // Load %b
OP_STR_TO_FLT               // Convert to float

OP_ADD                      // Pop 2, push result to FLT stack

OP_FLT_TO_STR               // Convert back to string
OP_SETCURVAR_CREATE <result_var>
OP_SAVEVAR_STR              // Save to %result
```

**Binary Operators:**
- `OP_ADD`, `OP_SUB`, `OP_MUL`, `OP_DIV` - Arithmetic
- `OP_MOD` - Modulo
- `OP_BITAND`, `OP_BITOR`, `OP_XOR` - Bitwise
- `OP_SHL`, `OP_SHR` - Bit shifts
- `OP_AND`, `OP_OR` - Logical
- `OP_CMPEQ`, `OP_CMPNE`, `OP_CMPLT`, `OP_CMPLE`, `OP_CMPGR`, `OP_CMPGE` - Comparisons

**Unary Operators:**
- `OP_NOT` - Logical NOT
- `OP_NOTF` - Float NOT
- `OP_NEG` - Negation
- `OP_ONESCOMPLEMENT` - Bitwise NOT

---

### 9. STRING CONCATENATION

**Source: TorqueScript**
```javascript
%result = %str1 @ %str2 @ %str3;
```

**Bytecode Sequence:**

```
// Push first string
OP_SETCURVAR <str1_var>
OP_LOADVAR_STR

// For each additional string:
OP_ADVANCE_STR              // Move string pointer
OP_SETCURVAR <str2_var>
OP_LOADVAR_STR
OP_REWIND_STR               // Combine strings

OP_ADVANCE_STR
OP_SETCURVAR <str3_var>
OP_LOADVAR_STR
OP_REWIND_STR

OP_TERMINATE_REWIND_STR     // Finalize concatenation

OP_SETCURVAR_CREATE <result_var>
OP_SAVEVAR_STR
```

**String Opcodes:**
- `OP_ADVANCE_STR` - Advance string builder
- `OP_ADVANCE_STR_COMMA` - Advance with comma separator
- `OP_ADVANCE_STR_NUL` - Advance with null terminator
- `OP_ADVANCE_STR_APPENDCHAR <char>` - Append specific character
- `OP_REWIND_STR` - Join top 2 strings on stack
- `OP_TERMINATE_REWIND_STR` - Finalize string building
- `OP_COMPARE_STR` - Compare strings

---

### 10. FIELD ACCESS

**Source: TorqueScript**
```javascript
%obj.fieldName = "value";
%val = %obj.fieldName;
```

**Setting Field:**
```
OP_SETCURVAR <obj_var>
OP_LOADVAR_STR
OP_SETCUROBJECT             // Make object current

OP_SETCURFIELD <field_name>

OP_LOADIMMED_STR <value>
OP_SAVEFIELD_STR            // Save to field
```

**Getting Field:**
```
OP_SETCURVAR <obj_var>
OP_LOADVAR_STR
OP_SETCUROBJECT

OP_SETCURFIELD <field_name>
OP_LOADFIELD_STR            // Load from field to STR stack

OP_SETCURVAR_CREATE <val_var>
OP_SAVEVAR_STR
```

---

## STACK MANAGEMENT RULES

### The Three Main Stacks:

1. **STR Stack** - String values
   - Load: `OP_LOADIMMED_STR`, `OP_LOADVAR_STR`, `OP_LOADFIELD_STR`
   - Save: `OP_SAVEVAR_STR`, `OP_SAVEFIELD_STR`
   - Convert: `OP_STR_TO_FLT`, `OP_STR_TO_UINT`, `OP_STR_TO_NONE`

2. **FLT Stack** - Float values
   - Load: `OP_LOADIMMED_FLT`, `OP_LOADVAR_FLT`, `OP_LOADFIELD_FLT`
   - Save: `OP_SAVEVAR_FLT`, `OP_SAVEFIELD_FLT`
   - Convert: `OP_FLT_TO_STR`, `OP_FLT_TO_UINT`, `OP_FLT_TO_NONE`

3. **UINT Stack** - Unsigned integer values
   - Load: `OP_LOADIMMED_UINT`, `OP_LOADVAR_UINT`, `OP_LOADFIELD_UINT`
   - Save: `OP_SAVEVAR_UINT`, `OP_SAVEFIELD_UINT`
   - Convert: `OP_UINT_TO_STR`, `OP_UINT_TO_FLT`, `OP_UINT_TO_NONE`

### The argFrame Stack:

- `OP_PUSHFRAME` - Create new argument frame (empty list)
- `OP_PUSH` - Pop from STR stack, push to current argFrame
- Function/method calls pop entire argFrame

### Rules:

1. **Always match types**: Load to correct stack, save from correct stack
2. **Convert when needed**: Use OP_*_TO_* opcodes
3. **Clean up**: Use OP_*_TO_NONE to discard unwanted values
4. **argFrame is LIFO**: Arguments pushed in order they appear

---

## COMMON PATTERNS

### Pattern 1: Load String Literal
```
OP_LOADIMMED_STR <offset_high> <offset_low>
```

### Pattern 2: Load Identifier (Variable/Function/Field Name)
```
OP_LOADIMMED_IDENT <offset>
```

### Pattern 3: Load Integer
```
OP_LOADIMMED_UINT <value>
```

### Pattern 4: Load Float
```
OP_LOADIMMED_FLT <float_table_index>
```

### Pattern 5: Push to argFrame
```
[Load value to STR/FLT/UINT stack]
OP_PUSH  // Scarface uses generic OP_PUSH
```

### Pattern 6: Variable Access
```
OP_SETCURVAR <var_name>    // Set as current
OP_LOADVAR_STR             // Load value
```

### Pattern 7: Object Access
```
OP_SETCURVAR <obj_var>
OP_LOADVAR_STR
OP_SETCUROBJECT            // Make current object
```

---

## DEBUGGING TIPS

1. **Count your PUSHes**: argFrame must be balanced
2. **Track stack depths**: STR/FLT/UINT stacks must not underflow
3. **Patch jumps**: All jump targets must be patched with actual IPs
4. **Match types**: Type mismatches cause runtime errors
5. **Check end_ip**: Object creation end_ip must point AFTER OP_END_OBJECT

---

## SCARFACE-SPECIFIC NOTES

### Removed from Torque3D:
- `OP_FINISH_OBJECT` - Don't emit this
- `OP_PUSH_UINT`, `OP_PUSH_FLT`, `OP_PUSH_VAR`, `OP_PUSH_THIS` - Use generic `OP_PUSH`
- `OP_RETURN_VOID`, `OP_RETURN_FLT`, `OP_RETURN_UINT` - Use generic `OP_RETURN`
- `OP_INC`, `OP_DEC` - Increment/decrement operators
- Iterator opcodes - No foreach loops
- `OP_DOCBLOCK_STR` - No documentation blocks

### String Offset Encoding:
- Offsets are stored as 2 bytes in big-endian
- But emitted as 2 separate U32 codes
- BrokenFace reads them together via `getStringOffset()`

Example:
```python
offset = 0x012C
code.emit(0x01)  # High byte
code.emit(0x2C)  # Low byte
```

### IdentTable:
- Tracks which code indices reference which string offsets
- Required for proper decompilation
- Add entry whenever emitting identifier offset:
```python
offset = add_identifier(name)
ident_table.add(offset, current_code_index)
emit_u16_bigendian(offset)
```

---

## END OF GUIDE
