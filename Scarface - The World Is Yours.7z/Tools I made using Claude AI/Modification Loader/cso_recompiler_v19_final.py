#!/usr/bin/env python3
"""
Scarface CSO Recompiler v19 - FINAL EDITION
Based on complete Torque3D source analysis + stwiy-lib + BrokenFace
"""

import struct
import sys
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

# ==============================================================================
# OPCODES (from Torque3D compiler.h + stwiy-lib CodeBlock.cpp)
# ==============================================================================

# Function and object opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05

# Jump opcodes
OP_JMPIFFNOT = 0x06
OP_JMPIFNOT = 0x07
OP_JMPIFF = 0x08
OP_JMPIF = 0x09
OP_JMPIFNOT_NP = 0x0A
OP_JMPIF_NP = 0x0B
OP_JMP = 0x0C

# Return
OP_RETURN = 0x0D

# Comparison opcodes
OP_CMPEQ = 0x0E
OP_CMPGR = 0x11
OP_CMPGE = 0x12
OP_CMPLT = 0x0F
OP_CMPLE = 0x10
OP_CMPNE = 0x13

# Binary operators
OP_XOR = 0x14
OP_MOD = 0x15
OP_BITAND = 0x16
OP_BITOR = 0x17
OP_NOT = 0x18
OP_NOTF = 0x19
OP_ONESCOMPLEMENT = 0x1A
OP_SHR = 0x1B
OP_SHL = 0x1C
OP_AND = 0x1D
OP_OR = 0x1E
OP_ADD = 0x1F
OP_SUB = 0x20
OP_MUL = 0x21
OP_DIV = 0x22
OP_NEG = 0x23

# Variable opcodes
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_SETCURVAR_ARRAY = 0x28
OP_SETCURVAR_ARRAY_CREATE = 0x29

OP_LOADVAR_UINT = 0x2C
OP_LOADVAR_FLT = 0x2D
OP_LOADVAR_STR = 0x2E

OP_SAVEVAR_UINT = 0x2F
OP_SAVEVAR_FLT = 0x30
OP_SAVEVAR_STR = 0x31

# Object field opcodes
OP_SETCUROBJECT = 0x32
OP_SETCUROBJECT_NEW = 0x33

OP_SETCURFIELD = 0x34
OP_SETCURFIELD_ARRAY = 0x35

OP_LOADFIELD_UINT = 0x36
OP_LOADFIELD_FLT = 0x37
OP_LOADFIELD_STR = 0x38

OP_SAVEFIELD_UINT = 0x39
OP_SAVEFIELD_FLT = 0x3A
OP_SAVEFIELD_STR = 0x3B

# Type conversion opcodes
OP_STR_TO_UINT = 0x3C
OP_STR_TO_FLT = 0x3D
OP_STR_TO_NONE = 0x3E
OP_FLT_TO_UINT = 0x3F
OP_FLT_TO_STR = 0x40
OP_FLT_TO_NONE = 0x41
OP_UINT_TO_FLT = 0x42
OP_UINT_TO_STR = 0x43
OP_UINT_TO_NONE = 0x44

# Immediate load opcodes
OP_LOADIMMED_UINT = 0x45
OP_LOADIMMED_FLT = 0x46
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_TAG_TO_STR = 0x49

# Function call opcodes
OP_CALLFUNC_RESOLVE = 0x4A
OP_CALLFUNC = 0x4B

# String manipulation opcodes
OP_ADVANCE_STR = 0x4D
OP_ADVANCE_STR_APPENDCHAR = 0x4E
OP_ADVANCE_STR_COMMA = 0x4F
OP_ADVANCE_STR_NUL = 0x50
OP_REWIND_STR = 0x51
OP_TERMINATE_REWIND_STR = 0x52
OP_COMPARE_STR = 0x53

# Stack manipulation opcodes
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

# ==============================================================================
# AST NODE CLASSES
# ==============================================================================

@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    pass

@dataclass
class FunctionDecl(ASTNode):
    """Function declaration"""
    name: str
    namespace: str
    package: str
    params: List[str]
    body: List[ASTNode]

@dataclass
class ObjectCreation(ASTNode):
    """Object creation: new ClassName(prop1: "val1", prop2: "val2")"""
    class_name: str
    object_name: str  # Empty string for unnamed objects
    properties: Dict[str, str]  # Key-value pairs
    parent: int = 0  # Parent object (0 = none)
    is_datablock: bool = False
    is_internal: bool = False
    is_singleton: bool = False

@dataclass
class VariableAssignment(ASTNode):
    """Variable assignment: %var = value"""
    var_name: str
    value: ASTNode
    create: bool = True  # Create if doesn't exist

@dataclass
class MethodCall(ASTNode):
    """Method call: %obj.method(args)"""
    object_var: str
    method_name: str
    arguments: List[ASTNode]

@dataclass
class FunctionCall(ASTNode):
    """Function call: function(args)"""
    function_name: str
    namespace: str
    arguments: List[ASTNode]

@dataclass
class ReturnStatement(ASTNode):
    """Return statement"""
    value: Optional[ASTNode] = None

@dataclass
class IfStatement(ASTNode):
    """If statement"""
    condition: ASTNode
    then_body: List[ASTNode]
    else_body: Optional[List[ASTNode]] = None

@dataclass
class WhileStatement(ASTNode):
    """While loop"""
    condition: ASTNode
    body: List[ASTNode]

@dataclass
class StringLiteral(ASTNode):
    """String literal"""
    value: str

@dataclass
class IntegerLiteral(ASTNode):
    """Integer literal"""
    value: int

@dataclass
class FloatLiteral(ASTNode):
    """Float literal"""
    value: float

@dataclass
class VariableRef(ASTNode):
    """Variable reference"""
    var_name: str

@dataclass
class BinaryOp(ASTNode):
    """Binary operation"""
    operator: str
    left: ASTNode
    right: ASTNode

# ==============================================================================
# CODE STREAM
# ==============================================================================

class CodeStream:
    """Manages bytecode generation"""
    
    def __init__(self):
        self.codes: List[int] = []
        
    def emit(self, value: int):
        """Emit a single code value"""
        self.codes.append(value)
        
    def emit_u16_bigendian(self, value: int):
        """Emit a 16-bit value as 2 bytes (big-endian)"""
        self.codes.append((value >> 8) & 0xFF)
        self.codes.append(value & 0xFF)
        
    def emit_u32(self, value: int):
        """Emit a U32 value (handles compression)"""
        if value < 255:
            self.codes.append(value)
        else:
            self.codes.append(0xFF)
            self.codes.append((value >> 8) & 0xFF)
            self.codes.append(value & 0xFF)
            
    def get_code_index(self) -> int:
        """Get current code index"""
        return len(self.codes)
        
    def tell(self) -> int:
        """Get current position (alias for get_code_index)"""
        return len(self.codes)
        
    def patch(self, index: int, value: int):
        """Patch a code at given index"""
        if value < 255:
            self.codes[index] = value
        else:
            # Need to expand - shift everything
            self.codes.insert(index + 1, value & 0xFF)
            self.codes[index] = 0xFF
            self.codes.insert(index + 1, (value >> 8) & 0xFF)

# ==============================================================================
# STRING/IDENTIFIER MANAGEMENT
# ==============================================================================

class StringTable:
    """Manages string table"""
    
    def __init__(self):
        self.strings: List[str] = []
        self.string_map: Dict[str, int] = {}
        self.current_offset = 0
        
    def add(self, s: str) -> int:
        """Add string and return offset"""
        if s in self.string_map:
            return self.string_map[s]
            
        offset = self.current_offset
        self.strings.append(s)
        self.string_map[s] = offset
        self.current_offset += len(s.encode('utf-8')) + 1  # +1 for null terminator
        return offset
        
    def get_bytes(self) -> bytes:
        """Get string table as bytes"""
        result = b''
        for s in self.strings:
            result += s.encode('utf-8') + b'\x00'
        return result

class FunctionStringTable:
    """Manages function string table (identifiers)"""
    
    def __init__(self):
        self.identifiers: List[str] = []
        self.ident_map: Dict[str, int] = {}
        
    def add(self, ident: str) -> int:
        """Add identifier and return index"""
        if ident in self.ident_map:
            return self.ident_map[ident]
            
        index = len(self.identifiers)
        self.identifiers.append(ident)
        self.ident_map[ident] = index
        return index
        
    def get_bytes(self) -> bytes:
        """Get function string table as bytes"""
        result = b''
        for ident in self.identifiers:
            result += ident.encode('utf-8') + b'\x00'
        return result

class FloatTable:
    """Manages float table"""
    
    def __init__(self):
        self.floats: List[float] = []
        self.float_map: Dict[float, int] = {}
        
    def add(self, f: float) -> int:
        """Add float and return index"""
        if f in self.float_map:
            return self.float_map[f]
            
        index = len(self.floats)
        self.floats.append(f)
        self.float_map[f] = index
        return index
        
    def get_bytes(self) -> bytes:
        """Get float table as bytes"""
        return b''.join(struct.pack('<d', f) for f in self.floats)

class IdentTable:
    """Tracks identifier references in code"""
    
    def __init__(self):
        self.references: List[Tuple[int, int]] = []  # (string_offset, code_index)
        
    def add(self, string_offset: int, code_index: int):
        """Add identifier reference"""
        self.references.append((string_offset, code_index))

# ==============================================================================
# COMPILER
# ==============================================================================

class CSOCompiler:
    """Compiles TorqueScript AST to CSO bytecode"""
    
    def __init__(self):
        self.code = CodeStream()
        self.string_table = StringTable()
        self.function_strings = FunctionStringTable()
        self.float_table = FloatTable()
        self.ident_table = IdentTable()
        self.global_strings = []  # Global variable names
        
    def add_string(self, s: str) -> int:
        """Add string to string table"""
        return self.string_table.add(s)
        
    def add_identifier(self, ident: str) -> int:
        """Add identifier to function string table"""
        return self.function_strings.add(ident)
        
    def add_float(self, f: float) -> int:
        """Add float to float table"""
        return self.float_table.add(f)
        
    # ==========================================================================
    # COMPILATION METHODS (Based on Torque3D astNodes.cpp)
    # ==========================================================================
    
    def compile_function(self, func: FunctionDecl):
        """
        Compile function declaration
        Based on: Torque3D compiler.cpp
        """
        # Add function name to identifier table
        name_idx = self.add_identifier(func.name)
        namespace_idx = self.add_identifier(func.namespace) if func.namespace else 0
        package_idx = self.add_identifier(func.package) if func.package else 0
        
        # OP_FUNC_DECL
        self.code.emit(OP_FUNC_DECL)
        self.code.emit_u16_bigendian(name_idx)
        self.code.emit_u16_bigendian(namespace_idx)
        self.code.emit_u16_bigendian(package_idx)
        self.code.emit(1)  # hasBody = 1
        
        # Reserve space for end_ip (will be patched)
        end_ip_index = self.code.get_code_index()
        self.code.emit(0)
        
        # Parameter count
        self.code.emit(len(func.params))
        
        # Parameter names
        for param in func.params:
            param_idx = self.add_identifier(param)
            self.code.emit_u16_bigendian(param_idx)
            
        # Compile function body
        for stmt in func.body:
            self.compile_statement(stmt)
            
        # Patch end_ip
        end_ip = self.code.get_code_index()
        self.code.patch(end_ip_index, end_ip)
        
    def compile_object_creation(self, obj: ObjectCreation):
        """
        Compile object creation
        Based on: Torque3D astNodes.cpp ObjectDeclNode::compileSubObject()
        
        CRITICAL SEQUENCE:
        1. OP_PUSHFRAME
        2. Load class name → OP_PUSH
        3. Load object name → OP_PUSH
        4. For each property: Load key → OP_PUSH, Load value → OP_PUSH
        5. OP_CREATE_OBJECT + 6 parameters
        6. [Field assignments if needed]
        7. OP_ADD_OBJECT
        8. OP_END_OBJECT
        """
        # 1. OP_PUSHFRAME - Create argument frame
        self.code.emit(OP_PUSHFRAME)
        
        # 2. Load class name and push to argFrame
        class_idx = self.add_identifier(obj.class_name)
        self.code.emit(OP_LOADIMMED_IDENT)
        self.code.emit_u16_bigendian(class_idx)
        self.code.emit(OP_PUSH)
        
        # 3. Load object name and push to argFrame
        # (Empty string for unnamed objects)
        obj_name = obj.object_name if obj.object_name else ""
        name_offset = self.add_string(obj_name)
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_u16_bigendian(name_offset)
        self.code.emit(OP_PUSH)
        
        # 4. Load all properties as key-value pairs
        for key, value in obj.properties.items():
            # Load property name
            key_idx = self.add_identifier(key)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_u16_bigendian(key_idx)
            self.code.emit(OP_PUSH)
            
            # Load property value
            value_offset = self.add_string(value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16_bigendian(value_offset)
            self.code.emit(OP_PUSH)
            
        # 5. OP_CREATE_OBJECT with 6 parameters
        self.code.emit(OP_CREATE_OBJECT)
        
        # Parameter 1: parentObject (StringTableEntry hash)
        parent_idx = self.add_identifier("") if obj.parent == 0 else obj.parent
        self.code.emit_u16_bigendian(parent_idx)
        
        # Parameter 2: isDatablock
        self.code.emit(1 if obj.is_datablock else 0)
        
        # Parameter 3: isInternal
        self.code.emit(1 if obj.is_internal else 0)
        
        # Parameter 4: isSingleton
        self.code.emit(1 if obj.is_singleton else 0)
        
        # Parameter 5: lineNumber
        self.code.emit(0)  # TODO: Track line numbers
        
        # Parameter 6: failJump (will be patched)
        fail_ip_index = self.code.get_code_index()
        self.code.emit(0)
        
        # 7. OP_ADD_OBJECT
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(1)  # placeAtRoot = 1 for top-level objects
        
        # 8. OP_END_OBJECT
        self.code.emit(OP_END_OBJECT)
        self.code.emit(1)  # placeAtRoot = 1 for top-level objects
        
        # Patch fail jump to point after OP_END_OBJECT
        fail_ip = self.code.get_code_index()
        self.code.patch(fail_ip_index, fail_ip)
        
        # NOTE: Torque3D emits OP_FINISH_OBJECT here, but Scarface REMOVED it!
        
    def compile_method_call(self, call: MethodCall):
        """
        Compile method call
        Based on: Torque3D astNodes.cpp FuncCallExprNode::compile()
        
        SEQUENCE:
        1. OP_PUSHFRAME
        2. Load object variable → OP_PUSH (implicit 'this' parameter)
        3. For each argument: compile → OP_PUSH
        4. OP_CALLFUNC with callType = 1 (MethodCall)
        5. OP_STR_TO_NONE if return value not used
        """
        # 1. OP_PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # 2. Load object as first argument
        obj_var_idx = self.add_identifier(call.object_var)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_u16_bigendian(obj_var_idx)
        self.code.emit(OP_LOADVAR_STR)
        self.code.emit(OP_PUSH)
        
        # 3. Push all arguments
        for arg in call.arguments:
            self.compile_expression(arg)
            self.code.emit(OP_PUSH)
            
        # 4. OP_CALLFUNC
        method_idx = self.add_identifier(call.method_name)
        namespace_idx = self.add_identifier("")  # Empty namespace
        
        self.code.emit(OP_CALLFUNC)
        self.code.emit_u16_bigendian(method_idx)
        self.code.emit_u16_bigendian(namespace_idx)
        self.code.emit(1)  # callType = 1 (MethodCall)
        
        # 5. Discard return value
        self.code.emit(OP_STR_TO_NONE)
        
    def compile_function_call(self, call: FunctionCall):
        """
        Compile function call
        """
        # OP_PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # Push all arguments
        for arg in call.arguments:
            self.compile_expression(arg)
            self.code.emit(OP_PUSH)
            
        # OP_CALLFUNC
        func_idx = self.add_identifier(call.function_name)
        namespace_idx = self.add_identifier(call.namespace) if call.namespace else self.add_identifier("")
        
        self.code.emit(OP_CALLFUNC)
        self.code.emit_u16_bigendian(func_idx)
        self.code.emit_u16_bigendian(namespace_idx)
        self.code.emit(0)  # callType = 0 (FunctionCall)
        
    def compile_variable_assignment(self, assign: VariableAssignment):
        """
        Compile variable assignment
        """
        # Compile value expression
        self.compile_expression(assign.value)
        
        # Set current variable
        var_idx = self.add_identifier(assign.var_name)
        if assign.create:
            self.code.emit(OP_SETCURVAR_CREATE)
        else:
            self.code.emit(OP_SETCURVAR)
        self.code.emit_u16_bigendian(var_idx)
        
        # Save to variable
        self.code.emit(OP_SAVEVAR_STR)  # TODO: Handle other types
        
    def compile_return(self, ret: ReturnStatement):
        """
        Compile return statement
        """
        if ret.value:
            # Compile return value
            self.compile_expression(ret.value)
        else:
            # Return empty string
            empty_offset = self.add_string("")
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16_bigendian(empty_offset)
            
        self.code.emit(OP_RETURN)
        
    def compile_if_statement(self, if_stmt: IfStatement):
        """
        Compile if statement
        """
        # Compile condition
        self.compile_expression(if_stmt.condition)
        
        # OP_JMPIFNOT to else block
        self.code.emit(OP_JMPIFNOT)
        else_ip_index = self.code.get_code_index()
        self.code.emit(0)  # Will be patched
        
        # Compile then block
        for stmt in if_stmt.then_body:
            self.compile_statement(stmt)
            
        # OP_JMP to end
        self.code.emit(OP_JMP)
        end_ip_index = self.code.get_code_index()
        self.code.emit(0)  # Will be patched
        
        # Patch else_ip
        else_ip = self.code.get_code_index()
        self.code.patch(else_ip_index, else_ip)
        
        # Compile else block if present
        if if_stmt.else_body:
            for stmt in if_stmt.else_body:
                self.compile_statement(stmt)
                
        # Patch end_ip
        end_ip = self.code.get_code_index()
        self.code.patch(end_ip_index, end_ip)
        
    def compile_while_statement(self, while_stmt: WhileStatement):
        """
        Compile while loop
        """
        # Mark start of loop
        start_ip = self.code.get_code_index()
        
        # Compile condition
        self.compile_expression(while_stmt.condition)
        
        # OP_JMPIFNOT to end
        self.code.emit(OP_JMPIFNOT)
        end_ip_index = self.code.get_code_index()
        self.code.emit(0)  # Will be patched
        
        # Compile body
        for stmt in while_stmt.body:
            self.compile_statement(stmt)
            
        # OP_JMP back to start
        self.code.emit(OP_JMP)
        self.code.emit(start_ip)
        
        # Patch end_ip
        end_ip = self.code.get_code_index()
        self.code.patch(end_ip_index, end_ip)
        
    def compile_expression(self, expr: ASTNode):
        """
        Compile expression (pushes result to STR stack)
        """
        if isinstance(expr, StringLiteral):
            offset = self.add_string(expr.value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16_bigendian(offset)
            
        elif isinstance(expr, IntegerLiteral):
            self.code.emit(OP_LOADIMMED_UINT)
            self.code.emit_u32(expr.value)
            self.code.emit(OP_UINT_TO_STR)
            
        elif isinstance(expr, FloatLiteral):
            idx = self.add_float(expr.value)
            self.code.emit(OP_LOADIMMED_FLT)
            self.code.emit_u32(idx)
            self.code.emit(OP_FLT_TO_STR)
            
        elif isinstance(expr, VariableRef):
            var_idx = self.add_identifier(expr.var_name)
            self.code.emit(OP_SETCURVAR)
            self.code.emit_u16_bigendian(var_idx)
            self.code.emit(OP_LOADVAR_STR)
            
        elif isinstance(expr, BinaryOp):
            self.compile_binary_op(expr)
            
        elif isinstance(expr, ObjectCreation):
            # Object creation can be used as expression
            # Pushes object ID to UINT stack, then convert to STR
            self.code.emit(OP_LOADIMMED_UINT)
            self.code.emit(0)  # Parent = 0
            self.compile_object_creation(expr)
            self.code.emit(OP_UINT_TO_STR)
            
        else:
            raise ValueError(f"Unknown expression type: {type(expr)}")
            
    def compile_binary_op(self, op: BinaryOp):
        """
        Compile binary operation
        """
        # Compile left side
        self.compile_expression(op.left)
        
        # Convert to appropriate type (default float for arithmetic)
        if op.operator in ['+', '-', '*', '/', '%']:
            self.code.emit(OP_STR_TO_FLT)
            
        # Compile right side
        self.compile_expression(op.right)
        
        # Convert to appropriate type
        if op.operator in ['+', '-', '*', '/', '%']:
            self.code.emit(OP_STR_TO_FLT)
            
        # Emit operator
        op_map = {
            '+': OP_ADD, '-': OP_SUB, '*': OP_MUL, '/': OP_DIV, '%': OP_MOD,
            '==': OP_CMPEQ, '!=': OP_CMPNE, '<': OP_CMPLT, '<=': OP_CMPLE,
            '>': OP_CMPGR, '>=': OP_CMPGE,
            '&&': OP_AND, '||': OP_OR,
            '&': OP_BITAND, '|': OP_BITOR, '^': OP_XOR,
            '<<': OP_SHL, '>>': OP_SHR
        }
        
        if op.operator in op_map:
            self.code.emit(op_map[op.operator])
        else:
            raise ValueError(f"Unknown operator: {op.operator}")
            
        # Convert result back to string
        if op.operator in ['+', '-', '*', '/', '%']:
            self.code.emit(OP_FLT_TO_STR)
            
    def compile_statement(self, stmt: ASTNode):
        """
        Compile a statement
        """
        if isinstance(stmt, FunctionDecl):
            self.compile_function(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, VariableAssignment):
            self.compile_variable_assignment(stmt)
        elif isinstance(stmt, ReturnStatement):
            self.compile_return(stmt)
        elif isinstance(stmt, IfStatement):
            self.compile_if_statement(stmt)
        elif isinstance(stmt, WhileStatement):
            self.compile_while_statement(stmt)
        else:
            raise ValueError(f"Unknown statement type: {type(stmt)}")
            
    # ==========================================================================
    # CSO FILE GENERATION
    # ==========================================================================
    
    def generate_cso(self) -> bytes:
        """
        Generate CSO file bytes
        """
        # Build all tables
        func_string_bytes = self.function_strings.get_bytes()
        string_bytes = self.string_table.get_bytes()
        float_bytes = self.float_table.get_bytes()
        code_bytes = bytes(self.code.codes)
        
        # Build global string table (empty for now)
        global_string_bytes = b'\x00'
        
        # Build header
        result = b''
        
        # Version (1)
        result += struct.pack('<I', 1)
        
        # Function string table size
        result += struct.pack('<I', len(func_string_bytes))
        
        # Function string table
        result += func_string_bytes
        
        # Separator
        result += b'\x00\x00\x00\x00'
        
        # String table size
        result += struct.pack('<I', len(string_bytes))
        
        # String table
        result += string_bytes
        
        # Separator
        result += b'\x00\x00\x00\x00'
        
        # Float table size
        result += struct.pack('<I', len(float_bytes))
        
        # Float table
        result += float_bytes
        
        # Separator
        result += b'\x00\x00\x00\x00'
        
        # Global string table size
        result += struct.pack('<I', len(global_string_bytes))
        
        # Global string table
        result += global_string_bytes
        
        # Separator
        result += b'\x00\x00\x00\x00'
        
        # Code size
        result += struct.pack('<I', len(code_bytes))
        
        # Code
        result += code_bytes
        
        return result

# ==============================================================================
# EXAMPLE USAGE
# ==============================================================================

def test_simple_function():
    """Test compiling a simple function"""
    compiler = CSOCompiler()
    
    # Create simple function: function test() { return "Hello"; }
    func = FunctionDecl(
        name="test",
        namespace="",
        package="",
        params=[],
        body=[
            ReturnStatement(StringLiteral("Hello"))
        ]
    )
    
    compiler.compile_function(func)
    
    cso_bytes = compiler.generate_cso()
    
    with open('/home/claude/scarface_project/test_v19_simple.cso', 'wb') as f:
        f.write(cso_bytes)
        
    print(f"✓ Generated test_v19_simple.cso ({len(cso_bytes)} bytes)")

def test_object_creation():
    """Test compiling object creation"""
    compiler = CSOCompiler()
    
    # Create function with object creation
    func = FunctionDecl(
        name="test",
        namespace="",
        package="",
        params=[],
        body=[
            ObjectCreation(
                class_name="ActionMap",
                object_name="",
                properties={
                    "Name": "GlobalActionMap"
                }
            ),
            ReturnStatement(None)
        ]
    )
    
    compiler.compile_function(func)
    
    cso_bytes = compiler.generate_cso()
    
    with open('/home/claude/scarface_project/test_v19_object.cso', 'wb') as f:
        f.write(cso_bytes)
        
    print(f"✓ Generated test_v19_object.cso ({len(cso_bytes)} bytes)")

def test_method_call():
    """Test compiling method call"""
    compiler = CSOCompiler()
    
    # Create function with object creation and method call
    func = FunctionDecl(
        name="test",
        namespace="",
        package="",
        params=[],
        body=[
            VariableAssignment(
                var_name="obj",
                value=ObjectCreation(
                    class_name="ActionMap",
                    object_name="",
                    properties={"Name": "GlobalActionMap"}
                ),
                create=True
            ),
            MethodCall(
                object_var="obj",
                method_name="bind",
                arguments=[
                    StringLiteral("keyboard"),
                    StringLiteral("escape"),
                    StringLiteral("quit();")
                ]
            ),
            ReturnStatement(VariableRef("obj"))
        ]
    )
    
    compiler.compile_function(func)
    
    cso_bytes = compiler.generate_cso()
    
    with open('/home/claude/scarface_project/test_v19_method.cso', 'wb') as f:
        f.write(cso_bytes)
        
    print(f"✓ Generated test_v19_method.cso ({len(cso_bytes)} bytes)")

if __name__ == "__main__":
    print("="*60)
    print("SCARFACE CSO RECOMPILER V19 - FINAL EDITION")
    print("="*60)
    print()
    
    test_simple_function()
    test_object_creation()
    test_method_call()
    
    print()
    print("✓ All test files generated!")
    print("="*60)
