// config.cs - MOD LOADER
// This file is loaded and compiled by the game automatically!
// Found in startup.cso line 76: stxfaflihej("script/config.cs", ...)
// And line 208: stxgcoimgjk("script/config.cs", "Script", "Dbg");

echo("==============================================");
echo("SCARFACE MOD LOADER - CONFIG.CS");
echo("==============================================");
echo("");

// Check if mods directory exists
if (isFile("script/mods/loader.cs"))
{
    echo("Loading mods from script/mods/...");
    exec("script/mods/loader.cs");
}
else
{
    echo("No mods found (script/mods/loader.cs doesn't exist)");
    echo("");
    echo("To add mods:");
    echo("1. Create script/mods/ folder");
    echo("2. Create script/mods/loader.cs");
    echo("3. Add your mod files");
    echo("");
}

echo("==============================================");
echo("");

// You can also put configuration here
$Pref::Audio::MasterVolume = 1.0;
$Pref::Video::FullScreen = true;

// Custom keybinds (if needed)
// bind("keyboard", "f5", "ReExecScript(\"script/config.cs\");");

// Debug mode
$Debug::Enabled = false;

// Your custom global settings
$ModLoader::Version = "1.0";
$ModLoader::Enabled = true;

echo("Config loaded successfully!");
