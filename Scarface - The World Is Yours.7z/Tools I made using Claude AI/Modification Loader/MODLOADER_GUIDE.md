# 🎮 SCARFACE MOD LOADER - Complete Guide

## 📋 Overview

The Scarface Mod Loader allows you to create and inject custom TorqueScript mods into Scarface: The World Is Yours without modifying the game's executable. It works by:

1. **Compiling** `.cs` (TorqueScript) files to `.cso` (bytecode) format
2. **Injecting** compiled scripts into the game's script loading system
3. **Hot-reloading** scripts while the game is running (optional)

---

## 🔬 How Scarface Loads Scripts

Based on analysis of `startup.cso` and `scriptload.cso`:

### Startup Sequence

```
Game Launch
    ↓
startup.cso loaded
    ↓
stxmljcojip() function called
    ↓
┌─────────────────────────────────────────┐
│ 1. Load StartupScripts.p3d             │ ← P3D package
│ 2. Load actionmaps_<platform>.cs       │ ← Individual script
│ 3. Load various system scripts         │
└─────────────────────────────────────────┘
    ↓
stxhkeiomci() function called
    ↓
┌─────────────────────────────────────────┐
│ 1. Load GUI scripts                    │
│ 2. Load gameplay scripts               │
│ 3. Load mission scripts                │
│ 4. Create game objects                 │
└─────────────────────────────────────────┘
```

### Script Loading Functions

| Obfuscated Name | Likely Function | Purpose |
|----------------|-----------------|---------|
| `stxfaflihej()` | `ResourceManager::load()` | Load script from P3D package |
| `stxgcoimgjk()` | `Con::executef()` | Execute individual .cs file |
| `stxapdemhcj()` | `ResourceManager::loadP3D()` | Load P3D package |

---

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or download the mod loader
git clone <repo-url>
cd scarface-modloader

# Install dependencies
pip install watchdog
```

### 2. Create Your First Mod

Create a file `mods/test_mod.cs`:

```torquescript
// test_mod.cs - My first Scarface mod

function myCustomFunction()
{
    echo("Hello from my mod!");
    return "Mod loaded successfully!";
}

// Hook into game startup
function onStartup()
{
    echo("Test mod initialized!");
    myCustomFunction();
}
```

### 3. Run the Mod Loader

```bash
python scarface_modloader.py --game-dir "C:/Program Files/Scarface" --mods-dir "./mods"
```

### 4. Launch Scarface

The mod loader will:
- Compile your `.cs` file to `.cso` bytecode
- Inject it into the game's script system
- Your mod is now active!

---

## 📚 Advanced Usage

### Hot-Reload Mode

Watch for file changes and recompile automatically:

```bash
python scarface_modloader.py --game-dir "C:/Games/Scarface" --mods-dir "./mods" --watch
```

Now you can edit your `.cs` files while the game is running, and they'll be recompiled automatically!

### Injection Methods

The mod loader supports three injection strategies:

#### A. Pre-Load Injection (Default)

Replaces game scripts before loading:

```python
loader = ScarfaceModLoader(game_dir, mods_dir)
loader.inject_mod_preload(cso_file, "config.cs")
```

**Pros**: Simple, reliable  
**Cons**: Replaces existing scripts

#### B. P3D Package Injection

Creates custom P3D package:

```python
loader.create_mod_p3d([cso1, cso2, cso3], "MyMods.p3d")
```

**Pros**: No file replacement, multiple mods in one package  
**Cons**: Requires modifying startup sequence

#### C. Startup Injection

Modifies `startup.cso` directly:

```python
loader.inject_mod_startup(cso_file)
```

**Pros**: Loads at game initialization  
**Cons**: Most complex, requires startup.cso modification

---

## 🔧 Mod Structure

### Simple Function Mod

```torquescript
// mods/my_functions.cs

function calculateDamage(%weapon, %distance)
{
    %baseDamage = 100;
    %distanceMod = 1.0 - (%distance / 100.0);
    return %baseDamage * %distanceMod;
}
```

### Object Creation Mod

```torquescript
// mods/custom_vehicle.cs

datablock VehicleData(CustomCar)
{
    category = "Vehicles";
    shapeFile = "art/shapes/vehicles/custom_car.dts";
    maxSpeed = 120.0;
    acceleration = 50.0;
};

function spawnCustomCar(%position)
{
    %car = new Vehicle() {
        dataBlock = CustomCar;
        position = %position;
    };
    return %car;
}
```

### Mission Hook Mod

```torquescript
// mods/mission_tweaks.cs

// Hook into existing mission
package MissionTweaks
{
    function Mission::start(%this)
    {
        Parent::start(%this);
        echo("Mission started with mods!");
        
        // Add custom logic
        %this.customReward = 10000;
    }
    
    function Mission::complete(%this)
    {
        Parent::complete(%this);
        
        // Give custom reward
        Player.addMoney(%this.customReward);
        echo("Custom reward awarded!");
    }
};

activatePackage(MissionTweaks);
```

---

## 🎯 Script Injection Targets

Based on analysis of `startup.cso`, here are key injection points:

### Early Startup Scripts

| Script | Purpose | Injection Timing |
|--------|---------|-----------------|
| `startup.cso` | Main startup | Before any other scripts |
| `scriptload.cso` | Script loader | Defines script loading order |
| `actionmaps.cs` | Input bindings | Early, before GUI |
| `config.cs` | Game configuration | Early, configuration phase |

### Gameplay Scripts

| Script | Purpose | Category |
|--------|---------|----------|
| `missions/*.cs` | Mission definitions | Mission System |
| `characters/*.cs` | Character AI | AI System |
| `vehicles/*.cs` | Vehicle physics | Vehicle System |
| `worldgameplay/*.cs` | Game mechanics | Gameplay |

### GUI Scripts

| Script | Purpose | Category |
|--------|---------|----------|
| `gui/hud/*.cs` | HUD elements | Interface |
| `gui/pause.cs` | Pause menu | Menu System |
| `gui/util.cs` | GUI utilities | Utilities |

---

## 🛠️ Creating Complex Mods

### Multi-File Mod Example

```
mods/
└── advanced_mod/
    ├── main.cs              # Entry point
    ├── functions.cs         # Utility functions
    ├── objects.cs           # Custom objects
    ├── missions.cs          # Mission modifications
    └── README.md            # Mod documentation
```

**main.cs**:
```torquescript
// Load other mod files
exec("./mods/advanced_mod/functions.cs");
exec("./mods/advanced_mod/objects.cs");
exec("./mods/advanced_mod/missions.cs");

function initAdvancedMod()
{
    echo("=== Advanced Mod Loading ===");
    
    // Initialize components
    setupCustomObjects();
    registerMissionHooks();
    
    echo("=== Advanced Mod Loaded ===");
}

// Auto-execute on load
initAdvancedMod();
```

---

## 🔍 Debugging

### Enable Debug Output

```torquescript
// In your mod
$Debug::Enabled = true;

function myFunction()
{
    if ($Debug::Enabled)
        echo("Debug: myFunction called");
        
    // Function code...
}
```

### View Compiled Bytecode

```bash
# Examine generated CSO file
python3 << 'EOF'
import sys
sys.path.append('./BrokenFace-master\'s File Extractor')
from brokenface import decompile

result = decompile("cache/my_mod_abc123.cso")
print(result)
EOF
```

### Common Issues

**Issue**: Mod doesn't load  
**Solution**: Check that CSO was generated in cache directory

**Issue**: Game crashes on startup  
**Solution**: Your script has syntax errors. Test compilation:
```bash
python cso_recompiler_v19_final.py
```

**Issue**: Changes not reflected in game  
**Solution**: Use `--watch` mode for hot-reload

---

## 🎨 Example Mods

### Infinite Money Mod

```torquescript
// mods/infinite_money.cs

function Player::addMoney(%this, %amount)
{
    // Always add 999999 instead of actual amount
    %this.money = %this.money + 999999;
    echo("Money added: 999999 (infinite money active)");
}
```

### Super Speed Mod

```torquescript
// mods/super_speed.cs

function Player::setSpeed(%this, %speed)
{
    // Multiply speed by 3
    %actualSpeed = %speed * 3.0;
    Parent::setSpeed(%this, %actualSpeed);
    echo("Speed set to: " @ %actualSpeed);
}
```

### Custom Weapon Mod

```torquescript
// mods/custom_weapon.cs

datablock ItemData(CustomRPG)
{
    category = "Weapons";
    shapeFile = "art/shapes/weapons/rpg.dts";
    
    // Weapon properties
    damage = 500;
    range = 1000;
    fireDelay = 1000;
    ammoCapacity = 10;
};

function giveCustomWeapon(%player)
{
    %player.mountImage(CustomRPG.image, 0);
    echo("Custom weapon equipped!");
}
```

---

## 🔐 Safety & Backups

The mod loader automatically backs up original files before modification:

```
backups/
├── startup.cso.backup
├── config.cs.backup
└── actionmaps.cs.backup
```

### Restore Original Files

```bash
python scarface_modloader.py --restore
```

This will restore all backed up files to their original locations.

---

## 🏗️ Architecture

### File Flow

```
[Your .cs file] 
       ↓
[TorqueScript Parser] ← TODO: Full implementation
       ↓
[AST Generation]
       ↓
[CSO Compiler] ← cso_recompiler_v19_final.py
       ↓
[CSO Bytecode]
       ↓
[Injection Strategy]
       ↓
[Game Loads Modified Script]
```

### Compiler Pipeline

```python
# 1. Parse TorqueScript
ast = parse_torquescript(cs_file)

# 2. Compile to bytecode
compiler = CSOCompiler()
for node in ast:
    compiler.compile_statement(node)

# 3. Generate CSO
cso_bytes = compiler.generate_cso()

# 4. Inject into game
inject_mod(cso_bytes, target_script)
```

---

## 📖 TorqueScript Reference

### Variable Types

```torquescript
$globalVar = "value";      // Global variable
%localVar = "value";       // Local variable
%this.field = "value";     // Object field
$array[0] = "value";       // Array element
```

### Function Definition

```torquescript
function myFunction(%param1, %param2)
{
    %result = %param1 + %param2;
    return %result;
}
```

### Object Creation

```torquescript
%obj = new SimObject() {
    name = "MyObject";
    value = 123;
};
```

### Control Flow

```torquescript
if (%condition)
{
    // Code
}
else
{
    // Code
}

while (%i < 10)
{
    %i++;
}

for (%i = 0; %i < 10; %i++)
{
    // Code
}
```

---

## 🔬 Technical Details

### CSO File Format

```
[Header]
- Version: 4 bytes (0x00000001)
- Function String Table Size: 4 bytes
- Function String Table: variable (null-terminated strings)
- Separator: 4 bytes (0x00000000)

[String Table]
- Size: 4 bytes
- Strings: variable (null-terminated strings)
- Separator: 4 bytes

[Float Table]
- Size: 4 bytes
- Floats: variable (8-byte doubles)
- Separator: 4 bytes

[Global String Table]
- Size: 4 bytes
- Global variable names: variable
- Separator: 4 bytes

[Code Section]
- Size: 4 bytes
- Bytecode: variable (U8 opcodes + parameters)
```

### Opcode Reference

See `SCARFACE_OPCODE_REFERENCE.md` for complete list of 86 opcodes.

Key opcodes:
- `0x00`: OP_FUNC_DECL - Function declaration
- `0x01`: OP_CREATE_OBJECT - Create object
- `0x4B`: OP_CALLFUNC - Call function
- `0x47`: OP_LOADIMMED_STR - Load string literal
- `0x0D`: OP_RETURN - Return from function

---

## 🤝 Contributing

Want to improve the mod loader? Here's what needs work:

### TODO List

- [ ] Full TorqueScript parser (currently creates dummy functions)
- [ ] Control flow support (if/while/for)
- [ ] Package system support
- [ ] Datablock parsing
- [ ] Expression parser
- [ ] Method call support
- [ ] String concatenation
- [ ] Array operations
- [ ] Better error messages
- [ ] GUI for mod management
- [ ] Mod dependency system

### Parser Implementation

The biggest missing piece is a full TorqueScript parser. Currently, we only compile simple test functions. Here's what's needed:

```python
# TODO: Implement full parser
def parse_torquescript(cs_file: Path) -> List[ASTNode]:
    """
    Parse TorqueScript file into AST
    
    Should handle:
    - Function declarations
    - Object creation
    - Variable assignments
    - Control flow (if/while/for)
    - Expressions
    - Method calls
    - Packages
    - Datablocks
    """
    with open(cs_file, 'r') as f:
        source = f.read()
        
    # Tokenize
    tokens = tokenize(source)
    
    # Parse
    ast = Parser(tokens).parse()
    
    return ast
```

---

## 📞 Support

Having issues? Check these resources:

1. **Decompiled Scripts**: Look at `Start-Up .cso Scripts/*.cs` for examples
2. **Opcode Reference**: `SCARFACE_OPCODE_REFERENCE.md`
3. **Compilation Guide**: `SCARFACE_COMPILATION_GUIDE.md`
4. **Torque3D Source**: Study `source/console/astNodes.cpp`

---

## ⚖️ Legal

This tool is for educational purposes and personal use only. Scarface: The World Is Yours is property of Radical Entertainment and Vivendi Universal Games. This mod loader does not distribute or modify the game's executable or assets, only scripts.

---

## 🎉 Credits

- **Torque3D** - Open source game engine
- **BrokenFace** - CSO decompiler
- **stwiy-lib** - Scarface VM implementation
- **Pure3D** - File format documentation

---

Happy modding! 🎮
