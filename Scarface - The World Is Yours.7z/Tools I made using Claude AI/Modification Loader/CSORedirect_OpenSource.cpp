// CSORedirect_OpenSource.cpp
// Open-source script redirection system for Scarface: The World Is Yours
// 
// This ASI/DLL hooks the game's script loading function and redirects
// .cso (compiled) files to .cs (source) alternatives, allowing you to
// mod the game with plain text TorqueScript files!
//
// License: MIT
// Author: Community contribution
// Based on: Analysis of Soon's CSORedirect.asi

#include <windows.h>
#include <stdio.h>
#include <string>
#include <map>
#include <fstream>
#include <detours.h>  // Microsoft Detours for hooking

// ============================================================================
// CONFIGURATION
// ============================================================================

#define LOG_FILE "CSORedirect_log.txt"
#define CONFIG_FILE "plugins\\CSORedirect.json"

// Enable/disable features
#define ENABLE_LOGGING 1
#define ENABLE_CONSOLE_OUTPUT 1

// ============================================================================
// GLOBAL STATE
// ============================================================================

// Mapping of .cso paths to .cs alternatives
std::map<std::string, std::string> g_redirections;

// Original function pointer
typedef void* (*ResourceLoad_t)(const char* path, const char* type, const char* heap, int mode);
ResourceLoad_t g_OriginalResourceLoad = nullptr;

// Log file
FILE* g_LogFile = nullptr;

// ============================================================================
// LOGGING
// ============================================================================

void Log(const char* format, ...)
{
    if (!ENABLE_LOGGING) return;
    
    // Open log file if needed
    if (!g_LogFile)
    {
        g_LogFile = fopen(LOG_FILE, "w");
        if (!g_LogFile) return;
        
        fprintf(g_LogFile, "===========================================\n");
        fprintf(g_LogFile, "CSORedirect Open-Source v1.0\n");
        fprintf(g_LogFile, "===========================================\n\n");
    }
    
    // Write to log
    va_list args;
    va_start(args, format);
    vfprintf(g_LogFile, format, args);
    va_end(args);
    
    fflush(g_LogFile);
    
    // Also output to console if enabled
#if ENABLE_CONSOLE_OUTPUT
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
#endif
}

// ============================================================================
// CONFIGURATION LOADING
// ============================================================================

void LoadSimpleConfig(const char* filename)
{
    /*
    Simple config format:
    
    scriptc/config.cso=script/config.cs
    scriptc/missions.cso=script/mods/missions.cs
    
    One mapping per line, format: FROM=TO
    Lines starting with # are comments
    */
    
    Log("Loading configuration from: %s\n", filename);
    
    FILE* f = fopen(filename, "r");
    if (!f)
    {
        Log("WARNING: Config file not found, creating default...\n");
        
        // Create default config
        f = fopen(filename, "w");
        if (f)
        {
            fprintf(f, "# CSORedirect Configuration\n");
            fprintf(f, "# Format: scriptc/file.cso=script/file.cs\n");
            fprintf(f, "#\n");
            fprintf(f, "# Examples:\n");
            fprintf(f, "# scriptc/config.cso=script/config.cs\n");
            fprintf(f, "# scriptc/missions.cso=script/mods/missions.cs\n");
            fprintf(f, "\n");
            fclose(f);
        }
        return;
    }
    
    // Read mappings
    char line[512];
    int lineNum = 0;
    
    while (fgets(line, sizeof(line), f))
    {
        lineNum++;
        
        // Remove newline
        line[strcspn(line, "\r\n")] = 0;
        
        // Skip empty lines and comments
        if (line[0] == 0 || line[0] == '#')
            continue;
            
        // Find '=' separator
        char* equals = strchr(line, '=');
        if (!equals)
        {
            Log("WARNING: Line %d invalid (no '='): %s\n", lineNum, line);
            continue;
        }
        
        // Split into from/to
        *equals = 0;
        std::string from = line;
        std::string to = equals + 1;
        
        // Trim whitespace
        from.erase(0, from.find_first_not_of(" \t"));
        from.erase(from.find_last_not_of(" \t") + 1);
        to.erase(0, to.find_first_not_of(" \t"));
        to.erase(to.find_last_not_of(" \t") + 1);
        
        if (from.empty() || to.empty())
        {
            Log("WARNING: Line %d invalid (empty): %s\n", lineNum, line);
            continue;
        }
        
        // Add mapping
        g_redirections[from] = to;
        Log("  %s -> %s\n", from.c_str(), to.c_str());
    }
    
    fclose(f);
    Log("Loaded %d redirections\n\n", (int)g_redirections.size());
}

// ============================================================================
// SCRIPT LOADING HOOK
// ============================================================================

void* HookedResourceLoad(const char* path, const char* type, const char* heap, int mode)
{
    // Log the call
    Log("ResourceLoad called: path=%s, type=%s\n", path, type);
    
    // Check if this path should be redirected
    std::string pathStr = path;
    
    // Check exact match first
    auto it = g_redirections.find(pathStr);
    if (it != g_redirections.end())
    {
        const char* newPath = it->second.c_str();
        Log("  REDIRECT: %s -> %s\n", path, newPath);
        
        // Call original function with new path
        return g_OriginalResourceLoad(newPath, type, heap, mode);
    }
    
    // Check if path ends with .cso
    if (pathStr.length() > 4 && pathStr.substr(pathStr.length() - 4) == ".cso")
    {
        // Try automatic .cso -> .cs conversion
        std::string csPath = pathStr.substr(0, pathStr.length() - 4) + ".cs";
        
        // Replace scriptc/ with script/
        size_t pos = csPath.find("scriptc/");
        if (pos != std::string::npos)
        {
            csPath.replace(pos, 8, "script/");
            
            Log("  AUTO-REDIRECT: %s -> %s\n", path, csPath.c_str());
            
            // Try loading .cs version
            return g_OriginalResourceLoad(csPath.c_str(), type, heap, mode);
        }
    }
    
    // No redirection, call original
    return g_OriginalResourceLoad(path, type, heap, mode);
}

// ============================================================================
// FUNCTION FINDING
// ============================================================================

DWORD_PTR FindResourceLoadFunction()
{
    /*
    Find the ResourceManager::load or similar function
    
    Method 1: Scan for string references
    Method 2: Scan for function pattern
    Method 3: Exported functions (unlikely)
    */
    
    Log("Searching for script loading function...\n");
    
    HMODULE hGame = GetModuleHandleA(nullptr);
    if (!hGame)
    {
        Log("ERROR: Cannot get game module!\n");
        return 0;
    }
    
    // Get module info
    MODULEINFO modInfo;
    if (!GetModuleInformation(GetCurrentProcess(), hGame, &modInfo, sizeof(MODULEINFO)))
    {
        Log("ERROR: Cannot get module info!\n");
        return 0;
    }
    
    BYTE* base = (BYTE*)hGame;
    DWORD size = modInfo.SizeOfImage;
    
    Log("  Module base: 0x%p\n", base);
    Log("  Module size: 0x%X\n", size);
    
    // PATTERN SCANNING
    // Look for function signature (this is a guess, needs testing)
    // Typical TorqueScript load function might start with:
    // push ebp
    // mov ebp, esp
    // sub esp, XX
    
    BYTE pattern[] = { 0x55, 0x8B, 0xEC, 0x83, 0xEC };  // push ebp; mov ebp,esp; sub esp,XX
    
    for (DWORD i = 0; i < size - sizeof(pattern); i++)
    {
        if (memcmp(base + i, pattern, sizeof(pattern)) == 0)
        {
            // Found potential function!
            // Verify it's the right one by checking nearby strings
            
            // For now, just return first match (needs refinement)
            DWORD_PTR addr = (DWORD_PTR)(base + i);
            Log("  Found potential function at: 0x%p\n", (void*)addr);
            
            // TODO: Add verification logic
            
            return addr;
        }
    }
    
    Log("ERROR: Function not found!\n");
    return 0;
}

// ============================================================================
// HOOKING SETUP
// ============================================================================

BOOL InstallHooks()
{
    Log("Installing hooks...\n");
    
    // Find the target function
    DWORD_PTR funcAddr = FindResourceLoadFunction();
    if (funcAddr == 0)
    {
        Log("ERROR: Cannot find function to hook!\n");
        
        // Try hardcoded address (game-version specific)
        // This needs to be found via reverse engineering
        // funcAddr = 0x????????;  // FILL THIS IN!
        
        Log("NOTE: You need to find the function address manually!\n");
        Log("      Use a debugger to find ResourceManager::load or similar\n");
        Log("      Then update the code with the correct address\n");
        return FALSE;
    }
    
    g_OriginalResourceLoad = (ResourceLoad_t)funcAddr;
    
    // Install hook using Detours
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach((PVOID*)&g_OriginalResourceLoad, HookedResourceLoad);
    
    LONG error = DetourTransactionCommit();
    if (error != NO_ERROR)
    {
        Log("ERROR: Hook installation failed! Error: %ld\n", error);
        return FALSE;
    }
    
    Log("Hooks installed successfully!\n\n");
    return TRUE;
}

void RemoveHooks()
{
    if (g_OriginalResourceLoad)
    {
        DetourTransactionBegin();
        DetourUpdateThread(GetCurrentThread());
        DetourDetach((PVOID*)&g_OriginalResourceLoad, HookedResourceLoad);
        DetourTransactionCommit();
    }
}

// ============================================================================
// DLL ENTRY POINT
// ============================================================================

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // Initialize
            DisableThreadLibraryCalls(hinstDLL);
            
            Log("===========================================\n");
            Log("CSORedirect Open-Source v1.0\n");
            Log("===========================================\n\n");
            
            // Load configuration
            LoadSimpleConfig(CONFIG_FILE);
            
            // Install hooks (in a separate thread to avoid deadlock)
            CreateThread(nullptr, 0, [](LPVOID) -> DWORD {
                Sleep(1000);  // Wait for game to initialize
                InstallHooks();
                return 0;
            }, nullptr, 0, nullptr);
            
            break;
            
        case DLL_PROCESS_DETACH:
            // Cleanup
            RemoveHooks();
            
            if (g_LogFile)
            {
                fclose(g_LogFile);
                g_LogFile = nullptr;
            }
            break;
    }
    
    return TRUE;
}

// ============================================================================
// ALTERNATIVE: SIMPLER APPROACH WITHOUT HOOKING
// ============================================================================

/*
If hooking doesn't work, we can use file system redirection:

1. Intercept CreateFileA/CreateFileW
2. Check if file ends with .cso
3. Redirect to .cs version
4. Let game compile it

This is simpler and more reliable!

See below for implementation...
*/

// Original file functions
typedef HANDLE (WINAPI *CreateFileA_t)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
CreateFileA_t g_OriginalCreateFileA = nullptr;

HANDLE WINAPI HookedCreateFileA(
    LPCSTR lpFileName,
    DWORD dwDesiredAccess,
    DWORD dwShareMode,
    LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    DWORD dwCreationDisposition,
    DWORD dwFlagsAndAttributes,
    HANDLE hTemplateFile)
{
    // Check if it's a .cso file
    const char* ext = strrchr(lpFileName, '.');
    if (ext && strcmp(ext, ".cso") == 0)
    {
        // Try .cs version
        char csPath[MAX_PATH];
        strncpy(csPath, lpFileName, MAX_PATH);
        char* extPos = strrchr(csPath, '.');
        if (extPos)
        {
            strcpy(extPos, ".cs");
            
            // Replace scriptc/ with script/
            char* scriptc = strstr(csPath, "scriptc");
            if (scriptc)
            {
                scriptc[6] = ' ';  // Change 'c' to space
                scriptc[7] = '/';  // Ensure slash
                
                Log("FILE REDIRECT: %s -> %s\n", lpFileName, csPath);
                
                // Try opening .cs file
                HANDLE h = g_OriginalCreateFileA(csPath, dwDesiredAccess, dwShareMode,
                    lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
                    
                if (h != INVALID_HANDLE_VALUE)
                {
                    Log("  SUCCESS!\n");
                    return h;
                }
                
                Log("  FAILED, falling back to .cso\n");
            }
        }
    }
    
    // Call original
    return g_OriginalCreateFileA(lpFileName, dwDesiredAccess, dwShareMode,
        lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
}

// Install file system hooks instead
BOOL InstallFileSystemHooks()
{
    Log("Installing file system hooks...\n");
    
    g_OriginalCreateFileA = CreateFileA;
    
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach((PVOID*)&g_OriginalCreateFileA, HookedCreateFileA);
    
    LONG error = DetourTransactionCommit();
    if (error != NO_ERROR)
    {
        Log("ERROR: File system hook failed!\n");
        return FALSE;
    }
    
    Log("File system hooks installed!\n");
    return TRUE;
}

// ============================================================================
// NOTES
// ============================================================================

/*
COMPILATION:
============
cl /LD /O2 CSORedirect_OpenSource.cpp /link detours.lib /OUT:CSORedirect_OpenSource.asi

Or with CMake:
cmake -B build
cmake --build build --config Release

USAGE:
======
1. Copy CSORedirect_OpenSource.asi to game/plugins/
2. Install Ultimate ASI Loader (dinput8.dll)
3. Create plugins/CSORedirect.json with your redirects
4. Launch game

CONFIG FORMAT:
==============
plugins/CSORedirect.json:
scriptc/config.cso=script/config.cs
scriptc/missions.cso=script/mods/missions.cs

TROUBLESHOOTING:
================
Check CSORedirect_log.txt for:
- Which files are being loaded
- Whether redirects are working
- Any errors

TODO:
=====
- Find actual function address via reverse engineering
- Test with real game
- Add more configuration options
- Improve pattern matching
- Add JSON config support
*/
