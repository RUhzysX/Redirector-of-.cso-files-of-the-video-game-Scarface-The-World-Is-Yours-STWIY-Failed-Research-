# 🎮 SCARFACE MOD LOADER v2.0 - Quick Start Guide

## 🎯 **THE BIG IDEA**

**We don't need our own compiler!** The game ALREADY has a TorqueScript compiler built-in!

The game loads `.cs` files directly and compiles them:
```torquescript
exec("script/mymod.cs");  // Game compiles this!
```

So all we need to do is:
1. Put your `.cs` mods in the game folder
2. Tell the game to load them
3. **BOOM! Game compiles and runs your mods!**

---

## 🚀 Quick Setup (3 Steps!)

### Step 1: Run Setup

```bash
python scarface_modloader_v2.py --game-dir "C:/Games/Scarface" --setup
```

This creates:
- `<game>/script/mods/` folder ← **YOUR MODS GO HERE**
- `loader.cs` that loads all your mods
- Hooks `loader.cs` into `config.cs`
- Creates an example mod

### Step 2: Create Your Mod

Create `<game>/script/mods/my_awesome_mod.cs`:

```torquescript
// my_awesome_mod.cs

echo("My awesome mod loaded!");

function givePlayerMoney()
{
    Player.money = Player.money + 100000;
    echo("Added $100,000!");
}

// Call it
givePlayerMoney();
```

### Step 3: Launch Scarface!

Your mod is now loaded and running! 🎉

---

## 📁 Where Do Mods Go?

```
C:/Games/Scarface/
├── Scarface.exe
└── script/
    ├── config.cs          ← Hooked to load mods
    └── mods/              ← PUT YOUR MODS HERE! 
        ├── loader.cs      ← Auto-generated
        ├── example_mod.cs ← Example
        └── my_mod.cs      ← YOUR MOD!
```

**Just drop `.cs` files in `script/mods/` and the game loads them!**

---

## 🔥 How It Works

### The Game Already Does This:

Looking at `startup.cso`:
```torquescript
stxgcoimgjk("script/config.cs", "Script");  
stxgcoimgjk("script/overlay.cs", "Script");
// etc...
```

`stxgcoimgjk()` = **Load and compile .cs file**

### Our Hook:

We add this to `config.cs`:
```torquescript
exec("script/mods/loader.cs");
```

Then `loader.cs` does:
```torquescript
exec("script/mods/my_mod.cs");      // Loads your mod!
exec("script/mods/another_mod.cs"); // Loads another!
```

**The game compiles everything automatically!**

---

## 💡 Advanced Usage

### Auto-Update Loader (Watch Mode)

```bash
python scarface_modloader_v2.py --game-dir "C:/Games/Scarface" --watch
```

Now:
1. Add/edit mods in `script/mods/`
2. Loader updates automatically
3. Restart game to see changes

### Example Mods

#### Infinite Money
```torquescript
// infinite_money.cs
function Player::addMoney(%this, %amount)
{
    %this.money = %this.money + 999999;
    echo("Money added: 999999 (infinite!)");
}
```

#### Super Speed
```torquescript
// super_speed.cs  
function Player::getMaxSpeed(%this)
{
    return Parent::getMaxSpeed(%this) * 3.0;
}
```

#### Debug Commands
```torquescript
// debug.cs
function godMode()
{
    Player.invincible = true;
    echo("God mode ON!");
}

function killAll()
{
    // Kill all enemies
    %enemy = findFirstObject("Enemy");
    while (isObject(%enemy))
    {
        %enemy.kill();
        %enemy = findNextObject("Enemy");
    }
    echo("All enemies eliminated!");
}
```

---

## 🎮 TorqueScript Basics

### Variables
```torquescript
$global = "value";     // Global variable
%local = "value";      // Local variable  
%obj.field = "value";  // Object field
```

### Functions
```torquescript
function myFunction(%param1, %param2)
{
    %result = %param1 + %param2;
    echo("Result: " @ %result);
    return %result;
}
```

### Console Output
```torquescript
echo("This appears in game console!");
warn("This is a warning!");
error("This is an error!");
```

### Conditionals
```torquescript
if (%health < 50)
{
    echo("Low health!");
}
else
{
    echo("Healthy!");
}
```

### Loops
```torquescript
for (%i = 0; %i < 10; %i++)
{
    echo("Count: " @ %i);
}

while (%condition)
{
    // Do something
}
```

---

## 🔍 Debugging

### Check Console
The game has a console (usually `~` key). Your `echo()` statements appear there!

### Common Issues

**Mods not loading?**
- Check `config.cs` has the exec() hook
- Verify mods are in `script/mods/`
- Check game console for errors

**Syntax errors?**
- TorqueScript is case-insensitive
- Use `//` for comments
- Functions need `function` keyword
- Statements end with `;`

**Game crashes?**
- Restore backups: `--restore`
- Comment out problematic code
- Test mods one at a time

---

## 🎯 Why v2.0 is Better

### v1.0 (Our Compiler):
```
Your .cs → Our Python compiler → .cso → Game loads
           ↑ LIMITED, buggy
```

### v2.0 (Game's Compiler):
```
Your .cs → Game's built-in compiler → Runs!
           ↑ FULL FEATURES, reliable
```

**Advantages:**
- ✅ Game compiles perfectly (it's the original!)
- ✅ Full TorqueScript support
- ✅ No compatibility issues
- ✅ Just edit text files!
- ✅ Easier debugging

---

## 📚 Resources

**Decompiled Scripts** (for reference):
- `startup.cso.cs` - Game startup
- `scriptload.cso.cs` - Script loading
- `ingame.cso.cs` - In-game systems

**Study These** to understand:
- How game systems work
- Function names (obfuscated)
- Global variables
- Game flow

---

## 🛠️ Commands Reference

```bash
# First time setup
python scarface_modloader_v2.py --game-dir "PATH" --setup

# Watch for changes
python scarface_modloader_v2.py --game-dir "PATH" --watch

# Create example mod
python scarface_modloader_v2.py --game-dir "PATH" --example

# Restore originals
python scarface_modloader_v2.py --game-dir "PATH" --restore
```

---

## 🎉 That's It!

**THE GAME DOES ALL THE WORK!**

You just:
1. Write `.cs` files
2. Drop them in `script/mods/`  
3. Play!

No complicated compilation, no bytecode, just pure TorqueScript! 🚀

---

## ⚠️ Important Notes

### The Hook
The loader adds this line to `config.cs`:
```torquescript
exec("script/mods/loader.cs");
```

If you restore backups, you'll need to re-run `--setup`!

### File Watching
Use `--watch` mode during development. The loader will automatically regenerate `loader.cs` when you add/remove/modify mods!

### Backups
Original files are backed up to `./backups/` before modification. Use `--restore` to undo all changes!

---

**Happy Modding!** 🎮✨
