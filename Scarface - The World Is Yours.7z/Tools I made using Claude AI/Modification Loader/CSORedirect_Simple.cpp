// CSORedirect_Simple.cpp
// Simple and reliable script redirection using CreateFileA hook
// Based on SilentPatch architecture but simplified
//
// LICENSE: MIT
// AUTHOR: Community contribution

#include <windows.h>
#include <stdio.h>
#include <string>
#include <map>
#include <fstream>

// ============================================================================
// CONFIGURATION
// ============================================================================

#define LOG_FILE "CSORedirect.log"
#define CONFIG_FILE "CSORedirect.txt"
#define VERSION "1.0-Simple"

// ============================================================================
// GLOBALS
// ============================================================================

std::map<std::string, std::string> g_redirects;
FILE* g_log = nullptr;
bool g_enabled = true;

// Original function pointer
typedef HANDLE (WINAPI *CreateFileA_t)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
CreateFileA_t g_origCreateFileA = nullptr;

// ============================================================================
// LOGGING
// ============================================================================

void Log(const char* format, ...)
{
    if (!g_log)
    {
        g_log = fopen(LOG_FILE, "w");
        if (!g_log) return;
        
        fprintf(g_log, "========================================\n");
        fprintf(g_log, "CSORedirect v%s\n", VERSION);
        fprintf(g_log, "========================================\n\n");
        fflush(g_log);
    }
    
    va_list args;
    va_start(args, format);
    vfprintf(g_log, format, args);
    va_end(args);
    fflush(g_log);
}

// ============================================================================
// STRING UTILITIES
// ============================================================================

std::string ToLower(std::string str)
{
    for (char& c : str) c = tolower(c);
    return str;
}

bool EndsWith(const std::string& str, const std::string& suffix)
{
    if (str.length() < suffix.length()) return false;
    return str.compare(str.length() - suffix.length(), suffix.length(), suffix) == 0;
}

std::string Replace(std::string str, const std::string& from, const std::string& to)
{
    size_t pos = 0;
    while ((pos = str.find(from, pos)) != std::string::npos)
    {
        str.replace(pos, from.length(), to);
        pos += to.length();
    }
    return str;
}

// ============================================================================
// CONFIGURATION
// ============================================================================

void LoadConfig()
{
    Log("Loading configuration from %s\n", CONFIG_FILE);
    
    std::ifstream file(CONFIG_FILE);
    if (!file.is_open())
    {
        Log("  Config file not found, creating default...\n");
        
        // Create default config
        std::ofstream out(CONFIG_FILE);
        if (out.is_open())
        {
            out << "# CSORedirect Configuration\n";
            out << "# Format: scriptc/file.cso=script/file.cs\n";
            out << "#\n";
            out << "# The game will try to load .cs files instead of .cso\n";
            out << "# Leave empty for automatic redirection of ALL .cso files\n";
            out << "#\n";
            out << "# Examples:\n";
            out << "# scriptc/config.cso=script/config.cs\n";
            out << "# scriptc/missions.cso=script/mods/missions.cs\n";
            out << "\n";
            out.close();
        }
        return;
    }
    
    std::string line;
    int lineNum = 0;
    
    while (std::getline(file, line))
    {
        lineNum++;
        
        // Remove comments
        size_t comment = line.find('#');
        if (comment != std::string::npos)
            line = line.substr(0, comment);
            
        // Trim whitespace
        line.erase(0, line.find_first_not_of(" \t\r\n"));
        line.erase(line.find_last_not_of(" \t\r\n") + 1);
        
        if (line.empty()) continue;
        
        // Find separator
        size_t eq = line.find('=');
        if (eq == std::string::npos)
        {
            Log("  Line %d: Invalid (no '=')\n", lineNum);
            continue;
        }
        
        std::string from = line.substr(0, eq);
        std::string to = line.substr(eq + 1);
        
        // Trim
        from.erase(0, from.find_first_not_of(" \t"));
        from.erase(from.find_last_not_of(" \t") + 1);
        to.erase(0, to.find_first_not_of(" \t"));
        to.erase(to.find_last_not_of(" \t") + 1);
        
        if (from.empty() || to.empty())
        {
            Log("  Line %d: Invalid (empty)\n", lineNum);
            continue;
        }
        
        // Convert to lowercase for case-insensitive matching
        g_redirects[ToLower(from)] = to;
        Log("  Redirect: %s -> %s\n", from.c_str(), to.c_str());
    }
    
    file.close();
    Log("Loaded %d redirects\n\n", (int)g_redirects.size());
}

// ============================================================================
// FILE HOOK
// ============================================================================

HANDLE WINAPI HookedCreateFileA(
    LPCSTR lpFileName,
    DWORD dwDesiredAccess,
    DWORD dwShareMode,
    LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    DWORD dwCreationDisposition,
    DWORD dwFlagsAndAttributes,
    HANDLE hTemplateFile)
{
    if (!g_enabled || !lpFileName)
    {
        return g_origCreateFileA(lpFileName, dwDesiredAccess, dwShareMode,
            lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
    }
    
    std::string path = lpFileName;
    std::string pathLower = ToLower(path);
    
    // Check if it's a .cso file
    if (EndsWith(pathLower, ".cso"))
    {
        Log("File access: %s\n", lpFileName);
        
        // Check explicit redirects first
        auto it = g_redirects.find(pathLower);
        if (it != g_redirects.end())
        {
            const char* newPath = it->second.c_str();
            Log("  REDIRECT (explicit): %s\n", newPath);
            
            HANDLE h = g_origCreateFileA(newPath, dwDesiredAccess, dwShareMode,
                lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
                
            if (h != INVALID_HANDLE_VALUE)
            {
                Log("  SUCCESS!\n");
                return h;
            }
            
            Log("  FAILED, trying original\n");
        }
        
        // Try automatic .cso -> .cs conversion
        std::string csPath = Replace(path, ".cso", ".cs");
        csPath = Replace(csPath, ".CSO", ".cs");
        csPath = Replace(csPath, "scriptc\\", "script\\");
        csPath = Replace(csPath, "scriptc/", "script/");
        csPath = Replace(csPath, "SCRIPTC\\", "script\\");
        csPath = Replace(csPath, "SCRIPTC/", "script/");
        
        if (csPath != path)  // If we made changes
        {
            Log("  REDIRECT (auto): %s\n", csPath.c_str());
            
            HANDLE h = g_origCreateFileA(csPath.c_str(), dwDesiredAccess, dwShareMode,
                lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
                
            if (h != INVALID_HANDLE_VALUE)
            {
                Log("  SUCCESS!\n");
                return h;
            }
            
            Log("  FAILED, using original\n");
        }
    }
    
    // Call original function
    return g_origCreateFileA(lpFileName, dwDesiredAccess, dwShareMode,
        lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
}

// ============================================================================
// IAT HOOKING
// ============================================================================

bool HookIAT()
{
    Log("Installing IAT hook for CreateFileA...\n");
    
    HMODULE hModule = GetModuleHandle(nullptr);
    if (!hModule)
    {
        Log("  ERROR: GetModuleHandle failed\n");
        return false;
    }
    
    // Get DOS header
    PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)hModule;
    if (pDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
    {
        Log("  ERROR: Invalid DOS signature\n");
        return false;
    }
    
    // Get NT headers
    PIMAGE_NT_HEADERS pNTHeaders = (PIMAGE_NT_HEADERS)((BYTE*)hModule + pDosHeader->e_lfanew);
    if (pNTHeaders->Signature != IMAGE_NT_SIGNATURE)
    {
        Log("  ERROR: Invalid NT signature\n");
        return false;
    }
    
    // Get import directory
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
        
    if (!pImportDesc)
    {
        Log("  ERROR: No import directory\n");
        return false;
    }
    
    // Find kernel32.dll
    for (; pImportDesc->Name; pImportDesc++)
    {
        const char* dllName = (const char*)((BYTE*)hModule + pImportDesc->Name);
        
        if (_stricmp(dllName, "kernel32.dll") == 0)
        {
            Log("  Found kernel32.dll imports\n");
            
            // Get thunk
            PIMAGE_THUNK_DATA pThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
            PIMAGE_THUNK_DATA pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
            
            for (; pOrigThunk->u1.Function; pThunk++, pOrigThunk++)
            {
                if (pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)
                    continue;  // Skip ordinal imports
                    
                PIMAGE_IMPORT_BY_NAME pImport = (PIMAGE_IMPORT_BY_NAME)((BYTE*)hModule + pOrigThunk->u1.AddressOfData);
                
                if (strcmp((const char*)pImport->Name, "CreateFileA") == 0)
                {
                    Log("  Found CreateFileA at 0x%p\n", &pThunk->u1.Function);
                    
                    // Store original
                    g_origCreateFileA = (CreateFileA_t)pThunk->u1.Function;
                    Log("  Original function: 0x%p\n", g_origCreateFileA);
                    
                    // Replace with our hook
                    DWORD oldProtect;
                    if (!VirtualProtect(&pThunk->u1.Function, sizeof(PVOID), PAGE_READWRITE, &oldProtect))
                    {
                        Log("  ERROR: VirtualProtect failed\n");
                        return false;
                    }
                    
                    pThunk->u1.Function = (DWORD_PTR)HookedCreateFileA;
                    
                    VirtualProtect(&pThunk->u1.Function, sizeof(PVOID), oldProtect, &oldProtect);
                    
                    Log("  Hook installed successfully!\n");
                    return true;
                }
            }
        }
    }
    
    Log("  ERROR: CreateFileA not found in IAT\n");
    return false;
}

// ============================================================================
// DLL ENTRY POINT
// ============================================================================

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
        {
            DisableThreadLibraryCalls(hinstDLL);
            
            Log("CSORedirect v%s initializing...\n\n", VERSION);
            
            // Load configuration
            LoadConfig();
            
            // Install hook
            if (!HookIAT())
            {
                Log("\nERROR: Failed to install hooks!\n");
                MessageBoxA(nullptr, 
                    "CSORedirect failed to install hooks!\nCheck CSORedirect.log for details.",
                    "CSORedirect Error", MB_OK | MB_ICONERROR);
                return FALSE;
            }
            
            Log("\nCSORedirect initialized successfully!\n");
            Log("Monitoring file access...\n\n");
            
            break;
        }
        
        case DLL_PROCESS_DETACH:
        {
            if (g_log)
            {
                Log("\nCSORedirect shutting down...\n");
                fclose(g_log);
                g_log = nullptr;
            }
            break;
        }
    }
    
    return TRUE;
}

// ============================================================================
// BUILD INSTRUCTIONS
// ============================================================================

/*
COMPILATION:
============

Using Visual Studio:
cl /LD /O2 /EHsc CSORedirect_Simple.cpp /link /OUT:CSORedirect.asi

Using MinGW:
g++ -shared -O2 -o CSORedirect.asi CSORedirect_Simple.cpp -lkernel32

INSTALLATION:
=============

1. Install Ultimate ASI Loader (dinput8.dll) in game directory
2. Copy CSORedirect.asi to game directory (or plugins/ folder)
3. Create CSORedirect.txt for custom redirects (optional)
4. Launch game

The .asi will automatically redirect ALL .cso files to .cs alternatives!

CONFIGURATION:
==============

CSORedirect.txt format:

# Explicit redirects
scriptc/config.cso=script/config.cs
scriptc/missions.cso=script/mods/my_missions.cs

# Leave empty for automatic redirection of ALL .cso files
# Automatic: scriptc/*.cso -> script/*.cs

TROUBLESHOOTING:
================

Check CSORedirect.log for:
- Which files are being accessed
- Whether redirects are working
- Any errors

If hooks fail:
1. Make sure game is NOT running as admin
2. Check Ultimate ASI Loader is installed
3. Try different ASI loader (d3d9.dll, dsound.dll)

ADVANTAGES:
===========

✅ Simple - Just one file
✅ Reliable - Uses Windows IAT hooking
✅ Works immediately - No reverse engineering
✅ Automatic - Redirects ALL .cso to .cs
✅ Configurable - Custom redirects via .txt file
✅ Logged - See exactly what's happening

This is the SIMPLEST working solution!
Just compile, install ASI loader, and it works!
*/
