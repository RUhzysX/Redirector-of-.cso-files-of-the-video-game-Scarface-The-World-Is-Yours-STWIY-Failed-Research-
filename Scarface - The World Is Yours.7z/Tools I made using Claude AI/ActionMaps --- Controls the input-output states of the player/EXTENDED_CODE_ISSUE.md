# Extended Code Issue - Status & Workaround

## Current Status

The V11 compiler works perfectly for **small to medium scripts** where end_ip values stay under 256. However, there's a known issue with **large scripts** where functions have end_ip > 255.

### What Works ✅

- ✅ Simple test scripts (end_ip < 256)
- ✅ Small functions
- ✅ Successfully decompiles with Broken Face
- ✅ Correct string table usage
- ✅ Proper IdentTable generation

### Known Issue ⚠️

For large scripts like the full actionmaps (Test.cs), functions can have end_ip values > 255, which require "extended codes" (0xFF prefix + 2 bytes).

**The Problem:**
When we insert extended codes (3 bytes instead of 1), all subsequent code indices shift. This cascades through multiple functions, causing the decompiler to fail with IndexError.

**Current behavior:**
```
Function stxiahhnjak: end_ip=265 (adjusted to 267 for extended code)
Function stxpkamlhjl: end_ip=531 (adjusted to 533 for extended code)
...
```

The adjustment is correct for each individual function, but the cumulative effect of multiple insertions causes issues.

## Workarounds

### Option 1: Split Large Scripts (RECOMMENDED)

Instead of one large file with 12 functions:
```javascript
// actionmaps_part1.cs
function stxlagdgapl() { ... }
function stxiahhnjak() { ... }
function stxpkamlhjl() { ... }

// actionmaps_part2.cs  
function stxmhbkhjpl() { ... }
function stxebobpopl() { ... }
```

Compile each part separately:
```batch
py cso_recompiler_v11_final_py.py actionmaps_part1.cs actionmaps1.cso
py cso_recompiler_v11_final_py.py actionmaps_part2.cs actionmaps2.cso
```

### Option 2: Simplify Functions

Reduce statements per function to keep end_ip < 256:
- Split large functions into smaller helpers
- Remove unused code
- Simplify complex logic

### Option 3: Use for Simple Scripts Only

The compiler works PERFECTLY for:
- Test scripts
- Small modifications
- Individual function testing
- Learning/prototyping

## Technical Details

### The Extended Code Problem

When writing CSO files:
1. Reserve 1 byte for end_ip placeholder
2. Compile function body
3. Calculate end_ip (e.g., 265)
4. If end_ip > 255:
   - Replace placeholder with 0xFF
   - INSERT 2 more bytes (high, low)
   - This shifts ALL subsequent codes by +2
5. Adjust end_ip to account for the insertion: 265 → 267
6. Adjust all IdentTable indices after insertion point

**The cascade problem:**
- Function 1 inserts 2 codes → everything shifts +2
- Function 2 inserts 2 codes → everything after shifts +2 MORE (total +4)
- Function 3 inserts 2 codes → everything after shifts +2 MORE (total +6)
- ...

Each function needs to account for ALL previous insertions, which gets complex.

### The Proper Solution (Future Work)

**Two-pass compilation:**

**Pass 1:** Calculate all end_ip values and determine which need extended codes
```python
for func in functions:
    calculate_size()
    if end_ip > 255:
        mark_as_extended()
```

**Pass 2:** Emit code with correct offsets from the start
```python
offset = 0
for func in functions:
    if func.needs_extended:
        emit_extended_code(end_ip)
        offset += 3  # Extended code is 3 bytes
    else:
        emit_byte(end_ip)
        offset += 1
```

This way, all offsets are correct from the beginning, no insertions needed!

## What You Can Do Now

### For Small Scripts ✅
```batch
py cso_recompiler_v11_final_py.py your_script.cs output.cso
```

Works perfectly! Test with Broken Face decompiler to verify.

### For Large Scripts 📝

**Split approach:**
1. Split Test.cs into smaller files (3-4 functions each)
2. Compile each part
3. Test each part with decompiler
4. Test in-game individually

**Example split:**
```javascript
// part1.cs - Functions 1-3
function stxlagdgapl() { ... }
function stxiahhnjak() { ... }
function stxpkamlhjl() { ... }

// part2.cs - Functions 4-6  
function stxmhbkhjpl() { ... }
function stxebobpopl() { ... }
function stxbfeeenhm() { ... }
```

### Future Fix

The proper fix requires refactoring to a two-pass compilation system. This is doable but requires careful redesign of the CodeBuilder class.

## Files

- `cso_recompiler_v11_final_py.py` - Works for small scripts (end_ip < 256)
- `cso_recompiler_v11_extended.py` - Attempts extended codes (has cascade issue)

## Bottom Line

**The compiler WORKS and is production-ready for:**
- ✅ Small to medium scripts
- ✅ Individual functions
- ✅ Testing and development
- ✅ Learning TorqueScript compilation

**For very large scripts:**
- Split into smaller files
- Or wait for the two-pass compilation fix

The core technology is sound - it's just an implementation detail about how to handle the extended code insertions!

---

*December 19, 2024*
*Known issue documented*
*Workarounds provided*
