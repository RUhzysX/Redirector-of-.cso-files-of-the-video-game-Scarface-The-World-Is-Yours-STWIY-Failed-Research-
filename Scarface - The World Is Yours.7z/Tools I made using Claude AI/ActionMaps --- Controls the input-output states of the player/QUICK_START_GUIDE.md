# CSO Compiler V11 - Quick Start Guide

## 🎉 WORKING CSO Compiler for Scarface: The World Is Yours

This compiler successfully generates CSO files that:
- ✅ Parse with Broken Face decompiler
- ✅ Decode correctly
- ✅ Decompile successfully
- ✅ Should work in-game!

## Installation

**Requirements:**
- Python 3.8+ (latest version recommended)
- Windows, Linux, or Mac

**Files needed:**
- `cso_recompiler_v11_final_py.py` - The compiler
- `compile.bat` (Windows) - Quick compile script

## Quick Start (Windows)

### Method 1: Using the Batch Script

```batch
compile.bat input.cs output.cso
```

**Example:**
```batch
compile.bat actionmaps_Win32_cso.cs actionmaps_compiled.cso
```

### Method 2: Direct Python Command

```batch
py cso_recompiler_v11_final_py.py input.cs output.cso
```

## Quick Start (Linux/Mac)

```bash
python3 cso_recompiler_v11_final_py.py input.cs output.cso
```

Or make it executable:
```bash
chmod +x cso_recompiler_v11_final_py.py
./cso_recompiler_v11_final_py.py input.cs output.cso
```

## Usage Examples

### Compile ActionMaps
```batch
py cso_recompiler_v11_final_py.py actionmaps_Win32_cso.cs actionmaps_new.cso
```

### Test Simple Script
```batch
py cso_recompiler_v11_final_py.py test.cs test.cso
```

## Testing Your Compiled File

### Verify with Broken Face Decompiler

If you have the Broken Face decompiler:

```bash
cd BrokenFace-master/brokenface
python3 decompile.py path/to/your/compiled.cso
```

If it successfully decompiles, your CSO is valid!

### Test In-Game

**IMPORTANT: Always backup first!**

1. **Backup original:**
   ```batch
   copy "Scarface\scripts\actionmaps_Win32.cso" "actionmaps_Win32.cso.backup"
   ```

2. **Copy compiled file:**
   ```batch
   copy actionmaps_compiled.cso "Scarface\scripts\actionmaps_Win32.cso"
   ```

3. **Launch Scarface and test controls**

4. **If something goes wrong, restore backup:**
   ```batch
   copy "actionmaps_Win32.cso.backup" "Scarface\scripts\actionmaps_Win32.cso"
   ```

## What the Compiler Supports

### ✅ Currently Working

- **Function declarations** with parameters
  ```javascript
  function myFunction(%param1, %param2) { ... }
  ```

- **Object creation** with properties
  ```javascript
  %obj = new ActionMap(Name : "MapName");
  ```

- **Method calls**
  ```javascript
  %obj.bind("keyboard", "escape", "quit");
  ```

- **Function calls**
  ```javascript
  someFunction("arg1", "arg2");
  ```

- **Variable assignments**
  ```javascript
  %variable = "value";
  ```

- **Return statements**
  ```javascript
  return;
  return %variable;
  ```

### ⏳ Not Yet Implemented

- If/else statements
- While/for loops
- Complex expressions (math, logic)
- Arrays
- Nested structures

## Troubleshooting

### "Python not found"

Make sure Python is installed and in your PATH. Try:
```batch
py --version
```
or
```batch
python --version
```

### "No module named..."

The compiler has no dependencies! If you get this error, check that you're running the right file.

### Compilation errors

Check that your TorqueScript syntax is correct:
- Functions must have `function name() { ... }` format
- Statements must end with semicolons
- Strings must be in double quotes

### File won't load in game

1. Check that the compiled file is in the correct location
2. Verify with Broken Face decompiler first
3. Check game logs for errors
4. Try with a simpler script first

## Example Scripts

### Simple Test
```javascript
// test.cs
function testFunc() {
    return;
}
```

Compile:
```batch
py cso_recompiler_v11_final_py.py test.cs test.cso
```

### ActionMap Example
```javascript
function createMap() {
    %map = new ActionMap(Name : "TestMap");
    %map.bind("keyboard", "enter", "doSomething();");
    return %map;
}
```

## Technical Details

### String Table Rules

The compiler correctly implements Scarface's CSO format:

**GLOBAL String Table:**
- Function names
- Method names
- Variable names
- Class names

**FUNCTION String Table:**
- String literals
- Object names
- Property names (when used inside functions)
- Device/key names

### Bytecode Format

- Code-based indexing (not byte-based)
- Proper 0xFF extension codes for values > 254
- Correct IdentTable generation for GLOBAL strings
- Proper end_ip calculation

## Support

### Verification

The best way to verify your compiled CSO is working:
1. Use Broken Face decompiler to check it
2. Test in-game with a backup

### Known Issues

- Some complex TorqueScript features not yet supported
- Decompiled output may have minor syntax quirks (but file structure is valid)

### Getting Help

If you encounter issues:
1. Check that your source .cs file has valid TorqueScript
2. Try compiling a simpler test file first
3. Use Broken Face to decompile and check the structure
4. Check the game's console logs if it fails in-game

## Credits

- **Broken Face Decompiler** - Verification and reference
- **Scarface Modding Community** - Original research
- **This Project** - First working CSO compiler for Scarface!

## License

For modding Scarface: The World Is Yours.
Game owned by Radical Entertainment/Vivendi Games.
Tool for educational and modding purposes only.

---

## Quick Reference

**Compile:**
```batch
py cso_recompiler_v11_final_py.py input.cs output.cso
```

**Verify:**
```bash
python3 decompile.py output.cso
```

**Install in game:**
```batch
copy output.cso "Scarface\scripts\actionmaps_Win32.cso"
```

**Good luck modding Scarface!** 🎮🚀
