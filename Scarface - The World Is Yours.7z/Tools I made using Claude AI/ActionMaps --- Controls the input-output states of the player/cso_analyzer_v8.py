#!/usr/bin/env python3
"""
CSO Format Analyzer - Detailed binary analysis
"""

import sys
import struct


def read_u32_le(data, offset):
    """Read 4-byte little-endian unsigned int"""
    return struct.unpack_from('<I', data, offset)[0], offset + 4


def read_string_table(data, offset, size):
    """Read null-terminated string table"""
    strings = []
    end = offset + size
    while offset < end:
        str_start = offset
        while offset < end and data[offset] != 0:
            offset += 1
        string = data[str_start:offset].decode('ascii', errors='replace')
        strings.append(string)
        offset += 1  # Skip null terminator
    return strings, offset


def read_float_table(data, offset, count):
    """Read float table"""
    floats = []
    for _ in range(count):
        f = struct.unpack_from('<f', data, offset)[0]
        floats.append(f)
        offset += 4
    return floats, offset


def read_bytecode(data, offset, code_count):
    """
    Read bytecode as CODES, not bytes.
    Each code is either 1 byte or 3 bytes (0xFF + 2-byte LE value)
    """
    codes = []
    byte_start = offset
    
    codes_read = 0
    while codes_read < code_count:
        byte = data[offset]
        offset += 1
        
        if byte == 0xFF:
            # Extended code: next 2 bytes are LITTLE-ENDIAN
            low = data[offset]
            high = data[offset + 1]
            code = (high << 8) | low
            offset += 2
            codes.append(code)
        else:
            codes.append(byte)
        
        codes_read += 1
    
    bytes_consumed = offset - byte_start
    return codes, offset, bytes_consumed


def read_ident_table(data, offset):
    """
    Read IdentTable.
    Each entry:
    - Offset: 4 bytes LE
    - Count: 4 bytes LE
    - Locations: 4 bytes LE each
    """
    entry_count, offset = read_u32_le(data, offset)
    
    entries = []
    for _ in range(entry_count):
        string_offset, offset = read_u32_le(data, offset)
        count, offset = read_u32_le(data, offset)
        
        locations = []
        for _ in range(count):
            loc, offset = read_u32_le(data, offset)
            locations.append(loc)
        
        entries.append({
            'offset': string_offset,
            'count': count,
            'locations': locations
        })
    
    return entries, offset


def analyze_cso(filename):
    """Analyze CSO file structure"""
    with open(filename, 'rb') as f:
        data = f.read()
    
    print(f"\n{'='*60}")
    print(f"CSO File Analysis: {filename}")
    print(f"{'='*60}")
    print(f"Total size: {len(data)} bytes\n")
    
    offset = 0
    
    # Version
    version, offset = read_u32_le(data, offset)
    print(f"Version: {version}")
    
    # Global string table
    global_str_size, offset = read_u32_le(data, offset)
    print(f"\nGlobal String Table: {global_str_size} bytes")
    global_strings, offset = read_string_table(data, offset, global_str_size)
    for i, s in enumerate(global_strings):
        print(f"  [{i:3}] offset={sum(len(s2)+1 for s2 in global_strings[:i]):5} '{s}'")
    
    # Global float table
    global_float_count, offset = read_u32_le(data, offset)
    print(f"\nGlobal Float Table: {global_float_count} entries")
    global_floats, offset = read_float_table(data, offset, global_float_count)
    for i, f in enumerate(global_floats):
        print(f"  [{i:3}] {f}")
    
    # Function string table
    func_str_size, offset = read_u32_le(data, offset)
    print(f"\nFunction String Table: {func_str_size} bytes")
    func_strings, offset = read_string_table(data, offset, func_str_size)
    for i, s in enumerate(func_strings):
        print(f"  [{i:3}] offset={sum(len(s2)+1 for s2 in func_strings[:i]):5} '{s}'")
    
    # Function float table
    func_float_count, offset = read_u32_le(data, offset)
    print(f"\nFunction Float Table: {func_float_count} entries")
    func_floats, offset = read_float_table(data, offset, func_float_count)
    for i, f in enumerate(func_floats):
        print(f"  [{i:3}] {f}")
    
    # Bytecode
    code_count, offset = read_u32_le(data, offset)
    print(f"\nBytecode: {code_count} codes")
    bytecode_start = offset
    codes, offset, bytes_consumed = read_bytecode(data, offset, code_count)
    print(f"Bytecode bytes: {bytes_consumed}")
    print(f"\nFirst 20 codes:")
    for i in range(min(20, len(codes))):
        if codes[i] < 256:
            print(f"  Code[{i:3}] = 0x{codes[i]:02X} ({codes[i]})")
        else:
            print(f"  Code[{i:3}] = 0x{codes[i]:04X} ({codes[i]}) [EXTENDED]")
    
    # IdentTable
    print(f"\nIdentTable:")
    ident_entries, offset = read_ident_table(data, offset)
    print(f"Entries: {len(ident_entries)}")
    for i, entry in enumerate(ident_entries):
        print(f"  Entry[{i}]:")
        print(f"    Offset: {entry['offset']} (0x{entry['offset']:04X})")
        print(f"    Count: {entry['count']}")
        print(f"    Locations: {entry['locations'][:5]}{'...' if len(entry['locations']) > 5 else ''}")
    
    print(f"\nBytes remaining: {len(data) - offset}")
    
    if offset < len(data):
        print(f"\nExtra data at end:")
        print(f"  {data[offset:offset+min(32, len(data)-offset)].hex()}")
    
    print(f"\n{'='*60}\n")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 cso_analyzer_v8.py file.cso [file2.cso ...]")
        sys.exit(1)
    
    for filename in sys.argv[1:]:
        try:
            analyze_cso(filename)
        except Exception as e:
            print(f"Error analyzing {filename}: {e}")
            import traceback
            traceback.print_exc()
