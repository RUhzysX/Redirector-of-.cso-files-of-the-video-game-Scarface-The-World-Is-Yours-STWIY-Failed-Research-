# SCARFACE TORQUE3D OPCODE REFERENCE
## Complete Guide for Recompiler Implementation

Based on:
- stwiy-lib CodeBlock.cpp (Scarface VM behavior - STORAGE format)
- BrokenFace codec.py (Decoder expectations - INTERPRETATION)
- Real actionmaps_Win32.cso analysis (Working bytecode)

---

## KEY CONCEPTS

### Storage vs Interpretation
- **STORAGE**: How opcodes are written to file (U32 array with compression)
- **INTERPRETATION**: How BrokenFace/VM reads and executes them

**CRITICAL**: We emit in STORAGE format, BrokenFace interprets differently!

### U32 Array Format
- Each element is a U32 (0-4,294,967,295)
- Values < 255: stored as 1 byte
- Values >= 255: stored as 3 bytes (0xFF + high byte + low byte)

### Stack Model
Scarface VM has multiple stacks:
- **STR stack**: String values
- **FLT stack**: Float values  
- **UINT stack**: Integer values
- **argFrame**: Argument frames (list of lists)
- **intStack**: Object references

---

## OPCODE REFERENCE

### OP_FUNC_DECL (0x00)
**Purpose**: Declares a function
**Storage**: `[opcode] [name] [namespace] [package] [hasBody] [end_ip] [argc] [param1] [param2]...`
**Parameters**:
- name: 1 U32 (StringTableEntry hash)
- namespace: 1 U32 
- package: 1 U32
- hasBody: 1 U32 (0 or 1)
- end_ip: 1 U32 (code index where function ends)
- argc: 1 U32 (number of parameters)
- params: argc U32s (parameter name hashes)

**Total codes**: 6 + argc

**Example**:
```
[0x00] [0x00] [0x00] [0x00] [0x00] [0x00] [0x00] [0x01] [0x87] [0x00]
  |      |      |      |      |      |      |      |      |      └─ argc=0
  |      |      |      |      |      |      |      |      └─ end_ip=135
  |      |      |      |      |      |      |      └─ hasBody=1
  |      |      |      |      |      └─ package=0 (low)
  |      |      |      |      └─ package=0 (high)
  |      |      |      └─ namespace=0 (low)
  |      |      └─ namespace=0 (high)
  |      └─ name=0 (low)
  └─ opcode
```

---

### OP_CREATE_OBJECT (0x01)
**Purpose**: Creates a new object instance

**CRITICAL DIFFERENCE**:

**stwiy-lib STORAGE (what's in file)**:
```
[opcode] [objParent] [isDataBlock] [isInternal] [isSingleton] [lineNumber] [failJump]
```
- objParent: 1 U32 (parent class hash)
- isDataBlock: 1 U32 (0/1)
- isInternal: 1 U32 (0/1)
- isSingleton: 1 U32 (0/1)
- lineNumber: 1 U32
- failJump: 1 U32 (IP to jump on failure)
**Total**: 6 parameters = 7 codes total

**BrokenFace INTERPRETATION (how it reads)**:
```python
parent = getString()      # Reads 2 bytes from code, looks up in string table
mystery = getCode()       # Reads 1 code
end = getCode()           # Reads 1 code (end IP)
argv = argFrame.pop()     # Pops constructor arguments
```

**SO**: BrokenFace expects:
1. Parent class NAME to be on STR stack (via previous LOADIMMED_IDENT + PUSH)
2. Class name in argFrame[1] (first argument after parent)
3. Constructor params in rest of argFrame

**Correct emission sequence**:
```python
# 1. Load parent object (usually 0)
OP_LOADIMMED_UINT, 0, 0

# 2. Create argument frame
OP_PUSHFRAME

# 3. Convert parent tag to string
OP_TAG_TO_STR, 0, 0

# 4. Push parent to argFrame
OP_PUSH

# 5. Load class name identifier
OP_LOADIMMED_IDENT, <class_name_offset_high>, <class_name_offset_low>

# 6. Push class name to argFrame
OP_PUSH

# 7. For each property:
#    OP_LOADIMMED_IDENT, <prop_name>
#    OP_PUSH
#    OP_LOADIMMED_STR, <prop_value>
#    OP_PUSH

# 8. Create object
OP_CREATE_OBJECT, <mystery=0>, <end_ip>
```

**Stack effect**:
- Pops: argFrame (constructor args)
- Pushes: object reference to intStack

---

### OP_ADD_OBJECT (0x04)
**Purpose**: Adds created object to parent or stack
**Storage**: `[opcode] [placeAtRoot]`
**Parameters**:
- placeAtRoot: 1 U32 (0 or 1)

**Total codes**: 2

**Stack effect**:
- If placeAtRoot: overwrites intStack[-1]
- Else: pushes to intStack

---

### OP_END_OBJECT (0x05)
**Purpose**: Ends object creation, restores previous tree
**Storage**: `[opcode] [placeAtRoot]`
**Parameters**:
- placeAtRoot: 1 U32 (0 or 1)

**Total codes**: 2

**Stack effect**:
- Restores previous tree from treeStack
- If !placeAtRoot: pops intStack and appends to tree

---

### OP_JMPIFFNOT (0x06)
**Purpose**: Jump if float on FLT stack is false (0.0)
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32 (code index to jump to)

**Total codes**: 2

---

### OP_JMPIFNOT (0x07)
**Purpose**: Jump if value on STR stack is false
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_JMPIFF (0x08)
**Purpose**: Jump if float on FLT stack is true (!= 0.0)
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_JMPIF (0x09)
**Purpose**: Jump if value on STR stack is true
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_JMPIFNOT_NP (0x0A)
**Purpose**: Jump if not (no pop - doesn't consume stack)
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_JMPIF_NP (0x0B)
**Purpose**: Jump if (no pop)
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_JMP (0x0C)
**Purpose**: Unconditional jump
**Storage**: `[opcode] [target_ip]`
**Parameters**:
- target_ip: 1 U32

**Total codes**: 2

---

### OP_RETURN (0x0D)
**Purpose**: Return from function
**Storage**: `[opcode]`
**Parameters**: None

**Total codes**: 1

---

### COMPARISON OPCODES (0x0E - 0x13)
All have same format:
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pop 2 values, push comparison result

- **OP_CMPEQ (0x0E)**: Equal
- **OP_CMPLT (0x0F)**: Less than
- **OP_CMPLE (0x10)**: Less than or equal
- **OP_CMPGR (0x11)**: Greater than
- **OP_CMPGE (0x12)**: Greater than or equal
- **OP_CMPNE (0x13)**: Not equal

---

### BINARY OPERATORS (0x14 - 0x22)
All have same format:
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pop 2 values, push result

- **OP_XOR (0x14)**: Bitwise XOR
- **OP_MOD (0x15)**: Modulo
- **OP_BITAND (0x16)**: Bitwise AND
- **OP_BITOR (0x17)**: Bitwise OR
- **OP_NOT (0x18)**: Logical NOT
- **OP_NOTF (0x19)**: Float NOT
- **OP_ONESCOMPLEMENT (0x1A)**: Bitwise complement
- **OP_SHR (0x1B)**: Shift right
- **OP_SHL (0x1C)**: Shift left
- **OP_AND (0x1D)**: Logical AND
- **OP_OR (0x1E)**: Logical OR
- **OP_ADD (0x1F)**: Addition
- **OP_SUB (0x20)**: Subtraction
- **OP_MUL (0x21)**: Multiplication
- **OP_DIV (0x22)**: Division
- **OP_NEG (0x23)**: Negation (unary)

---

### VARIABLE OPCODES

#### OP_SETCURVAR (0x24 - 0x27)
**Purpose**: Sets current variable for reading/writing
**Storage**: `[opcode] [var_name]`
**Parameters**:
- var_name: 1 U32 (StringTableEntry hash)

**Total codes**: 2

**Variants** (opcodes 0x24-0x27 all map to same handler):
- 0x24: OP_SETCURVAR
- 0x25: OP_SETCURVAR_CREATE
- 0x26: OP_SETCURVAR (variant 2)
- 0x27: OP_SETCURVAR (variant 3)

---

#### OP_SETCURVAR_ARRAY (0x28 - 0x2B)
**Purpose**: Sets current variable array
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Variants** (opcodes 0x28-0x2B):
- 0x28: OP_SETCURVAR_ARRAY
- 0x29: OP_SETCURVAR_ARRAY_CREATE
- 0x2A: OP_SETCURVAR_ARRAY (variant 2)
- 0x2B: OP_SETCURVAR_ARRAY (variant 3)

---

#### OP_LOADVAR_* (0x2C - 0x2E)
**Purpose**: Load variable value onto type-specific stack
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

- **OP_LOADVAR_UINT (0x2C)**: Load to UINT stack
- **OP_LOADVAR_FLT (0x2D)**: Load to FLT stack
- **OP_LOADVAR_STR (0x2E)**: Load to STR stack

---

#### OP_SAVEVAR_* (0x2F - 0x31)
**Purpose**: Save value from stack to current variable
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

- **OP_SAVEVAR_UINT (0x2F)**: Save from UINT stack
- **OP_SAVEVAR_FLT (0x30)**: Save from FLT stack
- **OP_SAVEVAR_STR (0x31)**: Save from STR stack

---

### OBJECT FIELD OPCODES

#### OP_SETCUROBJECT (0x32)
**Purpose**: Sets current object for field access
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pops object from intStack

---

#### OP_SETCUROBJECT_NEW (0x33)
**Purpose**: Sets current object (new variant)
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_SETCURFIELD (0x34)
**Purpose**: Sets current field for reading/writing
**Storage**: `[opcode] [field_name]`
**Parameters**:
- field_name: 1 U32 (StringTableEntry hash)

**Total codes**: 2

---

#### OP_SETCURFIELD_ARRAY (0x35)
**Purpose**: Sets current field array
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_LOADFIELD_* (0x36 - 0x38)
**Purpose**: Load field value to stack
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

- **OP_LOADFIELD_UINT (0x36)**
- **OP_LOADFIELD_FLT (0x37)**
- **OP_LOADFIELD_STR (0x38)**

---

#### OP_SAVEFIELD_* (0x39 - 0x3B)
**Purpose**: Save value to current field
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

- **OP_SAVEFIELD_UINT (0x39)**
- **OP_SAVEFIELD_FLT (0x3A)**
- **OP_SAVEFIELD_STR (0x3B)**

---

### TYPE CONVERSION OPCODES (0x3C - 0x44)

All have same format:
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pop from source stack, convert, push to dest stack

- **OP_STR_TO_UINT (0x3C)**: STR → UINT
- **OP_STR_TO_FLT (0x3D)**: STR → FLT
- **OP_STR_TO_NONE (0x3E)**: STR → (discard)
- **OP_FLT_TO_UINT (0x3F)**: FLT → UINT
- **OP_FLT_TO_STR (0x40)**: FLT → STR
- **OP_FLT_TO_NONE (0x41)**: FLT → (discard)
- **OP_UINT_TO_FLT (0x42)**: UINT → FLT
- **OP_UINT_TO_STR (0x43)**: UINT → STR
- **OP_UINT_TO_NONE (0x44)**: UINT → (discard)

---

### IMMEDIATE LOAD OPCODES

#### OP_LOADIMMED_UINT (0x45)
**Purpose**: Load immediate unsigned integer
**Storage**: `[opcode] [value]`
**Parameters**:
- value: 1 U32

**Total codes**: 2

**Stack effect**: Push value to UINT stack

---

#### OP_LOADIMMED_FLT (0x46)
**Purpose**: Load immediate float
**Storage**: `[opcode] [float_index]`
**Parameters**:
- float_index: 1 U32 (index into float table)

**Total codes**: 2

**Stack effect**: Push float to FLT stack

---

#### OP_LOADIMMED_STR (0x47)
**Purpose**: Load immediate string
**Storage**: `[opcode] [string_offset_high] [string_offset_low]`
**Parameters**:
- string_offset: 2 U32s (16-bit offset, big-endian)

**Total codes**: 3

**BrokenFace reads**: `getStringOffset()` which reads 2 bytes as U16
**Stack effect**: Push string to STR stack

---

#### OP_LOADIMMED_IDENT (0x48)
**Purpose**: Load identifier (hash to string)
**Storage**: `[opcode] [ident_hash]`
**Parameters**:
- ident_hash: 1 U32 (StringTableEntry hash)

**Total codes**: 2

**BrokenFace reads**: `getStringOffset()` which reads 2 bytes
**Stack effect**: Push identifier string to STR stack

---

#### OP_TAG_TO_STR (0x49)
**Purpose**: Convert tag to string
**Storage**: `[opcode] [tag_offset_high] [tag_offset_low]`
**Parameters**:
- tag_offset: 2 U32s (16-bit offset)

**Total codes**: 3

**Stack effect**: Push tag string to STR stack

---

### FUNCTION CALL OPCODES

#### OP_CALLFUNC_RESOLVE (0x4A)
**Purpose**: Call function with namespace resolution
**Storage**: `[opcode] [fn_name] [fn_namespace] [callType]`
**Parameters**:
- fn_name: 1 U32
- fn_namespace: 1 U32
- callType: 1 U32 (0=FunctionCall, 1=MethodCall, 2=ParentCall)

**Total codes**: 4

---

#### OP_CALLFUNC (0x4B - 0x4C)
**Purpose**: Call function
**Storage**: `[opcode] [fn_name] [fn_namespace] [callType]`
**Parameters**: Same as CALLFUNC_RESOLVE

**Total codes**: 4

**Stack effect**: 
- Pops: argFrame (function arguments)
- Pushes: return value to STR stack

---

### STRING MANIPULATION OPCODES

#### OP_ADVANCE_STR (0x4D)
**Purpose**: Advance string pointer
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_ADVANCE_STR_APPENDCHAR (0x4E)
**Purpose**: Advance and append character
**Storage**: `[opcode] [char]`
**Parameters**:
- char: 1 U32 (character code)

**Total codes**: 2

---

#### OP_ADVANCE_STR_COMMA (0x4F)
**Purpose**: Advance with comma separator
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_ADVANCE_STR_NUL (0x50)
**Purpose**: Advance with null terminator
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_REWIND_STR (0x51)
**Purpose**: Rewind string stack
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Joins top 2 strings on STR stack

---

#### OP_TERMINATE_REWIND_STR (0x52)
**Purpose**: Terminate rewind operation
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

---

#### OP_COMPARE_STR (0x53)
**Purpose**: Compare strings
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pop 2 strings, push comparison result

---

### STACK MANIPULATION OPCODES

#### OP_PUSH (0x54)
**Purpose**: Push value from STR stack to argFrame
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: 
- Pops: STR stack top
- Pushes: to argFrame[-1] (current argument frame)

---

#### OP_PUSHFRAME (0x55)
**Purpose**: Create new argument frame
**Storage**: `[opcode]`
**Parameters**: None
**Total codes**: 1

**Stack effect**: Pushes empty list to argFrame

---

## SUMMARY TABLE

| Opcode | Name | Params | Total Codes | Used in Scarface |
|--------|------|--------|-------------|------------------|
| 0x00 | OP_FUNC_DECL | 5 + argc | 6 + argc | ✓ |
| 0x01 | OP_CREATE_OBJECT | 6 | 7 | ✓ |
| 0x04 | OP_ADD_OBJECT | 1 | 2 | ✓ |
| 0x05 | OP_END_OBJECT | 1 | 2 | ✓ |
| 0x06 | OP_JMPIFFNOT | 1 | 2 | |
| 0x07 | OP_JMPIFNOT | 1 | 2 | ✓ |
| 0x08 | OP_JMPIFF | 1 | 2 | |
| 0x09 | OP_JMPIF | 1 | 2 | |
| 0x0A | OP_JMPIFNOT_NP | 1 | 2 | |
| 0x0B | OP_JMPIF_NP | 1 | 2 | |
| 0x0C | OP_JMP | 1 | 2 | |
| 0x0D | OP_RETURN | 0 | 1 | ✓ |
| 0x0E-0x13 | Comparisons | 0 | 1 | ✓ |
| 0x14-0x23 | Binary ops | 0 | 1 | ✓ |
| 0x24-0x27 | OP_SETCURVAR | 1 | 2 | ✓ |
| 0x28-0x2B | OP_SETCURVAR_ARRAY | 0 | 1 | |
| 0x2C-0x2E | OP_LOADVAR_* | 0 | 1 | ✓ |
| 0x2F-0x31 | OP_SAVEVAR_* | 0 | 1 | ✓ |
| 0x32 | OP_SETCUROBJECT | 0 | 1 | ✓ |
| 0x33 | OP_SETCUROBJECT_NEW | 0 | 1 | ✓ |
| 0x34 | OP_SETCURFIELD | 1 | 2 | ✓ |
| 0x35 | OP_SETCURFIELD_ARRAY | 0 | 1 | |
| 0x36-0x38 | OP_LOADFIELD_* | 0 | 1 | ✓ |
| 0x39-0x3B | OP_SAVEFIELD_* | 0 | 1 | ✓ |
| 0x3C-0x44 | Type conversions | 0 | 1 | ✓ |
| 0x45 | OP_LOADIMMED_UINT | 1 | 2 | ✓ |
| 0x46 | OP_LOADIMMED_FLT | 1 | 2 | |
| 0x47 | OP_LOADIMMED_STR | 2 | 3 | ✓ |
| 0x48 | OP_LOADIMMED_IDENT | 1 | 2 | ✓ |
| 0x49 | OP_TAG_TO_STR | 2 | 3 | ✓ |
| 0x4A | OP_CALLFUNC_RESOLVE | 3 | 4 | ✓ |
| 0x4B-0x4C | OP_CALLFUNC | 3 | 4 | ✓ |
| 0x4D-0x53 | String ops | varies | varies | ✓ |
| 0x54 | OP_PUSH | 0 | 1 | ✓ |
| 0x55 | OP_PUSHFRAME | 0 | 1 | ✓ |

---

## CRITICAL NOTES FOR IMPLEMENTATION

### 1. String Offsets Are Weird
- OP_LOADIMMED_STR uses 2 U32s for offset (big-endian)
- But they're emitted as SEPARATE codes!
- BrokenFace reads them together via `getStringOffset()`

**Example**:
```python
# To load string at offset 0x012C:
code.emit(OP_LOADIMMED_STR)  # 0x47
code.emit(0x01)               # High byte
code.emit(0x2C)               # Low byte
```

### 2. IdentTable References
When emitting identifier offsets:
```python
offset = self.add_identifier(name)
self.ident_table.add(offset, self.code.get_code_index())
```

The IdentTable tracks WHICH code indices reference WHICH string offsets!

### 3. Method Calls
Method calls require:
```
OP_PUSHFRAME
OP_SETCURVAR <object_var>
OP_LOADVAR_STR
OP_PUSH
[for each argument]:
  OP_LOADIMMED_* <arg>
  OP_PUSH
OP_CALLFUNC <method_name> <namespace> <MethodCall=1>
OP_STR_TO_NONE  # Discard return value if not used
```

### 4. Object Creation Full Sequence
```
OP_LOADIMMED_UINT 0 0        # Parent = 0
OP_PUSHFRAME                  # New arg frame
OP_TAG_TO_STR 0 0            # Convert parent tag
OP_PUSH                       # Push parent to argFrame
OP_LOADIMMED_IDENT <class>   # Load class name
OP_PUSH                       # Push class to argFrame
[for each property]:
  OP_LOADIMMED_IDENT <key>
  OP_PUSH
  OP_LOADIMMED_STR <value>
  OP_PUSH
OP_CREATE_OBJECT 0 <end_ip>  # Create object
OP_ADD_OBJECT 0              # Add to parent
OP_END_OBJECT 0              # End creation
OP_SETCURVAR_CREATE <var>    # Assign to variable
OP_SETCUROBJECT              # Make current object
```

---

## END OF REFERENCE
