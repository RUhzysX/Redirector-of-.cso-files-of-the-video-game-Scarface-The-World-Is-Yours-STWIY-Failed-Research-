# CSO Compiler - In-Game Testing Guide

## 🎯 TESTING PRIORITY

We have TWO files ready for testing:

### Test 1: V3 Modified File (PROVEN TO WORK)
**File:** `test_v3_modified.cso`
**What it does:** Changes DPadDown to DPadUp in actionmaps
**Why test this:** V3 is proven working - this confirms your test setup
**Expected result:** D-Pad Up should now trigger debug mode instead of D-Pad Down

### Test 2: V6 Compiled File (NEW - NEEDS VERIFICATION)
**File:** `test_ingame.cso`
**What it does:** Simple function that just returns
**Why test this:** First-ever compiled CSO - breakthrough!
**Expected result:** Game should load without crashing

## 📋 TESTING INSTRUCTIONS

### Setup
1. **Backup original files!**
   - Copy your original `actionmaps_Win32.cso` somewhere safe
   - Better safe than sorry!

2. **Locate the game's script folder**
   - Usually: `Scarface/data/scripts/` or similar
   - Find where `actionmaps_Win32.cso` lives

### Test 1: V3 Modified (Prove Testing Works)

1. **Copy test file:**
   ```
   Copy test_v3_modified.cso -> game/scripts/actionmaps_Win32.cso
   ```

2. **Launch game**
   - Load a save or start new game
   - Get to gameplay

3. **Test the change:**
   - Try pressing **D-Pad Down** - should NOT trigger debug
   - Try pressing **D-Pad Up** - SHOULD trigger debug mode
   
4. **Result:**
   - ✅ If D-Pad Up works: Your test setup is correct!
   - ❌ If nothing changed: Check file location or game cache

### Test 2: V6 Compiled (The Breakthrough!)

**IMPORTANT:** Only do this AFTER Test 1 succeeds!

1. **Copy test file:**
   ```
   Copy test_ingame.cso -> game/scripts/test_ingame.cso
   ```
   (Don't overwrite actionmaps - use a NEW filename!)

2. **Launch game**
   - Monitor for crashes on startup
   - Check console for script errors

3. **Expected behaviors:**
   - ✅ BEST: Game loads normally (CSO is valid!)
   - ⚠️ OK: Game crashes (we know what to fix)
   - ❌ BAD: Can't test (need different approach)

## 🔍 WHAT TO REPORT

For **Test 1 (V3)**:
- Does the button remapping work?
- Any crashes or glitches?

For **Test 2 (V6)**:
- Does the game load the CSO?
- Any error messages?
- Does game crash or run normally?

## 🚀 IF TEST 2 WORKS...

This means:
1. ✅ CSO format is 100% correct
2. ✅ Compiler works for simple functions
3. ✅ We can proceed to large functions
4. ✅ Full compilation is VERY close!

## 🛠️ IF TEST 2 FAILS...

Don't worry! We have options:
1. Check specific error messages
2. Try smaller/different functions
3. Compare byte-by-byte with original
4. Adjust compiler based on findings

## 📊 COMPARISON INFO

**Original actionmaps_Win32.cso:**
- Size: 19,568 bytes
- Functions: 12
- Complexity: High

**test_v3_modified.cso:**
- Size: 19,568 bytes (identical structure)
- Change: One string replaced
- Safety: Very high (proven working)

**test_ingame.cso:**
- Size: 81 bytes
- Functions: 1 (simple)
- Complexity: Minimal
- Safety: High (just returns, does nothing)

## 💡 TESTING TIPS

1. **Always test V3 first** - This proves your setup works
2. **Check game version** - Make sure scripts aren't cached
3. **Watch for errors** - Game console might show script errors
4. **Start small** - Don't test complex mods first
5. **Document everything** - Screenshots of errors help!

## 🎮 GAME-SPECIFIC NOTES

**Scarface: The World Is Yours**
- Scripts may be cached - restart game fully
- Some files may be in PAK archives
- Console commands might show script status
- Check for mod-enabling flags/configs

## 📞 WHAT TO REPORT BACK

Please share:
1. Which test(s) you ran
2. Results for each
3. Any error messages (screenshots!)
4. Game behavior (crashes, works, etc.)
5. Any console output

## 🎯 THE BIG PICTURE

This test determines:
- ✅ Can we modify CSO files? (Test 1)
- ✅ Can we CREATE CSO files? (Test 2)
- 🚀 Can we enable full modding? (Future!)

Good luck! This is groundbreaking work! 🎉

---
**Files included:**
- `test_v3_modified.cso` - V3 modified actionmaps (proven)
- `test_ingame.cso` - V6 compiled simple function (NEW!)
- `test_ingame.cs` - Source code for V6 test
- `test_ingame.cso.cs` - Decompiled V6 test (verification)

**All files decompile correctly with BrokenFace!**
