#!/usr/bin/env python3
"""
Analyze CSO file structure byte-by-byte
"""

import sys
import struct

def analyze_cso(filepath):
    with open(filepath, 'rb') as f:
        data = f.read()
    
    pos = 0
    
    # Version
    version = struct.unpack('<I', data[pos:pos+4])[0]
    print(f"Version: {version}")
    pos += 4
    
    # Global String Table
    gst_len = struct.unpack('<I', data[pos:pos+4])[0]
    print(f"\nGlobal String Table Length: {gst_len} bytes")
    pos += 4
    gst_end = pos + gst_len
    
    strings = []
    while pos < gst_end:
        end = data.find(b'\x00', pos)
        if end == -1 or end >= gst_end:
            break
        string = data[pos:end].decode('ascii', errors='replace')
        strings.append((pos - 4 - 4, string))  # offset from start of string table
        pos = end + 1
    
    for offset, string in strings[:20]:  # Print first 20
        print(f"  {offset:4d}: {string!r}")
    if len(strings) > 20:
        print(f"  ... and {len(strings) - 20} more")
    
    pos = gst_end
    
    # Function String Table
    fst_len = struct.unpack('<I', data[pos:pos+4])[0]
    print(f"\nFunction String Table Length: {fst_len} bytes")
    pos += 4
    pos += fst_len  # Skip
    
    # Global Float Table
    if pos + 4 <= len(data):
        gft_len = struct.unpack('<I', data[pos:pos+4])[0]
        print(f"\nGlobal Float Table Count: {gft_len}")
        pos += 4 + (gft_len * 8)  # Skip floats
    
    # Function Float Table
    if pos + 4 <= len(data):
        fft_len = struct.unpack('<I', data[pos:pos+4])[0]
        print(f"Function Float Table Count: {fft_len}")
        pos += 4 + (fft_len * 8)  # Skip floats
    else:
        print("\nNo Float Tables present")
        fft_len = 0
    
    # Code Section
    code_count = struct.unpack('<I', data[pos:pos+4])[0]
    print(f"\n=== CODE SECTION ===")
    print(f"Code Count: {code_count}")
    pos += 4
    
    code_start = pos
    code_data = data[pos:]
    
    # Parse first few codes
    print(f"\nFirst 100 bytes of code:")
    i = 0
    code_num = 0
    while i < min(100, len(code_data)) and code_num < 50:
        byte_val = code_data[i]
        print(f"  Code {code_num:3d} @ byte {i:3d}: 0x{byte_val:02X} ({byte_val:3d})", end="")
        
        # Try to identify opcode
        opcode_names = {
            0x00: "OP_FUNC_DECL",
            0x01: "OP_CREATE_OBJECT",
            0x04: "OP_ADD_OBJECT",
            0x05: "OP_END_OBJECT",
            0x07: "OP_JMPIFNOT",
            0x0C: "OP_JMP",
            0x0D: "OP_RETURN",
            0x0E: "OP_CMPEQ",
            0x18: "OP_NOT",
            0x24: "OP_SETCURVAR",
            0x25: "OP_SETCURVAR_CREATE",
            0x2E: "OP_LOADVAR_STR",
            0x31: "OP_SAVEVAR_STR",
            0x32: "OP_SETCUROBJECT",
            0x36: "OP_SETCURFIELD",
            0x37: "OP_SETCURFIELD_ARRAY",
            0x47: "OP_LOADIMMED_STR",
            0x48: "OP_LOADIMMED_IDENT",
            0x4B: "OP_CALLFUNC",
            0x54: "OP_PUSH",
            0x55: "OP_PUSHFRAME",
            0xFF: "EXT_CTRL_CODE",
        }
        
        if byte_val in opcode_names:
            print(f" - {opcode_names[byte_val]}")
            
            # Special handling for OP_FUNC_DECL
            if byte_val == 0x00 and i + 9 < len(code_data):
                print(f"    → name_offset: {(code_data[i+1] << 8) | code_data[i+2]}")
                print(f"    → ns_offset:   {(code_data[i+3] << 8) | code_data[i+4]}")
                print(f"    → pkg_offset:  {(code_data[i+5] << 8) | code_data[i+6]}")
                print(f"    → hasBody:     {code_data[i+7]}")
                print(f"    → end_ip:      {code_data[i+8]}")
                print(f"    → argc:        {code_data[i+9]}")
        else:
            print()
        
        i += 1
        code_num += 1
    
    print(f"\n... (truncated at {code_num} codes / {i} bytes)")
    
    # Find IdentTable
    code_bytes = code_count  # In our format, code_count == byte_count
    ident_start = code_start + code_bytes
    
    if ident_start < len(data):
        print(f"\n=== IDENTTABLE ===")
        print(f"IdentTable starts at byte {ident_start}")
        ident_count = struct.unpack('<I', data[ident_start:ident_start+4])[0]
        print(f"IdentTable entry count: {ident_count}")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <file.cso>")
        sys.exit(1)
    
    analyze_cso(sys.argv[1])
