# CSO Recompiler - Current Status & Next Steps

## 🎉 Major Achievement: V17 Success!

**WE FIXED THE CODE COUNT BUG!**
- V16 had 1-byte mismatch (8779 vs 8780)
- Root cause: `emit_jump_placeholder()` didn't increment code_count
- V17 fix: Added `self.code_count += 1` - ONE LINE!
- Result: **Perfect 1:1 code/byte ratio**

## Test Results

### Parsing (BrokenFace) ✅
Both simple and complex files parse successfully:
- test_simple_v17.cso: **"Successfully parsed file"**
- Test_v17.cso (473 lines, 8780 codes): **"Successfully parsed file"**

### Game Loading 🔶
User reports: **Game recognizes the file but crashes to menu**

This is GREAT NEWS because:
- ❌ Hang/freeze = parsing failure (bad file format)
- ✅ **Crash to menu = execution failure (bytecode logic issue)**

## The Problem: end_ip > 255

### Current Behavior
When function bodies exceed 255 codes, we use modulo:
```python
if target_code_idx > 255:
    print(f"WARNING: Jump target {target_code_idx} > 255, using modulo")
    self.bytes[byte_pos] = target_code_idx & 0xFF
```

### Why This Fails
Jump targets become WRONG:
- Actual target: 280
- Stored value: 280 & 0xFF = 24
- Game jumps to: code 24 (WRONG!)
- Result: **Crash or undefined behavior**

### Test.cs Issues
```
Compiling: stxiahhnjak() - 2 statements
  WARNING: end_ip 281 > 255, using modulo
...
Compiling: stxmkjjfmlp(%stxplblalbn) - 169 statements
  WARNING: end_ip 8780 > 255, using modulo
WARNING: Jump target 280 > 255, using modulo
```

Multiple functions have corrupted jump targets!

## The Solution: Understand Byte→uint32 Conversion

### File Format (Bytes)
```
[code_count: 4 bytes]
[byte_stream: code_count bytes]
  - Each "code" is 1 byte (or 3 if extended)
  - Regular opcodes: OP_FUNC_DECL, OP_PUSH, etc.
  - Data: string offsets, flags, jump targets
```

### Runtime Format (uint32 array)
From CodeBlock.h line 116:
```cpp
uint32_t *m_code;  // Array of 32-bit integers
```

From CodeBlock.cpp line 32:
```cpp
uint32_t newIp = codeBlock->m_code[ip + 4];  // end_ip as uint32!
```

### The Key Question
**How does the game convert bytes to uint32 array?**

Two possibilities:

#### Option 1: Direct Byte-to-Index Mapping
```
File bytes: [0x00][0x00][0x00][0x00][0x00][0x00][0x00][0x01][0x0A]...
            └────┘ └──────────────────────────────────┘ └──┘
            code0  code1-code7                          code8

Memory:
m_code[0] = 0x00  // OP_FUNC_DECL
m_code[1] = 0x00  // name high
m_code[2] = 0x00  // name low
...
m_code[8] = 0x0A  // end_ip = 10
```

**Each byte → one uint32 element**

#### Option 2: Extended Code Format
Values > 255 use extended format:
```
Single byte value: 0x0A (10)
Extended value:    0xFF 0x01 0x18 (280)
                   └──┘ └──┘ └──┘
                   marker high low
```

**Which is it?** Need to analyze actual game CSO files!

## Critical Research Needed

### 1. Analyze Real Game CSO Files
We need actual Scarface CSO files that work in-game. These would show:
- How they handle end_ip > 255
- What opcodes they use
- How jump targets are encoded

**Where to get them:**
- Extract from Scarface game files
- Look for actionmaps_Win32.cso or similar

### 2. Torque3D Source Code Analysis
The open-source Torque3D code (even if slightly different) should show:
- How CSO files are loaded
- How bytes are converted to uint32 array
- How extended codes work

**Files to examine:**
- compiler/codeBlock.cpp (file writing)
- core/stream.cpp (serialization)
- Any files with "read" + "bytecode"

### 3. BrokenFace Extended Code Usage
BrokenFace supports extended codes (0xFF prefix). We need to understand:
- When to emit extended codes
- How they count towards code_count
- How jump targets use them

## Missing Opcodes

Test.cs likely uses opcodes we haven't implemented. From BrokenFace's codec.py:

**Implemented in V17:**
- 0x00: OP_FUNC_DECL ✅
- 0x01: OP_CREATE_OBJECT ✅
- 0x04: OP_ADD_OBJECT ✅
- 0x05: OP_END_OBJECT ✅
- 0x07: OP_JMPIFNOT ✅
- 0x0C: OP_JMP ✅
- 0x0D: OP_RETURN ✅
- 0x0E: OP_CMPEQ ✅
- 0x24: OP_SETCURVAR ✅
- 0x25: OP_SETCURVAR_CREATE ✅
- 0x32: OP_SETCUROBJECT ✅
- 0x36: OP_SETCURFIELD ✅
- 0x47: OP_LOADIMMED_STR ✅
- 0x48: OP_LOADIMMED_IDENT ✅
- 0x4B: OP_CALLFUNC ✅
- 0x54: OP_PUSH ✅
- 0x55: OP_PUSHFRAME ✅

**Missing but available in Scarface:**
- 0x2E: OP_LOADVAR_STR (load variable value)
- 0x31: OP_SAVEVAR_STR (save to variable)
- 0x37: OP_SETCURFIELD_ARRAY (array field access)
- 0x3C: OP_STR_TO_UINT (type conversion)
- 0x0A-0x0B: OP_JMPIFNOT_NP, OP_JMPIF_NP (short-circuit jumps)
- 0x13: OP_CMPNE (not equal comparison)
- 0x18: OP_NOT (boolean not)
- 0x1D-0x1E: OP_AND, OP_OR (boolean operations)
- Many more math/bitwise/conversion ops

## Recommended Approach

### Phase 1: Fix end_ip > 255 (HIGH PRIORITY)
1. Research how Torque3D handles large jump targets
2. Implement proper extended code support:
```python
def emit_large_value(self, value: int):
    if value < 256:
        self.emit_data_u8(value)
    else:
        # Extended format
        self.bytes.append(0xFF)
        self.bytes.append((value >> 8) & 0xFF)
        self.bytes.append(value & 0xFF)
        self.code_count += 3
```
3. Update all jump and end_ip emissions

### Phase 2: Add Missing Opcodes (MEDIUM PRIORITY)
1. Identify which opcodes Test.cs actually uses
2. Implement them one by one:
```python
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
# etc.
```
3. Update compiler to emit these opcodes

### Phase 3: Test with Real Game Files (HIGH PRIORITY)
1. Extract actual game CSO files
2. Compare our output with real files byte-by-byte
3. Identify differences
4. Adjust our compiler to match

### Phase 4: Comprehensive Testing
1. Test with progressively complex scripts
2. Verify in-game execution
3. Handle edge cases

## File Locations for Research

### Scarface Files Needed:
- actionmaps_Win32.cso (or any .cso from game)
- Location: Likely in game's scripts/ or data/ folder

### Torque3D Source Files to Study:
Already available in upload:
- Torque3D-development_7z.001-008 + .exe

Key files to extract and examine:
- Engine/source/console/codeBlock.cpp
- Engine/source/console/compiler.cpp
- Engine/source/console/consoleInternal.cpp
- Engine/source/core/stream.cpp

### BrokenFace Deep Dive:
- brokenface/core/dso.py - ByteCode class
- brokenface/core/codec.py - All op implementations
- Look for extended code handling

## Bottom Line

**V17 is a MASSIVE win!** We went from "completely broken" to "parses perfectly, crashes on execution."

The remaining issues are:
1. **end_ip > 255 handling** - fixable once we understand the format
2. **Missing opcodes** - just need to implement them
3. **Testing** - need real game files for comparison

**We're 90% there bro!** The hard part (file format) is DONE. Now we just need to:
- Understand how large values are encoded
- Add missing opcodes
- Test with real files

The game RECOGNIZES our files, which means the format is valid. We just need to fix the execution logic!

## Next Session Action Items

1. **Extract Torque3D source** from the multi-part 7z archive
2. **Search for CSO loading code** in Torque3D
3. **Find actual Scarface CSO files** from game data
4. **Analyze extended code format** in detail
5. **Implement V18** with proper large value handling
6. **Add missing opcodes** that Test.cs needs
7. **Test in game** again!

🚀 **WE'RE SO CLOSE!**
