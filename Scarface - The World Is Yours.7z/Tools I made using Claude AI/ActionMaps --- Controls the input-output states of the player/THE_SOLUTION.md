# THE SOLUTION - Understanding Code Count

## The Fundamental Misunderstanding

We were treating every byte as a "code". But in the DSO/CSO format:

**CODE** = Opcode only (like OP_FUNC_DECL, OP_PUSH, OP_RETURN)
**DATA** = Parameters/arguments that follow opcodes (string offsets, flags, counts)

## The File Format

```
[code_count: 4 bytes]  ← NUMBER OF OPCODES ONLY
[byte_stream...]        ← Opcodes + their data bytes
```

When the file says `code_count = 10`, it means:
- There are 10 OPCODES in the stream
- But the byte stream might be 50+ bytes because opcodes have data

## Example: OP_FUNC_DECL

**In file**:
```
Byte 0: 0x00 (OP_FUNC_DECL) ← THIS IS CODE #1
Byte 1-2: String offset      ← Data for code #1
Byte 3-4: Namespace offset   ← Data for code #1
Byte 5-6: Package offset     ← Data for code #1
Byte 7: 0x01 (hasBody)       ← THIS IS CODE #2
Byte 8: 0x43 (end_ip)        ← THIS IS CODE #3
Byte 9: 0x00 (argc)          ← THIS IS CODE #4
```

So 10 bytes = 4 codes!

## What We Were Doing Wrong (V15)

```python
self.code.emit(OP_FUNC_DECL)     # code_count++ ✓
self.code.emit_string_ref(...)    # code_count (no change) ✓
self.code.emit_u16be(0x0000)      # code_count (no change) ✓
self.code.emit(0x01)              # code_count++ ✗ WRONG!
```

We were incrementing `code_count` for data bytes like `hasBody`, `end_ip`, `argc`!

These should NOT increment code_count because they're PARAMETERS to the previous opcode, not opcodes themselves!

## The Correct Model

Each opcode has a fixed structure:

**OP_FUNC_DECL** (1 code):
- fnName offset (2 bytes data)
- namespace offset (2 bytes data)  
- package offset (2 bytes data)
- hasBody (1 byte data)
- end_ip (1 byte data)
- argc (1 byte data)
- For each arg: param offset (2 bytes data)

**OP_PUSH** (1 code):
- No data

**OP_CALLFUNC** (1 code):
- func offset (2 bytes data)
- namespace offset (2 bytes data)
- callType (1 byte data)

## Why This Matters

When reading the file:
```python
for i in range(code_count):  # Read THIS many opcodes
    opcode = read_byte()
    if opcode == OP_FUNC_DECL:
        read_name()       # 2 bytes
        read_namespace()  # 2 bytes  
        read_package()    # 2 bytes
        read_hasBody()    # 1 byte
        read_end_ip()     # 1 byte
        read_argc()       # 1 byte
        # etc...
```

The reader KNOWS what data to expect for each opcode!

## The Fix for V16

We need to change our emit model:

```python
def emit_func_decl(self, name_offset, namespace, package, has_body, end_ip, argc, params):
    self.emit_opcode(OP_FUNC_DECL)      # Only THIS increments code_count
    self.emit_data_u16(name_offset)      # Just adds bytes
    self.emit_data_u16(namespace)        # Just adds bytes
    self.emit_data_u16(package)          # Just adds bytes
    self.emit_data_u8(has_body)          # Just adds bytes
    self.emit_data_u8(end_ip)            # Just adds bytes
    self.emit_data_u8(argc)              # Just adds bytes
    for param in params:
        self.emit_data_u16(param)        # Just adds bytes
```

Only `emit_opcode()` increments `code_count`.
All data methods just append to the byte stream without incrementing `code_count`.

## Current Status

**V13**: Works because functions are small and end_ip < 256
**V14**: IdentTable corruption due to byte/code confusion
**V15**: Fixed IdentTable, but still has byte/code confusion
**V16 (needed)**: Proper opcode/data separation

## Next Steps

1. Rewrite CodeBuilder to separate opcodes from data
2. Create emit_opcode() and emit_data_*() methods
3. Update all compile_*() methods to use new API
4. Test with Test.cs

This will be the proper, final fix!
