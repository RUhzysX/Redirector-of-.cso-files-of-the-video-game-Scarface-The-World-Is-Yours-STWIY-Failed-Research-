#!/usr/bin/env py
"""
CSO Recompiler V11 - FINAL WORKING VERSION

Based on analysis of REAL actionmaps_Win32.cso file:

GLOBAL String Table: ALL TorqueScript identifiers
- Function names
- Method names  
- Variable names
- Class names (when used as identifiers)
- Parameter names

FUNCTION String Table: ALL literal string values
- Object names ("GlobalActionMap")
- Device names ("Joystick", "Keyboard0")
- Button/key names ("DPadDown", "Enter", "X")
- Function call strings ("ToggleDebugMode();")
- Any other string literals

Usage: py cso_recompiler_v11_final.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_RETURN = 0x0D
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x34
OP_SAVEFIELD_STR = 0x3B
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        """Add string and return its offset"""
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class CodeBuilder:
    """Builds bytecode with proper IdentTable"""
    def __init__(self):
        self.codes = []
        self.string_refs = {}  # code_index -> (string_offset, is_global)
    
    def emit(self, code: int):
        """Emit a single code"""
        self.codes.append(code)
    
    def emit_string_ref(self, offset: int, is_global: bool):
        """
        Emit a string reference (always big-endian initially).
        IdentTable will track this for patching to little-endian.
        """
        high = (offset >> 8) & 0xFF
        low = offset & 0xFF
        
        # Track this string reference
        code_idx = len(self.codes)
        self.string_refs[code_idx] = (offset, is_global)
        
        # Write as big-endian (will be patched by IdentTable)
        self.codes.append(high)
        self.codes.append(low)
    
    def emit_u16be(self, value: int):
        """Emit a 16-bit value as big-endian (for non-string values)"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes.append(high)
        self.codes.append(low)
    
    def get_code_index(self) -> int:
        """Get current code index"""
        return len(self.codes)
    
    def to_bytes(self) -> bytes:
        """Convert code list to raw bytes"""
        output = bytearray()
        for code in self.codes:
            if code > 0xFE:
                output.append(EXT_CTRL_CODE)
                output.append((code >> 8) & 0xFF)
                output.append(code & 0xFF)
            else:
                output.append(code & 0xFF)
        return bytes(output)


class IdentTable:
    """Tracks string references for patching"""
    def __init__(self):
        # Only GLOBAL strings go in IdentTable
        self.entries = {}  # string_offset -> [code_indices]
    
    def add(self, string_offset: int, code_index: int):
        """Record that a GLOBAL string is referenced at a code index"""
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        """Convert to binary format (Broken Face format)"""
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            # Broken Face reads 4 bytes for offset but only uses first 2
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')  # Padding (2 bytes)
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        
        return bytes(output)


class SimpleParser:
    """Simplified parser"""
    
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
    
    def parse(self) -> List[Tuple[str, List[str], List[str]]]:
        """Returns list of (name, params, raw_statement_lines)"""
        functions = []
        
        i = 0
        while i < len(self.lines):
            line = self.lines[i].strip()
            
            if not line or line.startswith('//'):
                i += 1
                continue
            
            if line.startswith('function '):
                func_data = self.parse_function(i)
                if func_data:
                    functions.append(func_data)
                    name, params, stmts, end_line = func_data
                    i = end_line + 1
                else:
                    i += 1
            else:
                i += 1
        
        return [(n, p, s) for n, p, s, _ in functions]
    
    def parse_function(self, start_line: int) -> Optional[Tuple[str, List[str], List[str], int]]:
        """Parse function starting at line"""
        line = self.lines[start_line].strip()
        
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        i = start_line
        while i < len(self.lines) and '{' not in self.lines[i]:
            i += 1
        
        if i >= len(self.lines):
            return None
        
        statements = []
        i += 1
        brace_count = 1
        
        while i < len(self.lines) and brace_count > 0:
            line = self.lines[i].strip()
            brace_count += line.count('{') - line.count('}')
            
            if brace_count > 0 or (brace_count == 0 and line and line != '}'):
                if line and line != '{' and line != '}':
                    statements.append(line)
            
            i += 1
            if brace_count == 0:
                break
        
        return (name, params, statements, i - 1)


class Statement:
    pass

class ObjectCreation(Statement):
    def __init__(self, var: str, class_name: str, obj_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.obj_name = obj_name
        self.properties = properties

class MethodCall(Statement):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(Statement):
    def __init__(self, func: str, args: List[str]):
        self.func = func
        self.args = args

class Assignment(Statement):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStmt(Statement):
    def __init__(self, value: Optional[str] = None):
        self.value = value


def parse_statement(line: str) -> Optional[Statement]:
    """Parse a single statement line"""
    line = line.strip()
    if not line or line.startswith('//'):
        return None
    
    if line.endswith(';'):
        line = line[:-1].strip()
    
    # Return statement
    if line.startswith('return'):
        rest = line[6:].strip()
        return ReturnStmt(rest if rest else None)
    
    # Object creation
    match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(\s*(\w+)\s*:\s*\"([^"]+)\"(.*)\)', line)
    if match:
        var = match.group(1)
        class_name = match.group(2)
        prop_name = match.group(3)
        prop_value = match.group(4)
        rest = match.group(5)
        
        properties = {prop_name: prop_value}
        
        for prop_match in re.finditer(r',\s*(\w+)\s*:\s*\"([^"]+)\"', rest):
            properties[prop_match.group(1)] = prop_match.group(2)
        
        obj_name = properties.get('Name', properties.get('name', ''))
        return ObjectCreation(var, class_name, obj_name, properties)
    
    # Method call
    match = re.match(r'(%\w+)\.(\w+)\((.*)\)', line)
    if match:
        obj = match.group(1)
        method = match.group(2)
        args_str = match.group(3)
        args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
        return MethodCall(obj, method, args)
    
    # Function call
    match = re.match(r'(\w+)\((.*)\)', line)
    if match:
        func = match.group(1)
        args_str = match.group(2)
        args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
        return FunctionCall(func, args)
    
    # Assignment
    match = re.match(r'(%\w+)\s*=\s*(.+)', line)
    if match:
        var = match.group(1)
        value = match.group(2).strip().strip('"')
        return Assignment(var, value)
    
    return None


class Compiler:
    def __init__(self):
        # GLOBAL: All identifiers (names)
        self.global_strings = StringTable()
        # FUNCTION: All literal values
        self.func_strings = StringTable()
        
        self.code = CodeBuilder()
        self.ident_table = IdentTable()
    
    def add_identifier(self, name: str) -> int:
        """Add identifier to GLOBAL table"""
        return self.global_strings.add(name)
    
    def add_value(self, value: str) -> int:
        """Add value to FUNCTION table"""
        return self.func_strings.add(value)
    
    def compile_function(self, name: str, params: List[str], statements: List[str]):
        """Compile a single function"""
        # Function name → GLOBAL (it's an identifier)
        fn_offset = self.add_identifier(name)
        
        # OP_FUNC_DECL
        func_start = self.code.get_code_index()
        self.code.emit(OP_FUNC_DECL)
        
        # Function name offset (to GLOBAL table)
        self.code.emit_string_ref(fn_offset, is_global=True)
        self.ident_table.add(fn_offset, func_start + 1)
        
        # Namespace (0x0000 = none)
        self.code.emit_u16be(0x0000)
        
        # Package (0x0000 = none)
        self.code.emit_u16be(0x0000)
        
        # Has body (0x01 = yes)
        self.code.emit(0x01)
        
        # End IP - we need to calculate this after compiling the body
        # For now, emit a placeholder that we'll patch later
        end_ip_placeholder_idx = self.code.get_code_index()
        
        # Reserve space for end_ip (we'll determine if extended code is needed later)
        # For now, just emit 0 as placeholder - we might need to expand this
        self.code.emit(0x00)
        
        # Store the CODE INDEX where end_ip starts (not byte index)
        # This is important for IdentTable adjustments if we expand to extended code
        
        # Parameter count
        self.code.emit(len(params))
        
        # Parameters → GLOBAL (they're identifiers)
        for param in params:
            # Remove % prefix if present
            param_name = param[1:] if param.startswith('%') else param
            param_offset = self.add_identifier(param_name)
            self.code.emit_string_ref(param_offset, is_global=True)
            self.ident_table.add(param_offset, self.code.get_code_index() - 2)
        
        # Remember where IdentTable entries start (before function body)
        ident_entries_before = list(self.ident_table.entries.values())
        ident_entries_before_flat = [idx for indices in ident_entries_before for idx in indices]
        
        # NOW compile the function body
        for line in statements:
            stmt = parse_statement(line)
            if stmt:
                self.compile_statement(stmt)
        
        # Calculate end_ip (points to last code of function)
        end_ip = self.code.get_code_index() - 1
        
        # Now patch end_ip properly
        if end_ip > 255:
            # We need extended code (3 codes total: 0xFF + high + low)
            # But we only reserved 1 code, so we need to insert 2 more
            
            # CRITICAL: When we insert 2 extra codes, ALL code indices after the
            # insertion point shift by +2, INCLUDING our end_ip target!
            # So we need to add +2 to end_ip to account for this shift
            end_ip_adjusted = end_ip + 2
            
            # Replace placeholder with 0xFF
            self.code.codes[end_ip_placeholder_idx] = 0xFF
            # Insert high and low bytes
            self.code.codes.insert(end_ip_placeholder_idx + 1, (end_ip_adjusted >> 8) & 0xFF)
            self.code.codes.insert(end_ip_placeholder_idx + 2, end_ip_adjusted & 0xFF)
            
            # CRITICAL: We inserted 2 extra codes, so all IdentTable indices
            # after end_ip_placeholder_idx need to be adjusted by +2
            for offset, indices in self.ident_table.entries.items():
                adjusted_indices = []
                for idx in indices:
                    if idx > end_ip_placeholder_idx:
                        adjusted_indices.append(idx + 2)  # Shift by 2
                    else:
                        adjusted_indices.append(idx)
                self.ident_table.entries[offset] = adjusted_indices
            
            print(f"  Function {name}: end_ip={end_ip} (adjusted to {end_ip_adjusted} for extended code)")
        else:
            # Fits in single byte
            self.code.codes[end_ip_placeholder_idx] = end_ip
    
    def compile_statement(self, stmt: Statement):
        """Compile a statement"""
        if isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.compile_return(stmt)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        """Compile object creation"""
        self.code.emit(OP_PUSHFRAME)
        
        for prop_name, prop_value in stmt.properties.items():
            # Property NAME → FUNCTION (used inside function context)
            #  OP_LOADIMMED_IDENT uses context-sensitive lookup!
            prop_offset = self.add_value(prop_name)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_string_ref(prop_offset, is_global=False)
            self.code.emit(OP_PUSH)
            
            # Property VALUE → FUNCTION (literal)
            val_offset = self.add_value(prop_value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(val_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        # Class NAME → GLOBAL (identifier)
        class_offset = self.add_identifier(stmt.class_name)
        self.code.emit(OP_CREATE_OBJECT)
        self.code.emit_string_ref(class_offset, is_global=True)
        self.ident_table.add(class_offset, self.code.get_code_index() - 2)
        self.code.emit(0x00)
        self.code.emit(0x01)
        
        # ADD_OBJECT
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(0x00)
        
        # Variable NAME → GLOBAL (identifier)
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index() - 2)
        
        # SAVEVAR_STR
        self.code.emit(OP_SAVEVAR_STR)
        
        # END_OBJECT
        self.code.emit(OP_END_OBJECT)
        self.code.emit(0x00)
    
    def compile_method_call(self, stmt: MethodCall):
        """Compile method call"""
        # Object NAME → GLOBAL (identifier)
        obj_name = stmt.obj[1:] if stmt.obj.startswith('%') else stmt.obj
        obj_offset = self.add_identifier(obj_name)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_string_ref(obj_offset, is_global=True)
        self.ident_table.add(obj_offset, self.code.get_code_index() - 2)
        
        self.code.emit(OP_SETCUROBJECT)
        self.code.emit(OP_PUSHFRAME)
        
        # Arguments → FUNCTION (they're values)
        for arg in stmt.args:
            arg_offset = self.add_value(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        # Method NAME → GLOBAL (identifier)
        method_offset = self.add_identifier(stmt.method)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(method_offset, is_global=True)
        self.ident_table.add(method_offset, self.code.get_code_index() - 2)
        self.code.emit_u16be(0x0000)
        self.code.emit(0x01)  # method call
    
    def compile_function_call(self, stmt: FunctionCall):
        """Compile function call"""
        self.code.emit(OP_PUSHFRAME)
        
        # Arguments → FUNCTION (values)
        for arg in stmt.args:
            arg_offset = self.add_value(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        # Function NAME → GLOBAL (identifier)
        func_offset = self.add_identifier(stmt.func)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(func_offset, is_global=True)
        self.ident_table.add(func_offset, self.code.get_code_index() - 2)
        self.code.emit_u16be(0x0000)
        self.code.emit(0x00)  # function call
    
    def compile_assignment(self, stmt: Assignment):
        """Compile assignment"""
        # Value → FUNCTION (literal)
        val_offset = self.add_value(stmt.value)
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_string_ref(val_offset, is_global=False)
        
        # Variable NAME → GLOBAL (identifier)
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index() - 2)
        
        self.code.emit(OP_SAVEVAR_STR)
    
    def compile_return(self, stmt: ReturnStmt):
        """Compile return"""
        if stmt.value:
            if stmt.value.startswith('%'):
                # Variable NAME → GLOBAL
                var_name = stmt.value[1:]
                var_offset = self.add_identifier(var_name)
                self.code.emit(OP_SETCURVAR)
                self.code.emit_string_ref(var_offset, is_global=True)
                self.ident_table.add(var_offset, self.code.get_code_index() - 2)
                self.code.emit(OP_LOADVAR_STR)
        
        self.code.emit(OP_RETURN)
    
    def write_cso(self, output_path: str):
        """Write CSO file"""
        with open(output_path, 'wb') as f:
            # Version
            f.write(struct.pack('<I', 1))
            
            # Global String Table (IDENTIFIERS)
            global_str_bytes = self.global_strings.to_bytes()
            f.write(struct.pack('<I', len(global_str_bytes)))
            f.write(global_str_bytes)
            
            # Global Float Table (empty)
            f.write(struct.pack('<I', 0))
            
            # Function String Table (VALUES)
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            # Function Float Table (empty)
            f.write(struct.pack('<I', 0))
            
            # Bytecode - CODE COUNT
            code_count = len(self.code.codes)
            f.write(struct.pack('<I', code_count))
            f.write(self.code.to_bytes())
            
            # IdentTable (only GLOBAL strings)
            f.write(self.ident_table.to_bytes())


def main():
    if len(sys.argv) != 3:
        print("Usage: py cso_recompiler_v11_final.py input.cs output.cso")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        source = f.read()
    
    parser = SimpleParser(source)
    functions = parser.parse()
    
    print(f"Parsed {len(functions)} functions")
    
    compiler = Compiler()
    for name, params, statements in functions:
        print(f"Compiling function: {name}({', '.join(params)})")
        print(f"  Statements: {len(statements)}")
        compiler.compile_function(name, params, statements)
    
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V11 - FINAL)")
    print(f"  Code count: {len(compiler.code.codes)}")
    print(f"  Global strings: {len(compiler.global_strings.strings)} (identifiers)")
    print(f"  Function strings: {len(compiler.func_strings.strings)} (values)")
    print(f"  IdentTable entries: {len(compiler.ident_table.entries)}")
    print(f"\nString Table Usage:")
    print(f"  GLOBAL (identifiers): {', '.join(compiler.global_strings.strings[:5])}...")
    print(f"  FUNCTION (values): {', '.join(compiler.func_strings.strings[:5])}...")


if __name__ == '__main__':
    main()
