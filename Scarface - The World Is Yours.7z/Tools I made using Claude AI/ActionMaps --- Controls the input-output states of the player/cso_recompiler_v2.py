#!/usr/bin/env python3
"""
WORKING CSO Recompiler for Scarface: The World Is Yours
Correctly encodes StringTableEntry references using the discovered format

The key discovery: StringTableEntry values are encoded as:
  32-bit value = 0xTTZZYYXX (little-endian)
  Where: XX YY ZZ = offset (big-endian 24-bit)
         TT = type/flag byte

Usage: python3 cso_recompiler_v2.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional

# Opcode definitions
OP_FUNC_DECL = 0
OP_CREATE_OBJECT = 1
OP_ADD_OBJECT = 4
OP_END_OBJECT = 5
OP_RETURN = 13
OP_SETCURVAR = 36
OP_SETCURVAR_CREATE = 37
OP_SETCUROBJECT = 50
OP_SETCUROBJECT_NEW = 51
OP_SETCURFIELD = 52
OP_LOADIMMED_STR = 71
OP_LOADIMMED_IDENT = 72
OP_CALLFUNC = 75
OP_PUSH = 84

# Call types
FUNC_CALL = 0
METHOD_CALL = 1

# String entry types (discovered from original CSO)
STR_TYPE_GLOBAL = 0x01
STR_TYPE_FUNC = 0x00


def encode_string_entry(offset: int, entry_type: int = STR_TYPE_GLOBAL) -> int:
    """
    Encode a string table offset as a StringTableEntry value.
    
    Format: 0xTTZZYYXX where XX YY ZZ is offset (big-endian), TT is type
    """
    if offset > 0xFFFFFF:
        raise ValueError(f"Offset {offset} too large (max 0xFFFFFF)")
    
    # Convert offset to 3 bytes (big-endian)
    offset_bytes = struct.pack('>I', offset)[1:]  # Take last 3 bytes
    
    # Combine with type byte
    full_bytes = offset_bytes + bytes([entry_type])
    
    # Return as little-endian uint32
    return struct.unpack('<I', full_bytes)[0]


class StringTable:
    """Manages a string table for CSO files"""
    
    def __init__(self, name: str = ""):
        self.name = name
        self.strings: List[str] = []
        self.offsets: Dict[str, int] = {}
    
    def add(self, string: str) -> int:
        """Add a string to the table and return its offset"""
        if string in self.offsets:
            return self.offsets[string]
        
        # Calculate offset
        offset = sum(len(s) + 1 for s in self.strings)
        self.strings.append(string)
        self.offsets[string] = offset
        return offset
    
    def get_offset(self, string: str) -> Optional[int]:
        """Get the offset of a string if it exists"""
        return self.offsets.get(string)
    
    def to_bytes(self) -> bytes:
        """Convert the string table to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)
    
    def __len__(self) -> int:
        """Return the total size in bytes"""
        return sum(len(s) + 1 for s in self.strings)


class BytecodeBuilder:
    """Builds bytecode instruction stream"""
    
    def __init__(self, global_strings: StringTable, func_strings: StringTable):
        self.code: List[int] = []
        self.global_strings = global_strings
        self.func_strings = func_strings
    
    def emit(self, *values: int):
        """Emit one or more uint32 values"""
        self.code.extend(values)
    
    def emit_global_string_ref(self, string: str):
        """Emit a reference to a global string"""
        offset = self.global_strings.add(string)
        encoded = encode_string_entry(offset, STR_TYPE_GLOBAL)
        self.emit(encoded)
    
    def emit_func_string_ref(self, string: str):
        """Emit a reference to a function string"""
        offset = self.func_strings.add(string)
        encoded = encode_string_entry(offset, STR_TYPE_FUNC)
        self.emit(encoded)
    
    def get_ip(self) -> int:
        """Get current instruction pointer"""
        return len(self.code)
    
    def patch(self, index: int, value: int):
        """Patch a value at a specific index"""
        if 0 <= index < len(self.code):
            self.code[index] = value
    
    def to_bytes(self) -> bytes:
        """Convert bytecode to binary format"""
        return b''.join(struct.pack('<I', val) for val in self.code)
    
    def __len__(self) -> int:
        """Return number of instructions"""
        return len(self.code)


class SimpleParser:
    """Very simple parser for ActionMaps-style scripts"""
    
    def __init__(self, source: str):
        self.source = source
        self.functions = []
    
    def parse(self):
        """Parse all functions"""
        # Match function definitions
        func_pattern = r'function\s+(\w+)\s*\(\s*\)\s*\{([^\}]*(?:\{[^\}]*\}[^\}]*)*)\}'
        
        for match in re.finditer(func_pattern, self.source, re.MULTILINE | re.DOTALL):
            func_name = match.group(1)
            body = match.group(2)
            self.functions.append((func_name, body))
        
        return self.functions


class CSOCompilerV2:
    """Correct CSO compiler with proper string encoding"""
    
    def __init__(self):
        self.global_strings = StringTable("global")
        self.func_strings = StringTable("function")
        self.bytecode = None
    
    def compile_file(self, source: str) -> bytes:
        """Compile source code to CSO binary"""
        
        # Parse
        parser = SimpleParser(source)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions")
        
        # Initialize bytecode builder
        self.bytecode = BytecodeBuilder(self.global_strings, self.func_strings)
        
        # Compile each function
        for func_name, func_body in functions:
            self.compile_function(func_name, func_body)
        
        # Build final binary
        return self.build_cso()
    
    def compile_function(self, func_name: str, func_body: str):
        """Compile a single function"""
        
        # Emit OP_FUNC_DECL
        self.bytecode.emit(OP_FUNC_DECL)
        self.bytecode.emit_global_string_ref(func_name)
        self.bytecode.emit_global_string_ref("")  # namespace (empty)
        self.bytecode.emit_global_string_ref("")  # package (empty)
        self.bytecode.emit(1)  # has_body = true
        
        # Reserve space for newip
        newip_index = self.bytecode.get_ip()
        self.bytecode.emit(0)  # Will be patched
        
        self.bytecode.emit(0)  # argc = 0
        
        # Compile body
        self.compile_statements(func_body)
        
        # Add return
        self.bytecode.emit(OP_RETURN)
        
        # Patch newip
        func_end_ip = self.bytecode.get_ip()
        self.bytecode.patch(newip_index, func_end_ip)
    
    def compile_statements(self, body: str):
        """Compile statements in function body"""
        # Split by semicolons
        statements = [s.strip() for s in body.split(';') if s.strip()]
        
        for stmt in statements:
            self.compile_statement(stmt)
    
    def compile_statement(self, stmt: str):
        """Compile a single statement"""
        stmt = stmt.strip()
        
        if not stmt or stmt.startswith('//'):
            return
        
        # Return statement
        if stmt.startswith('return'):
            # Parse: return %var; or return;
            if '%' in stmt:
                var_name = stmt.split()[1].rstrip(';')
                # Load variable
                self.bytecode.emit(OP_SETCURVAR)
                self.bytecode.emit_global_string_ref(var_name)
            self.bytecode.emit(OP_RETURN)
        
        # Variable assignment with object creation
        elif '=' in stmt and 'new ' in stmt:
            self.compile_object_creation(stmt)
        
        # Method call
        elif '.' in stmt and '(' in stmt:
            self.compile_method_call(stmt)
        
        # If statement (very basic)
        elif stmt.startswith('if'):
            pass  # Skip for now
    
    def compile_object_creation(self, stmt: str):
        """Compile: %var = new ClassName(Name : "value", ...)"""
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        var_name = match.group(1)
        class_name = match.group(2)
        args_str = match.group(3)
        
        # OP_CREATE_OBJECT
        self.bytecode.emit(OP_CREATE_OBJECT)
        self.bytecode.emit_global_string_ref(class_name)
        self.bytecode.emit(0)  # is_datablock
        self.bytecode.emit(0)  # is_internal
        self.bytecode.emit(0)  # is_singleton
        self.bytecode.emit(0)  # line_number
        self.bytecode.emit(0)  # fail_jump
        
        # Parse properties: Name : "value"
        if args_str.strip():
            prop_pattern = r'(\w+)\s*:\s*"([^"]*)"'
            for prop_match in re.finditer(prop_pattern, args_str):
                prop_name = prop_match.group(1)
                prop_value = prop_match.group(2)
                
                # SETCURFIELD
                self.bytecode.emit(OP_SETCURFIELD)
                self.bytecode.emit_global_string_ref(prop_name)
                
                # LOADIMMED_STR
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_func_string_ref(prop_value)
                
                # Note: Original probably uses SAVEFIELD_STR here
                # but we'll keep it simple for now
        
        # OP_ADD_OBJECT
        self.bytecode.emit(OP_ADD_OBJECT)
        self.bytecode.emit(0)  # place_at_root
        
        # OP_END_OBJECT
        self.bytecode.emit(OP_END_OBJECT)
        self.bytecode.emit(0)  # place_at_root
        
        # SETCUROBJECT_NEW
        self.bytecode.emit(OP_SETCUROBJECT_NEW)
        
        # Assign to variable
        self.bytecode.emit(OP_SETCURVAR_CREATE)
        self.bytecode.emit_global_string_ref(var_name)
    
    def compile_method_call(self, stmt: str):
        """Compile: %obj.method(arg1, arg2, ...)"""
        match = re.match(r'(%\w+)\.(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        obj_var = match.group(1)
        method_name = match.group(2)
        args_str = match.group(3)
        
        # Load object
        self.bytecode.emit(OP_SETCURVAR)
        self.bytecode.emit_global_string_ref(obj_var)
        # Note: Original uses LOADVAR_STR + SETCUROBJECT here
        self.bytecode.emit(OP_SETCUROBJECT)
        
        # Push arguments
        if args_str.strip():
            args = [a.strip() for a in args_str.split(',')]
            for arg in args:
                self.compile_argument(arg)
                self.bytecode.emit(OP_PUSH)
        
        # Call method
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_global_string_ref(method_name)
        self.bytecode.emit_global_string_ref("")  # namespace
        self.bytecode.emit(METHOD_CALL)
    
    def compile_argument(self, arg: str):
        """Compile a function argument"""
        arg = arg.strip()
        
        # String literal
        if arg.startswith('"') and arg.endswith('"'):
            string_val = arg[1:-1]
            self.bytecode.emit(OP_LOADIMMED_STR)
            self.bytecode.emit_func_string_ref(string_val)
        
        # Variable reference
        elif arg.startswith('%'):
            self.bytecode.emit(OP_SETCURVAR)
            self.bytecode.emit_global_string_ref(arg)
            # Note: Original uses LOADVAR_STR here
        
        # Identifier
        else:
            self.bytecode.emit(OP_LOADIMMED_IDENT)
            self.bytecode.emit_global_string_ref(arg)
    
    def build_cso(self) -> bytes:
        """Build the final CSO binary"""
        output = bytearray()
        
        # Version
        output.extend(struct.pack('<I', 1))
        
        # Global string table
        global_strings_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(global_strings_bytes)))
        output.extend(global_strings_bytes)
        
        # Function string table
        output.extend(struct.pack('<I', 0))  # Marker
        function_strings_bytes = self.func_strings.to_bytes()
        output.extend(struct.pack('<I', len(function_strings_bytes)))
        output.extend(function_strings_bytes)
        
        # Code size field (0)
        output.extend(struct.pack('<I', 0))
        
        # Actual bytecode size in bytes
        bytecode_bytes = self.bytecode.to_bytes()
        output.extend(struct.pack('<I', len(bytecode_bytes)))
        
        # Bytecode
        output.extend(bytecode_bytes)
        
        # Note: We're not including line break data/metadata for now
        # This might be needed for the game to accept the file
        
        return bytes(output)


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_recompiler_v2.py input.cs output.cso")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    with open(input_file, 'r') as f:
        source = f.read()
    
    compiler = CSOCompilerV2()
    cso_data = compiler.compile_file(source)
    
    with open(output_file, 'wb') as f:
        f.write(cso_data)
    
    print(f"Compiled to {output_file} ({len(cso_data)} bytes)")
    print(f"Global strings: {len(compiler.global_strings.strings)}")
    print(f"Function strings: {len(compiler.func_strings.strings)}")
    print(f"Bytecode: {len(compiler.bytecode)} instructions")


if __name__ == "__main__":
    main()
