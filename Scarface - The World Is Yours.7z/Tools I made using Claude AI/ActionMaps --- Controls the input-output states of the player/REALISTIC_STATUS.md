# CSO Compiler V6 - Current Status & Workaround

## 🎯 The Reality Check

Your Test.cs contains the FULL actionmaps code with all its complexity. V6 can't compile this yet because it only implements **basic function declarations**, not the full TorqueScript language.

## ✅ What V6 CAN Compile (Successfully Tested)

### 1. Empty Functions
```torquescript
function test() {
    return;
}
```
**Status:** ✅ Works perfectly - compiles and decompiles

### 2. Functions with Parameters
```torquescript
function test(%param1, %param2) {
    return;
}
```
**Status:** ✅ Works perfectly

### 3. Multiple Functions
```torquescript
function test1() { return; }
function test2() { return; }
function test3() { return; }
```
**Status:** ✅ Works perfectly

## ❌ What V6 CANNOT Compile Yet

### 1. Object Creation
```torquescript
%obj = new ActionMap(Name : "test");
```
**Status:** ❌ Parser sees it but doesn't generate correct bytecode

### 2. Method Calls
```torquescript
%obj.bindCommand("key", "command");
```
**Status:** ❌ Not implemented

### 3. Function Calls
```torquescript
someFunction(%arg1, %arg2);
```
**Status:** ❌ Not implemented

### 4. If Statements
```torquescript
if (condition) {
    // code
}
```
**Status:** ❌ Not implemented

### 5. Variable Assignment
```torquescript
%var = "value";
```
**Status:** ❌ Not implemented (except in object creation)

### 6. Property Initialization Blocks
```torquescript
%obj = new Class() {
    property = "value";
};
```
**Status:** ❌ Not implemented

## 🔍 Why Your Test.cs Fails

Looking at the first function in actionmaps:
```torquescript
function stxlagdgapl()
{
    %stxkeipamak = new stxilbjjlhp(Name : "GlobalActionMap");  // ❌ Object creation
    %stxkeipamak.stxijmcdenl("Joystick", "DPadDown R3", "...");  // ❌ Method call
    %stxbkkoegpo.stxbghnpjpk(%stxkeipamak);  // ❌ Method call
    return %stxkeipamak;  // ❌ Return with value
}
```

**Every statement** uses features V6 doesn't implement! That's why you get IndexError - the bytecode generated is incomplete/wrong.

## 💡 Current Workarounds

### Option 1: Use V3 (String Modifier)
**Status:** ✅ **PROVEN WORKING IN-GAME**

```bash
python3 cso_recompiler_v3.py original.cso modified.cso "old_string" "new_string"
```

**What it can do:**
- Change button mappings
- Modify any string in the file
- **100% safe** - maintains exact file structure

**Limitations:**
- Can't add new functions
- Can't change logic
- Can only modify strings

### Option 2: Add Simple Test Functions (V6)
**Status:** ✅ **WORKS** - but only for empty/basic functions

Create a separate CSO with just your test function:
```torquescript
// my_test.cs
function myTestFunction()
{
    return;
}
```

Compile:
```bash
python3 cso_recompiler_v6.py my_test.cs my_test.cso
```

**Works:** ✅ File compiles and decompiles
**In-game:** Unknown (needs testing)

### Option 3: Manually Edit Original + V3
**Status:** Experimental

1. Decompile original with BrokenFace
2. Hand-edit the decompiled .cs file (carefully!)
3. Use V3 to modify specific strings in the original .cso
4. Test each change incrementally

## 🚀 The Path to Full Compilation

To compile the full actionmaps, V6 needs these additions:

### Phase 1: Basic Statements (Est: 2-4 hours)
- [ ] Variable assignments
- [ ] Function calls
- [ ] Method calls
- [ ] Return with value

### Phase 2: Control Flow (Est: 2-3 hours)
- [ ] If statements
- [ ] If-else statements
- [ ] While loops
- [ ] For loops

### Phase 3: Objects (Est: 3-4 hours)
- [ ] Object creation
- [ ] Property initialization
- [ ] Object property blocks

### Phase 4: Advanced (Est: 2-3 hours)
- [ ] Extended end_ip (for large functions)
- [ ] Float table population
- [ ] Complex expressions

### Phase 5: Natives Integration (Est: 2-3 hours)
- [ ] Load natives.json
- [ ] Validate function calls
- [ ] Validate method calls
- [ ] Check argument counts

**Total estimated time:** 11-17 hours of focused development

## 📊 Comparison: What Works

| Feature | V3 (Modifier) | V6 (Compiler) | Needed for Actionmaps |
|---------|---------------|---------------|----------------------|
| String replacement | ✅ | N/A | ✅ |
| Empty functions | N/A | ✅ | ✅ |
| With parameters | N/A | ✅ | ✅ |
| Object creation | ❌ | ❌ | ✅ |
| Method calls | ❌ | ❌ | ✅ |
| If statements | ❌ | ❌ | ✅ |
| Function calls | ❌ | ❌ | ✅ |
| In-game tested | ✅ | ⚠️ | ✅ |

## 🎯 Recommended Approach

**For immediate modding:**
1. **Use V3** to modify button mappings (proven working!)
2. Test simple V6 functions in-game (to verify format is correct)
3. Report back results

**For full compilation:**
1. I implement Phase 1-3 (basic statements + control flow + objects)
2. You test with progressively complex functions
3. We iterate until full actionmaps compiles

## 🔧 Test Suite Needed

To properly develop V6, we need test cases:

1. ✅ **Empty function** - DONE, WORKS
2. ✅ **With parameters** - DONE, WORKS  
3. ⚠️ **Object creation** - Parser done, bytecode incomplete
4. ❌ **Method call** - Not implemented
5. ❌ **If statement** - Not implemented
6. ❌ **Function call** - Not implemented
7. ❌ **Complex mix** - Not implemented

## 💡 Quick Win Option

If you just want to test V6's format in-game, create a minimal addon:

```torquescript
// addon.cs
function myCustomFunction()
{
    return;
}

function anotherTest(%param1)
{
    return;
}
```

This will compile with V6 and let you verify the format works in-game without needing complex features!

## 🎮 Immediate Next Steps

**Choice A: Test What Works**
1. Compile simple addon with V6
2. Test in-game
3. Verify format is correct
4. Then I implement more features

**Choice B: Full Development**
1. I implement all needed features (11-17 hours)
2. Test with actionmaps
3. Debug until it works

**Choice C: Use V3 Now**
1. Modify strings with V3
2. Mod the game today
3. Full compiler later

What would you prefer? 🤔

---

**Bottom line:** V6 has the CORRECT file format (proven by successful decompilation), but it doesn't implement enough TorqueScript features to compile complex code like actionmaps. It's like having a car with a perfect frame but no engine yet - we need to build the engine!
