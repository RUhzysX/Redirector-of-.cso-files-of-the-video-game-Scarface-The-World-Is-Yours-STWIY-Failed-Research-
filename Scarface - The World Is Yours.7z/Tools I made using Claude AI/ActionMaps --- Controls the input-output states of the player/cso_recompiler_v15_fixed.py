#!/usr/bin/env py
"""
CSO Recompiler V15 - FIXED IdentTable Bug

CRITICAL FIX: Properly track CODE count vs BYTE count
- Extended codes are 3 bytes but count as 1 CODE
- File format expects CODE count, not byte count
- IdentTable indices reference CODE positions, not byte positions

Usage: py cso_recompiler_v15_fixed.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional, Any

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMPIF = 0x09
OP_JMPIFNOT_NP = 0x0A
OP_JMPIF_NP = 0x0B
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_CMPEQ = 0x0E
OP_CMPLT = 0x0F
OP_CMPLE = 0x10
OP_CMPGR = 0x11
OP_CMPGE = 0x12
OP_CMPNE = 0x13
OP_NOT = 0x18
OP_AND = 0x1D
OP_OR = 0x1E
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_STR_TO_UINT = 0x3C
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF

CALL_FUNCTION = 0x00
CALL_METHOD = 0x01

class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        if s in self.offsets:
            return self.offsets[s]
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)

class CodeBuilder:
    """
    CRITICAL: This tracks LOGICAL codes, not bytes!
    Extended codes (0xFF + high + low) count as ONE code.
    """
    def __init__(self):
        self.codes = []  # Byte array (may have extended codes)
        self.code_count = 0  # LOGICAL code count (what goes in file header)
        self.string_refs = {}
        self.jump_patches = {}
        self.labels = {}
    
    def emit(self, code: int):
        """Emit a code - might be extended"""
        if code >= 0xFF or code < 0:
            # Extended code: 3 bytes (0xFF is reserved as EXT_CTRL_CODE)
            self.codes.append(EXT_CTRL_CODE)
            self.codes.append((code >> 8) & 0xFF)
            self.codes.append(code & 0xFF)
        else:
            # Regular code: 1 byte (0x00 to 0xFE)
            self.codes.append(code & 0xFF)
        
        # ALWAYS increment code count by 1
        self.code_count += 1
    
    def emit_string_ref(self, offset: int, is_global: bool):
        """Emit string reference (2 bytes, NOT a code)"""
        high = (offset >> 8) & 0xFF
        low = offset & 0xFF
        code_idx = self.code_count  # Current code index
        self.string_refs[code_idx] = (offset, is_global)
        self.codes.append(high)
        self.codes.append(low)
        # NOTE: These 2 bytes are PART of the previous code's data
        # They do NOT increment code_count
    
    def emit_u16be(self, value: int):
        """Emit 16-bit value (NOT a code, part of previous code's data)"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes.append(high)
        self.codes.append(low)
    
    def emit_jump_placeholder(self, label: str):
        """Emit placeholder for jump target"""
        idx = self.code_count
        if label not in self.jump_patches:
            self.jump_patches[label] = []
        self.jump_patches[label].append(idx)
        self.codes.append(0x00)  # Placeholder byte
        # This byte is part of the jump instruction's data, not a new code
    
    def place_label(self, label: str):
        """Place label at current CODE position"""
        self.labels[label] = self.code_count
    
    def patch_jumps(self):
        """
        Patch jump targets.
        CRITICAL: We cannot use insert() because it breaks code_count tracking!
        Instead, we replace the placeholder byte with the target value.
        """
        for label, indices in self.jump_patches.items():
            if label not in self.labels:
                print(f"WARNING: Label {label} not found!")
                continue
            
            target = self.labels[label]
            
            for code_idx in indices:
                # Find the byte position of this code's jump target byte
                byte_pos = self._code_index_to_byte_pos(code_idx)
                
                if target > 255:
                    # Extended jump: need to write 0xFF + high + low
                    # But we only have 1 placeholder byte!
                    # Solution: Write modulo for now (limitation)
                    print(f"WARNING: Jump target {target} > 255, using modulo 256")
                    self.codes[byte_pos] = target & 0xFF
                else:
                    # Simple: write target
                    self.codes[byte_pos] = target
    
    def _code_index_to_byte_pos(self, code_idx: int) -> int:
        """
        Convert code index to byte position.
        Must scan through codes counting extended codes.
        """
        byte_pos = 0
        current_code = 0
        i = 0
        
        while current_code < code_idx and i < len(self.codes):
            if self.codes[i] == EXT_CTRL_CODE:
                i += 3  # Extended code
            else:
                i += 1  # Regular code
            current_code += 1
        
        # Now we're at the start of code_idx
        # The jump placeholder byte is right after the jump opcode
        # which was already counted, so return current position
        return i
    
    def get_code_index(self) -> int:
        """Return current LOGICAL code index"""
        return self.code_count
    
    def to_bytes(self) -> bytes:
        """Return byte stream as-is"""
        return bytes(self.codes)

class IdentTable:
    def __init__(self):
        self.entries = {}
    
    def add(self, string_offset: int, code_index: int):
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def adjust_indices(self, after: int, shift: int):
        """Adjust indices after a certain code position"""
        for offset, indices in self.entries.items():
            self.entries[offset] = [idx + shift if idx > after else idx for idx in indices]
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        return bytes(output)

# [AST Nodes - same as V14]
class ASTNode:
    pass

class ObjectCreation(ASTNode):
    def __init__(self, var: str, class_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.properties = properties

class MethodCall(ASTNode):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(ASTNode):
    def __init__(self, func: str, args: List[Any]):
        self.func = func
        self.args = args

class Assignment(ASTNode):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStmt(ASTNode):
    def __init__(self, value: Optional[str] = None):
        self.value = value

class IfStatement(ASTNode):
    def __init__(self, condition: Any, then_body: List[ASTNode], else_body: List[ASTNode] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body or []

class WhileLoop(ASTNode):
    def __init__(self, condition: Any, body: List[ASTNode]):
        self.condition = condition
        self.body = body

class NotExpr(ASTNode):
    def __init__(self, expr: Any):
        self.expr = expr

class BinaryOp(ASTNode):
    def __init__(self, op: str, left: Any, right: Any):
        self.op = op
        self.left = left
        self.right = right

class VarRef(ASTNode):
    def __init__(self, name: str):
        self.name = name

class Literal(ASTNode):
    def __init__(self, value: str):
        self.value = value

# [Parser - same as V14, including all the methods]
class Parser:
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
        self.pos = 0
    
    def parse(self) -> List[Tuple[str, List[str], List[ASTNode]]]:
        functions = []
        while self.pos < len(self.lines):
            line = self.lines[self.pos].strip()
            if line.startswith('function '):
                func = self.parse_function()
                if func:
                    functions.append(func)
            else:
                self.pos += 1
        return functions
    
    def parse_function(self) -> Optional[Tuple[str, List[str], List[ASTNode]]]:
        line = self.lines[self.pos].strip()
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            self.pos += 1
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
            self.pos += 1
        self.pos += 1
        
        body = self.parse_block()
        return (name, params, body)
    
    def parse_block(self) -> List[ASTNode]:
        statements = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                self.pos += 1
                if brace_count == 0:
                    break
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    statements.append(stmt)
            elif line.startswith('while '):
                stmt = self.parse_while_loop()
                if stmt:
                    statements.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    statements.append(stmt)
                self.pos += 1
        
        return statements
    
    def parse_if_statement(self) -> Optional[IfStatement]:
        line = self.lines[self.pos].strip()
        
        match = re.match(r'if\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        self.pos += 1
        
        then_body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    then_body.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    then_body.append(stmt)
                self.pos += 1
        
        else_body = []
        if self.pos < len(self.lines):
            next_line = self.lines[self.pos].strip()
            if next_line.startswith('else'):
                self.pos += 1
                while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                    self.pos += 1
                self.pos += 1
                
                brace_count = 1
                while self.pos < len(self.lines) and brace_count > 0:
                    line = self.lines[self.pos].strip()
                    
                    if '}' in line:
                        brace_count -= 1
                        if brace_count == 0:
                            self.pos += 1
                            break
                        self.pos += 1
                        continue
                    
                    if '{' in line:
                        brace_count += 1
                        self.pos += 1
                        continue
                    
                    if not line or line.startswith('//'):
                        self.pos += 1
                        continue
                    
                    stmt = self.parse_statement(line)
                    if stmt:
                        else_body.append(stmt)
                    self.pos += 1
        
        return IfStatement(condition, then_body, else_body)
    
    def parse_while_loop(self) -> Optional[WhileLoop]:
        line = self.lines[self.pos].strip()
        
        match = re.match(r'while\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        self.pos += 1
        
        body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            stmt = self.parse_statement(line)
            if stmt:
                body.append(stmt)
            self.pos += 1
        
        return WhileLoop(condition, body)
    
    def parse_condition(self, cond_str: str) -> Any:
        cond_str = cond_str.strip()
        
        if cond_str.startswith('!(') and cond_str.endswith(')'):
            inner = cond_str[2:-1].strip()
            inner_expr = self.parse_condition(inner)
            return NotExpr(inner_expr)
        
        for op in ['==', '!=', '<=', '>=', '<', '>']:
            if op in cond_str:
                parts = cond_str.split(op, 1)
                if len(parts) == 2:
                    left = self.parse_condition(parts[0].strip())
                    right = self.parse_condition(parts[1].strip())
                    return BinaryOp(op, left, right)
        
        if '&&' in cond_str:
            parts = cond_str.split('&&', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('&&', left, right)
        
        if '||' in cond_str:
            parts = cond_str.split('||', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('||', left, right)
        
        match = re.match(r'(\w+)\s*\((.*)\)', cond_str)
        if match:
            func_name = match.group(1)
            args_str = match.group(2)
            args = []
            for arg in args_str.split(','):
                arg = arg.strip()
                if arg.startswith('%'):
                    args.append(VarRef(arg[1:]))
                else:
                    args.append(Literal(arg.strip('"')))
            return FunctionCall(func_name, args)
        
        if cond_str.startswith('%'):
            return VarRef(cond_str[1:])
        
        return Literal(cond_str.strip('"'))
    
    def parse_statement(self, line: str) -> Optional[ASTNode]:
        line = line.rstrip(';').strip()
        
        if not line or line.startswith('//'):
            return None
        
        if line.startswith('return'):
            rest = line[6:].strip()
            return ReturnStmt(rest if rest else None)
        
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\((.*)\)', line)
        if match:
            var = match.group(1)
            class_name = match.group(2)
            props_str = match.group(3)
            properties = {}
            for prop in re.finditer(r'(\w+)\s*:\s*"([^"]*)"', props_str):
                properties[prop.group(1)] = prop.group(2)
            return ObjectCreation(var, class_name, properties)
        
        match = re.match(r'(%\w+)\.(\w+)\((.*)\)', line)
        if match:
            obj = match.group(1)
            method = match.group(2)
            args_str = match.group(3)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return MethodCall(obj, method, args)
        
        match = re.match(r'(\w+)\((.*)\)', line)
        if match:
            func = match.group(1)
            args_str = match.group(2)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return FunctionCall(func, args)
        
        match = re.match(r'(%\w+)\s*=\s*(.+)', line)
        if match:
            var = match.group(1)
            value = match.group(2).strip().strip('"')
            return Assignment(var, value)
        
        return None

# [Compiler - uses new CodeBuilder]
class Compiler:
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.code = CodeBuilder()
        self.ident_table = IdentTable()
        self.label_counter = 0
    
    def add_identifier(self, name: str) -> int:
        return self.global_strings.add(name)
    
    def add_value(self, value: str) -> int:
        return self.func_strings.add(value)
    
    def gen_label(self) -> str:
        self.label_counter += 1
        return f"L{self.label_counter}"
    
    def compile_function(self, name: str, params: List[str], statements: List[ASTNode]):
        fn_offset = self.add_identifier(name)
        
        func_start = self.code.get_code_index()
        self.code.emit(OP_FUNC_DECL)
        self.code.emit_string_ref(fn_offset, is_global=True)
        self.ident_table.add(fn_offset, func_start + 1)
        
        self.code.emit_u16be(0x0000)
        self.code.emit_u16be(0x0000)
        self.code.emit(0x01)
        
        end_ip_placeholder_code_idx = self.code.get_code_index()
        self.code.emit(0x00)
        
        self.code.emit(len(params))
        
        for param in params:
            param_name = param[1:] if param.startswith('%') else param
            param_offset = self.add_identifier(param_name)
            self.code.emit_string_ref(param_offset, is_global=True)
            self.ident_table.add(param_offset, self.code.get_code_index())
        
        for stmt in statements:
            self.compile_statement(stmt)
        
        end_ip = self.code.get_code_index() - 1
        
        # Replace placeholder with actual end_ip
        # Find byte position of end_ip placeholder
        byte_pos = self.code._code_index_to_byte_pos(end_ip_placeholder_code_idx)
        
        if end_ip > 255:
            # Would need 3 bytes but we only have 1!
            # Use modulo (limitation)
            print(f"  WARNING: end_ip {end_ip} > 255, using modulo")
            self.code.codes[byte_pos] = end_ip & 0xFF
        else:
            self.code.codes[byte_pos] = end_ip
    
    def compile_statement(self, stmt: ASTNode):
        if isinstance(stmt, IfStatement):
            self.compile_if(stmt)
        elif isinstance(stmt, WhileLoop):
            self.compile_while(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.compile_return(stmt)
    
    def compile_if(self, stmt: IfStatement):
        else_label = self.gen_label() if stmt.else_body else None
        end_label = self.gen_label()
        
        self.compile_condition(stmt.condition)
        
        self.code.emit(OP_JMPIFNOT)
        if stmt.else_body:
            self.code.emit_jump_placeholder(else_label)
        else:
            self.code.emit_jump_placeholder(end_label)
        
        for s in stmt.then_body:
            self.compile_statement(s)
        
        if stmt.else_body:
            self.code.emit(OP_JMP)
            self.code.emit_jump_placeholder(end_label)
            
            self.code.place_label(else_label)
            for s in stmt.else_body:
                self.compile_statement(s)
        
        self.code.place_label(end_label)
    
    def compile_while(self, stmt: WhileLoop):
        start_label = self.gen_label()
        end_label = self.gen_label()
        
        self.code.place_label(start_label)
        self.compile_condition(stmt.condition)
        
        self.code.emit(OP_JMPIFNOT)
        self.code.emit_jump_placeholder(end_label)
        
        for s in stmt.body:
            self.compile_statement(s)
        
        self.code.emit(OP_JMP)
        self.code.emit_jump_placeholder(start_label)
        
        self.code.place_label(end_label)
    
    def compile_condition(self, cond: Any):
        if isinstance(cond, NotExpr):
            self.compile_condition(cond.expr)
            self.code.emit(OP_NOT)
        
        elif isinstance(cond, BinaryOp):
            if cond.op == '&&':
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit(OP_JMPIFNOT_NP)
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit(OP_AND)
                self.code.place_label(skip_label)
            
            elif cond.op == '||':
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit(OP_JMPIF_NP)
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit(OP_OR)
                self.code.place_label(skip_label)
            
            elif cond.op in ['==', '!=', '<', '>', '<=', '>=']:
                self.compile_condition(cond.left)
                self.compile_condition(cond.right)
                if cond.op == '==':
                    self.code.emit(OP_CMPEQ)
                elif cond.op == '!=':
                    self.code.emit(OP_CMPNE)
                elif cond.op == '<':
                    self.code.emit(OP_CMPLT)
                elif cond.op == '>':
                    self.code.emit(OP_CMPGR)
                elif cond.op == '<=':
                    self.code.emit(OP_CMPLE)
                elif cond.op == '>=':
                    self.code.emit(OP_CMPGE)
        
        elif isinstance(cond, FunctionCall):
            self.code.emit(OP_PUSHFRAME)
            
            for arg in cond.args:
                if isinstance(arg, VarRef):
                    var_offset = self.add_identifier(arg.name)
                    self.code.emit(OP_SETCURVAR)
                    self.code.emit_string_ref(var_offset, is_global=True)
                    self.ident_table.add(var_offset, self.code.get_code_index())
                    self.code.emit(OP_LOADVAR_STR)
                elif isinstance(arg, Literal):
                    arg_offset = self.add_value(arg.value)
                    self.code.emit(OP_LOADIMMED_STR)
                    self.code.emit_string_ref(arg_offset, is_global=False)
                self.code.emit(OP_PUSH)
            
            func_offset = self.add_identifier(cond.func)
            self.code.emit(OP_CALLFUNC)
            self.code.emit_string_ref(func_offset, is_global=True)
            self.ident_table.add(func_offset, self.code.get_code_index())
            self.code.emit_u16be(0x0000)
            self.code.emit(CALL_FUNCTION)
            self.code.emit(OP_STR_TO_UINT)
        
        elif isinstance(cond, VarRef):
            var_offset = self.add_identifier(cond.name)
            self.code.emit(OP_SETCURVAR)
            self.code.emit_string_ref(var_offset, is_global=True)
            self.ident_table.add(var_offset, self.code.get_code_index())
            self.code.emit(OP_LOADVAR_STR)
            self.code.emit(OP_STR_TO_UINT)
        
        elif isinstance(cond, Literal):
            lit_offset = self.add_value(cond.value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(lit_offset, is_global=False)
            self.code.emit(OP_STR_TO_UINT)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        self.code.emit(OP_PUSHFRAME)
        
        for prop_name, prop_value in stmt.properties.items():
            prop_offset = self.add_value(prop_name)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_string_ref(prop_offset, is_global=False)
            self.code.emit(OP_PUSH)
            
            val_offset = self.add_value(prop_value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(val_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        class_offset = self.add_identifier(stmt.class_name)
        self.code.emit(OP_CREATE_OBJECT)
        self.code.emit_string_ref(class_offset, is_global=True)
        self.ident_table.add(class_offset, self.code.get_code_index())
        self.code.emit(0x00)
        self.code.emit(0x01)
        
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(0x00)
        
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index())
        
        self.code.emit(OP_SAVEVAR_STR)
        self.code.emit(OP_END_OBJECT)
        self.code.emit(0x00)
    
    def compile_method_call(self, stmt: MethodCall):
        obj_name = stmt.obj[1:] if stmt.obj.startswith('%') else stmt.obj
        obj_offset = self.add_identifier(obj_name)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_string_ref(obj_offset, is_global=True)
        self.ident_table.add(obj_offset, self.code.get_code_index())
        
        self.code.emit(OP_SETCUROBJECT)
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        method_offset = self.add_identifier(stmt.method)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(method_offset, is_global=True)
        self.ident_table.add(method_offset, self.code.get_code_index())
        self.code.emit_u16be(0x0000)
        self.code.emit(CALL_METHOD)
    
    def compile_function_call(self, stmt: FunctionCall):
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        func_offset = self.add_identifier(stmt.func)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(func_offset, is_global=True)
        self.ident_table.add(func_offset, self.code.get_code_index())
        self.code.emit_u16be(0x0000)
        self.code.emit(CALL_FUNCTION)
    
    def compile_assignment(self, stmt: Assignment):
        val_offset = self.add_value(str(stmt.value))
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_string_ref(val_offset, is_global=False)
        
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index())
        
        self.code.emit(OP_SAVEVAR_STR)
    
    def compile_return(self, stmt: ReturnStmt):
        if stmt.value:
            if isinstance(stmt.value, str) and stmt.value.startswith('%'):
                var_name = stmt.value[1:]
                var_offset = self.add_identifier(var_name)
                self.code.emit(OP_SETCURVAR)
                self.code.emit_string_ref(var_offset, is_global=True)
                self.ident_table.add(var_offset, self.code.get_code_index())
                self.code.emit(OP_LOADVAR_STR)
        self.code.emit(OP_RETURN)
    
    def write_cso(self, output_path: str):
        self.code.patch_jumps()
        
        with open(output_path, 'wb') as f:
            f.write(struct.pack('<I', 1))
            
            global_str_bytes = self.global_strings.to_bytes()
            f.write(struct.pack('<I', len(global_str_bytes)))
            f.write(global_str_bytes)
            
            f.write(struct.pack('<I', 0))
            
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            f.write(struct.pack('<I', 0))
            
            # CRITICAL FIX: Write LOGICAL code count, not byte count!
            f.write(struct.pack('<I', self.code.code_count))
            f.write(self.code.to_bytes())
            
            f.write(self.ident_table.to_bytes())

def main():
    if len(sys.argv) != 3:
        print("Usage: py cso_recompiler_v15_fixed.py input.cs output.cso")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        source = f.read()
    
    parser = Parser(source)
    functions = parser.parse()
    
    print(f"Parsed {len(functions)} functions")
    
    compiler = Compiler()
    for name, params, statements in functions:
        print(f"Compiling: {name}({', '.join(params)}) - {len(statements)} statements")
        compiler.compile_function(name, params, statements)
    
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V15 - FIXED)")
    print(f"  Logical codes: {compiler.code.code_count}")
    print(f"  Byte count: {len(compiler.code.codes)}")
    print(f"  Global strings: {len(compiler.global_strings.strings)}")
    print(f"  Function strings: {len(compiler.func_strings.strings)}")
    print(f"  IdentTable entries: {len(compiler.ident_table.entries)}")

if __name__ == '__main__':
    main()
