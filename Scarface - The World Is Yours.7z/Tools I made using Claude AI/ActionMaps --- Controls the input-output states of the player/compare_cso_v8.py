#!/usr/bin/env python3
"""
Compare two CSO files to see structural differences
"""

import sys
import struct

def read_uint32(f):
    return struct.unpack('<I', f.read(4))[0]

def read_uint16(f):
    return struct.unpack('<H', f.read(2))[0]

def read_string_table(f, size):
    data = f.read(size)
    strings = []
    current = b''
    for byte in data:
        if byte == 0:
            if current:
                strings.append(current.decode('ascii', errors='replace'))
                current = b''
        else:
            current += bytes([byte])
    return strings

def read_codes(f, count):
    codes = []
    codes_read = 0
    
    while codes_read < count:
        byte = f.read(1)[0]
        if byte == 0xFF:
            high = f.read(1)[0]
            low = f.read(1)[0]
            code = (high << 8) | low
            codes.append(code)
        else:
            codes.append(byte)
        codes_read += 1
    
    return codes

def analyze_structure(filepath):
    """Get CSO file structure"""
    with open(filepath, 'rb') as f:
        version = read_uint32(f)
        
        # Global strings
        g_str_size = read_uint32(f)
        g_strings = read_string_table(f, g_str_size)
        
        # Global floats
        g_float_count = read_uint32(f)
        f.read(g_float_count * 4)
        
        # Function strings
        f_str_size = read_uint32(f)
        f_strings = read_string_table(f, f_str_size)
        
        # Function floats
        f_float_count = read_uint32(f)
        f.read(f_float_count * 4)
        
        # Bytecode
        code_count = read_uint32(f)
        bytecode_start = f.tell()
        codes = read_codes(f, code_count)
        bytecode_end = f.tell()
        byte_count = bytecode_end - bytecode_start
        
        # IdentTable
        try:
            ident_count = read_uint32(f)
            ident_entries = []
            for _ in range(ident_count):
                offset = read_uint16(f)
                padding = read_uint16(f)
                count = read_uint32(f)
                indices = [read_uint32(f) for _ in range(count)]
                ident_entries.append((offset, indices))
            remaining = len(f.read())
        except:
            # File might not have IdentTable or have different structure
            remaining = -1
            ident_count = 0
            ident_entries = []
        
        return {
            'version': version,
            'global_strings': g_strings,
            'global_floats': g_float_count,
            'func_strings': f_strings,
            'func_floats': f_float_count,
            'code_count': code_count,
            'byte_count': byte_count,
            'codes': codes,
            'ident_count': ident_count,
            'ident_entries': ident_entries,
            'extra_bytes': remaining
        }

def compare_cso_files(file1, file2):
    print(f"=== Comparing CSO Files ===")
    print(f"File 1: {file1}")
    print(f"File 2: {file2}\n")
    
    data1 = analyze_structure(file1)
    data2 = analyze_structure(file2)
    
    # Compare basic stats
    print("--- Basic Structure ---")
    print(f"{'Metric':<25} {'File 1':>15} {'File 2':>15} {'Diff':>10}")
    print("-" * 70)
    
    metrics = [
        ('Version', 'version', '{:d}'),
        ('Global Strings', 'global_strings', '{}'),
        ('Global Floats', 'global_floats', '{:d}'),
        ('Function Strings', 'func_strings', '{}'),
        ('Function Floats', 'func_floats', '{:d}'),
        ('Code Count', 'code_count', '{:d}'),
        ('Byte Count', 'byte_count', '{:d}'),
        ('IdentTable Entries', 'ident_count', '{:d}'),
        ('Extra Bytes', 'extra_bytes', '{:d}'),
    ]
    
    for label, key, fmt in metrics:
        val1 = data1[key]
        val2 = data2[key]
        
        if isinstance(val1, list):
            val1_str = str(len(val1))
            val2_str = str(len(val2))
            diff = len(val2) - len(val1)
        else:
            val1_str = fmt.format(val1)
            val2_str = fmt.format(val2)
            diff = val2 - val1
        
        diff_str = f"+{diff}" if diff > 0 else str(diff)
        print(f"{label:<25} {val1_str:>15} {val2_str:>15} {diff_str:>10}")
    
    # String comparison
    print("\n--- Function Strings Comparison ---")
    all_strings = set(data1['func_strings']) | set(data2['func_strings'])
    
    only_in_1 = set(data1['func_strings']) - set(data2['func_strings'])
    only_in_2 = set(data2['func_strings']) - set(data1['func_strings'])
    in_both = set(data1['func_strings']) & set(data2['func_strings'])
    
    print(f"Strings in both: {len(in_both)}")
    print(f"Only in File 1: {len(only_in_1)}")
    if only_in_1:
        for s in sorted(only_in_1)[:10]:
            print(f"  - {s}")
        if len(only_in_1) > 10:
            print(f"  ... and {len(only_in_1) - 10} more")
    
    print(f"Only in File 2: {len(only_in_2)}")
    if only_in_2:
        for s in sorted(only_in_2)[:10]:
            print(f"  + {s}")
        if len(only_in_2) > 10:
            print(f"  ... and {len(only_in_2) - 10} more")
    
    # Function detection
    print("\n--- Function Declarations ---")
    
    def find_functions(codes):
        funcs = []
        i = 0
        while i < len(codes):
            if codes[i] == 0x00 and i + 9 < len(codes):
                fn_offset = (codes[i+1] << 8) | codes[i+2]
                end_ip = codes[i+8]
                argc = codes[i+9]
                funcs.append((i, fn_offset, end_ip, argc))
                i += 10 + argc * 2
            else:
                i += 1
        return funcs
    
    funcs1 = find_functions(data1['codes'])
    funcs2 = find_functions(data2['codes'])
    
    print(f"Functions in File 1: {len(funcs1)}")
    print(f"Functions in File 2: {len(funcs2)}")
    
    # Bytecode comparison
    print("\n--- Bytecode Comparison ---")
    print(f"First 50 codes comparison:")
    print(f"{'Index':<8} {'File 1':<12} {'File 2':<12} {'Match':<8}")
    print("-" * 45)
    
    max_len = min(50, len(data1['codes']), len(data2['codes']))
    differences = 0
    for i in range(max_len):
        c1 = data1['codes'][i] if i < len(data1['codes']) else None
        c2 = data2['codes'][i] if i < len(data2['codes']) else None
        
        match = '✓' if c1 == c2 else '✗'
        if c1 != c2:
            differences += 1
        
        c1_str = f"0x{c1:02X}" if c1 is not None and c1 < 256 else f"0x{c1:04X}" if c1 is not None else "N/A"
        c2_str = f"0x{c2:02X}" if c2 is not None and c2 < 256 else f"0x{c2:04X}" if c2 is not None else "N/A"
        
        if c1 != c2:
            print(f"[{i:4d}]   {c1_str:<12} {c2_str:<12} {match:<8}")
    
    print(f"\nDifferences in first 50 codes: {differences}")
    
    # Overall similarity
    min_len = min(len(data1['codes']), len(data2['codes']))
    matches = sum(1 for i in range(min_len) if data1['codes'][i] == data2['codes'][i])
    similarity = (matches / min_len * 100) if min_len > 0 else 0
    
    print(f"\n--- Overall Similarity ---")
    print(f"Bytecode similarity (first {min_len} codes): {similarity:.1f}%")
    
    if data1['extra_bytes'] == 0 and data2['extra_bytes'] == 0:
        print("✅ Both files end cleanly after IdentTable")
    else:
        print(f"⚠️ Extra bytes: File1={data1['extra_bytes']}, File2={data2['extra_bytes']}")


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python3 compare_cso.py file1.cso file2.cso")
        sys.exit(1)
    
    compare_cso_files(sys.argv[1], sys.argv[2])
