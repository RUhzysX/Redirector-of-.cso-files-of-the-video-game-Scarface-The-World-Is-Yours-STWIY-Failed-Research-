# CSO Format - Complete Understanding

## The Journey

After analyzing the BrokenFace decompiler source code, we now have COMPLETE understanding of the CSO format!

## Critical Discovery: Bytecode is Code-Stream, Not Byte-Stream!

The KEY insight that was missing: **Bytecode is stored as CODES, not raw bytes!**

### What This Means

When the file says "bytecode length = 10312", it means:
- **10,312 CODES** (not bytes!)
- Actual byte size: 11,716 bytes
- Each "code" is read by `getCode()` which can be 1 or 3 bytes

### Code Reading Algorithm

```python
def getCode():
    byte = read_byte()
    if byte == 0xFF:  # Extension marker
        # This is a 16-bit extended code
        return read_uint16()  # Read next 2 bytes
    else:
        # Regular 8-bit code
        return byte
```

So bytecode like: `00 FF 01 23 45` is read as:
- Code 0: `0x00`
- Code 1: `0x0123` (extended, 3 bytes total: FF 01 23)
- Code 2: `0x45`

That's 3 codes, 5 bytes!

## Complete File Structure

```
Offset | Size | Description
-------|------|-------------
0x0000 | 4    | Version (uint32 LE)
0x0004 | 4    | Global String Table size (bytes)
+4     | N    | Global strings (null-terminated)
+N     | 4    | Global Float Table count
+4     | M*4  | Global floats (float32 LE)
+?     | 4    | Function String Table size (bytes)
+4     | P    | Function strings (null-terminated)
+P     | 4    | Function Float Table count
+4     | Q*4  | Function floats (float32 LE)
+?     | 4    | Bytecode CODE count (NOT byte count!)
+4     | ?    | Bytecode (variable length, codes)
+?     | 4    | IdentTable entry count
+4     | ?    | IdentTable entries
```

## IdentTable Structure

The IdentTable is crucial - it tells the decoder where string references are in the bytecode!

Each entry:
```
- offset (2 bytes LE) - string offset in table
- padding (2 bytes) - always 0x0000
- count (4 bytes LE) - number of locations
- indices[] (4 bytes LE each) - code indices to patch
```

Example:
```
Offset: 0x0000 (string "stxlagdgapl")
Count: 5
Indices: [1, 15, 31, ...]
```

This means: "The string at offset 0x0000 is referenced at code indices 1, 15, 31..."

The decoder uses this to PATCH the bytecode after loading, converting code indices to actual string offsets.

## OP_FUNC_DECL Structure (Code-by-Code)

```
Code [0]:    0x00 (OP_FUNC_DECL opcode)
Code [1-2]:  Function name offset (16-bit BE)
Code [3-4]:  Namespace offset (16-bit BE, or 0x0000 for none)
Code [5-6]:  Package offset (16-bit BE, or 0x0000 for none)
Code [7]:    Has body (0x00 or 0x01)
Code [8]:    End IP (code index where function ends)
Code [9]:    Argc (parameter count)
Code [10+]:  Parameter offsets (16-bit BE each, argc*2 codes)
```

## Example from ActionMaps

First function decoded:
```
Code [0]:   0x00 -> OP_FUNC_DECL
Code [1-2]: 0x0000 -> "stxlagdgapl" (fn name at offset 0)
Code [3-4]: 0x0000 -> "" (no namespace)
Code [5-6]: 0x0000 -> "" (no package)
Code [7]:   0x01 -> has body
Code [8]:   0x87 (135) -> ends at code 135
Code [9]:   0x00 -> 0 parameters
```

Function body starts at Code [10].

## Key Opcodes

Based on decompiler's callOp table:

```
0x00: OP_FUNC_DECL - Function declaration
0x01: OP_CREATE_OBJECT - Create object
      - parent offset (16-bit)
      - mystery byte
      - end IP byte
      
0x04: OP_ADD_OBJECT - Add object to stack
      - place_at_root byte
      
0x05: OP_END_OBJECT - End object creation
      - place_at_root byte
      
0x0D: OP_RETURN - Return from function
      (no args)
      
0x24: OP_SETCURVAR - Set current variable
      - var offset (16-bit)
      
0x25: OP_SETCURVAR_CREATE - Set/create current variable
      - var offset (16-bit)
      
0x32: OP_SETCUROBJECT - Set current object
      (no args - uses stack)
      
0x33: OP_SETCUROBJECT_NEW - Set current object to new
      (no args)
      
0x34: OP_SETCURFIELD - Set current field
      - field offset (16-bit)
      
0x45: OP_LOADIMMED_UINT - Load immediate uint
      - value (16-bit)
      
0x47: OP_LOADIMMED_STR - Load immediate string
      - offset (16-bit)
      
0x48: OP_LOADIMMED_IDENT - Load immediate identifier
      - offset (16-bit)
      
0x4B: OP_CALLFUNC - Call function
      - func offset (16-bit)
      - namespace offset (16-bit)
      - call type byte (0=func, 1=method)
      
0x54: OP_PUSH - Push value to stack
      (no args)
      
0x55: OP_PUSHFRAME - Push new argument frame
      (no args)
```

## What Went Wrong in Previous Attempts

### V2 Issues:
- ❌ Treated StringTableEntry as 32-bit (it's 16-bit!)
- ❌ Used little-endian (it's big-endian for offsets!)
- ❌ Missing Float tables
- ❌ Missing IdentTable
- ❌ Thought bytecode size was in bytes (it's CODE count!)

### V3 Issues:
- ✅ Not a compiler - it's a modifier (works perfectly for that!)

### V4 Issues:
- ❌ Still had V2 problems but added metadata
- ❌ Metadata alone doesn't fix wrong bytecode

### V5 Issues:
- ✅ Correct file structure
- ✅ Correct string tables and float tables
- ❌ Bytecode generation still wrong (emitting wrong format)

## The Path to V6 (Final)

To create a working compiler, we need to:

1. **Emit codes correctly**:
   - Each opcode is ONE code
   - String offsets are TWO codes (high, low bytes, big-endian)
   - Track which codes are string references

2. **Build IdentTable**:
   - For each string in global table
   - Record all code indices where it's referenced
   - Emit IdentTable at end

3. **Calculate code count**:
   - Count CODES, not bytes
   - Store this count before bytecode

4. **Proper code emission**:
   - Normal codes: emit as-is
   - Extended codes (>255): emit as 0xFF + 16-bit value

## Testing Strategy

1. Compile minimal function:
   ```
   function test() { return; }
   ```

2. Expected bytecode:
   ```
   Code [0]:   0x00 (FUNC_DECL)
   Code [1-2]: 0x0000 (fn name at offset 0)
   Code [3-4]: 0x0000 (no namespace)
   Code [5-6]: 0x0000 (no package)
   Code [7]:   0x01 (has body)
   Code [8]:   0x0A (ends at code 10)
   Code [9]:   0x00 (no params)
   Code [10]:  0x0D (RETURN)
   ```
   
   Total: 11 codes
   
3. IdentTable should have:
   - Offset 0x0000 -> [1]  (fn name referenced at code 1)

4. Verify decompiler can read it

## File Included

- `cso_recompiler_v5.py` - Has correct structure but bytecode needs fix
- Decompiler source - Reference for all opcodes and structures

## Next Step

Create V6 with:
- Correct code emission (not byte emission)
- IdentTable generation
- Proper code counting

This will be the final, working version!

---
*Complete CSO Format Specification*
*December 2024*
*Reverse Engineered from BrokenFace Decompiler*
