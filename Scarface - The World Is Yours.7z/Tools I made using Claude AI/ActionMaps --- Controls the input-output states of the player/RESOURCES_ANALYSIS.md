# Scarface Resources - Analysis

## 📦 Resources Provided

You've provided three incredible resources that give us deep insight into Scarface's engine!

### 1. Scarface Classes (classes-main/)

**What it is:** C++ header files (.hh) for game engine classes

**Example - ActionMap.hh:**
```cpp
class ActionMap : public ScriptObject
{
public:
    ActionMap* m_pNext;                         // 0x20
    ActionMap* m_pPrev;                         // 0x24
    bool m_bBlockLocalEvents;                   // 0x28
    bool m_bBlockAllEvents;                     // 0x29
    bool m_bPushed;                             // 0x2A
    smVector m_Events;                          // 0x2C
};
```

**Value for compiler:**
- Shows exact class structures
- Memory layouts (offsets in comments)
- Inheritance relationships
- Member variable types

**Key insight:** The game uses a custom scripting system based on TorqueScript, with classes exposed to scripts.

### 2. Scarface Hashkey (hashkey-main/main.cc)

**What it is:** Hash algorithm for string obfuscation

**The Algorithm:**
```cpp
uint32_t MakeKey(const char* p_Str)
{
    uint32_t _Key = 0;
    while (*p_Str)
    {
        _Key *= 65599;
        _Key = (_Key ^ (static_cast<uint32_t>(*p_Str)));
        p_Str++;
    }
    return _Key;
}
```

**String Hash Format:**
- Format: `stx` + 8 hex chars (lowercase a-p)
- Example: `stxlagdgapl` = hash of function name
- Encoding: Each nibble (4 bits) encoded as 'a' + value

**Why "stx" names:**
- Original names hashed for obfuscation
- Prevents reverse engineering
- All function/class names in CSO files are hashed

**Value for compiler:**
- Explains mysterious "stx..." names
- We can generate these hashes for new functions
- Reverse engineering possible if we know original names

### 3. Scarface Natives (natives-main/)

**What it is:** Complete database of native functions with addresses

**Structure (natives.json):**
```json
{
    "classFunctions": {
        "ActionMap": {
            "BindCommand": {
                "address": "0x0042f5c0",
                "className": "ActionMap",
                "methodName": "BindCommand",
                "minArguments": 5,
                "maxArguments": 6,
                "return": 3
            }
        }
    },
    "globalFunctions": {
        "echo": { ... },
        "warn": { ... }
    }
}
```

**Contains:**
- Every native function (class methods + globals)
- Memory addresses
- Argument counts (min/max)
- Return types
- Method documentation

**Value for compiler:**
- Know which functions exist
- Validate function calls
- Understand argument requirements
- Generate proper bytecode for native calls

## 🎯 How These Help the Compiler

### Issue 1: IndexError in Your Test

Your IndexError likely comes from:
1. **Complex function calls** - Using natives not properly recognized
2. **Method calls** - `.method()` syntax needs special handling
3. **Object creation** - `new ClassName()` requires understanding classes

**With these resources, we can:**
- Validate class names against classes-main
- Check method existence in natives.json
- Generate proper opcodes for native calls

### Issue 2: Understanding CSO Format

The resources clarify:
- **Why hashed names:** Security through obfuscation
- **What classes exist:** Complete class hierarchy
- **What methods are valid:** Full native function database

### Issue 3: Extending the Compiler

With these resources, we can implement:

1. **Native Function Validation**
   - Check if function exists before compiling
   - Validate argument counts
   - Generate warnings for invalid calls

2. **Class Method Compilation**
   - Verify class exists
   - Check method is valid for that class
   - Emit correct bytecode for method calls

3. **Hash Generation**
   - Generate "stx..." names for new functions
   - Maintain consistency with game's format

4. **Better Error Messages**
   - "Unknown class: X"
   - "Method Y requires 3-5 arguments, got 2"
   - "Function Z is not a native"

## 🔧 Immediate Applications

### For Your IndexError

Can you share your Test.cs so I can:
1. Check if it uses classes from classes-main
2. Verify native function calls against natives.json
3. Generate proper bytecode for those specific operations

### For V6 Compiler

We should enhance it to:
1. **Load natives.json** on startup
2. **Validate all function calls** against database
3. **Generate proper opcodes** for class methods
4. **Handle object creation** correctly

## 📊 Example Usage

**Before (broken):**
```torquescript
%obj = new TestClass(Name : "test");
%obj.someMethod("arg");
```

Compiler doesn't know:
- Does TestClass exist?
- Does someMethod exist on TestClass?
- How many arguments does someMethod need?

**After (with resources):**
```python
# Load natives
with open('natives.json') as f:
    natives = json.load(f)

# Validate class
if 'TestClass' not in natives['classFunctions']:
    raise CompileError("Unknown class: TestClass")

# Validate method
if 'someMethod' not in natives['classFunctions']['TestClass']:
    raise CompileError("Unknown method: TestClass.someMethod")

# Check arguments
method = natives['classFunctions']['TestClass']['someMethod']
if argc < method['minArguments'] or argc > method['maxArguments']:
    raise CompileError(f"Wrong argument count for someMethod")

# Emit proper bytecode
emit_method_call(...)
```

## 🎯 Next Steps

1. **Debug your IndexError** - Share Test.cs for analysis
2. **Integrate natives.json** - Validate function calls
3. **Add class validation** - Check against classes-main
4. **Enhance error messages** - Use resource data

These resources are GOLD for modding! They essentially give us the complete game engine API! 🚀

## 📝 Resource File Locations

After extraction:
- `/home/claude/classes-main/` - All class headers
- `/home/claude/hashkey-main/main.cc` - Hash algorithm
- `/home/claude/natives-main/natives.json` - Function database

## 💡 Key Insights

1. **Scarface uses TorqueScript** - Modified version for this game
2. **Heavy obfuscation** - All names hashed to "stx..."
3. **Complete documentation exists** - Via these resources
4. **Reverse engineering possible** - We have the keys!

This is essentially the game's internal SDK! 🎉
