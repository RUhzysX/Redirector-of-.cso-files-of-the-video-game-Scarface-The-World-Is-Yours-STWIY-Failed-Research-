# CSO Recompiler V8 - CRITICAL BYTECODE PARSING FIX

## The Problem We Had

In previous versions (V7.1 and earlier), the decompiler was failing with:
```
IndexError: list assignment index out of range
```

This indicated our bytecode structure was **almost** correct, but something was off with how codes were being written/read.

## The Root Cause - Discovered from Broken Face README

From analyzing the **Bytecode - Parsing - README.md** file, the critical insight is:

### Bytecode is Code-Based, Not Byte-Based!

**Key Quote from README (line 57-60):**
> * `Bytecode Size` (4-bytes long, little-endian) - Size, in "codes", of the `Bytecode` to be parsed next.
> * `Bytecode` - Stream of "codes" that describe the instructions the script consists of. This structure is indexed both by byte and by "code". Each "code" can be either:
>   - 1-byte long
>   - 3-bytes long (effectively 2-bytes long, little-endian) - The byte `0xff` is reserved to indicate that a code is 2-bytes long. The next two bytes after an occurrence of this control code compose a single code

### What This Means

1. **The bytecode size in the file header is CODE COUNT, not byte count**
   - If header says "10,312 codes", that means 10,312 codes to read
   - The actual byte size might be different (e.g., 11,716 bytes)

2. **Code Reading Algorithm:**
   ```python
   def read_code():
       byte = read_byte()
       if byte == 0xFF:  # Extension marker
           # Read next 2 bytes as 16-bit value
           high = read_byte()
           low = read_byte()
           return (high << 8) | low  # Big-endian!
       else:
           return byte
   ```

3. **Example:**
   - Bytecode bytes: `00 FF 01 23 45`
   - Codes read: `[0x00, 0x0123, 0x45]`
   - That's **3 codes** from **5 bytes**

## The Fix in V8

### 1. Proper Code Emission (`CodeBuilder.to_bytes()`)

```python
def to_bytes(self) -> bytes:
    """
    Convert code list to raw bytes.
    - Codes 0-254: single byte
    - Codes 255-65535: 0xFF + 2 bytes (big-endian)
    """
    output = bytearray()
    for code in self.codes:
        if code > 0xFE:  # Codes 255+ need extension
            output.append(0xFF)  # Extension marker
            output.append((code >> 8) & 0xFF)  # High byte first (BIG-ENDIAN)
            output.append(code & 0xFF)  # Low byte
        else:
            output.append(code & 0xFF)
    return bytes(output)
```

### 2. Write CODE COUNT, Not Byte Count

```python
# In write_cso():
code_count = len(self.code.codes)  # Number of CODES
f.write(struct.pack('<I', code_count))  # Write code count
f.write(self.code.to_bytes())  # Then write the bytes
```

### 3. String Encoding - Two Phases

**Phase 1: Initial Bytecode (Big-Endian)**
When we emit string offsets into bytecode, we write them as big-endian:
```python
def emit_u16be(self, value: int, is_string_ref=False, string_offset=None):
    high = (value >> 8) & 0xFF
    low = value & 0xFF
    self.codes.append(high)  # High byte first
    self.codes.append(low)   # Low byte second
```

**Phase 2: IdentTable Patching (Little-Endian)**
The IdentTable tells the game engine which code indices contain string references.
The engine will PATCH these locations, converting them to little-endian format.

From README (line 99-101):
> * 2-bytes long (big-endian) - If the string offset was not patched to the location being accessed, it is encoded as big-endian.
> * 2-bytes long (little-endian) - If the string offset was patched, it is encoded as little-endian.

## Additional Critical Fixes

### IdentTable Structure (from README)

```
Each entry:
- offset (2 bytes LE) - string offset in table
- padding (2 bytes) - always 0x0000
- count (4 bytes LE) - number of locations
- indices[] (4 bytes LE each) - code indices to patch
```

Our V8 implementation:
```python
def to_bytes(self) -> bytes:
    output = bytearray()
    output.extend(struct.pack('<I', len(self.entries)))  # Entry count
    
    for offset in sorted(self.entries.keys()):
        indices = self.entries[offset]
        output.extend(struct.pack('<H', offset & 0xFFFF))  # String offset (LE)
        output.extend(b'\x00\x00')  # Padding
        output.extend(struct.pack('<I', len(indices)))  # Index count (LE)
        for idx in indices:
            output.extend(struct.pack('<I', idx))  # Code index (LE)
    
    return bytes(output)
```

## Testing V8

### Simple Test:
```bash
python3 cso_recompiler_v8_fixed.py test_simple.cs test_simple_v8.cso
```

Expected output:
- ✅ No errors during compilation
- ✅ Code count properly calculated
- ✅ String references tracked in IdentTable
- ✅ Bytecode properly compressed (0xFF for codes > 254)

### Verification:
Use the analyzer to check structure:
```bash
python3 cso_analyzer_v8.py test_simple_v8.cso
```

Look for:
- ✅ Correct code count
- ✅ Proper function declarations
- ✅ Valid IdentTable entries
- ✅ No extra bytes at end

## What's Different from V7.1?

### V7.1 Issues:
1. ❌ Wrote codes as bytes directly without considering 0xFF compression
2. ❌ Didn't properly distinguish between code count and byte count
3. ❌ May have had endianness issues in some places

### V8 Fixes:
1. ✅ Proper code-to-byte conversion with 0xFF handling
2. ✅ Writes CODE COUNT in header, not byte count
3. ✅ Clear separation: initial bytecode (big-endian) vs. patched (little-endian)
4. ✅ Proper IdentTable structure exactly as specified in README

## Next Steps

1. **Test with existing .cso files:**
   - Try compiling one of the test files from the previous session
   - Use a CSO decompiler to verify it can read our output

2. **Test in-game:**
   - Compile actionmaps_test.cs
   - Replace the game's actionmaps_Win32.cso
   - See if it loads and works!

3. **Extend compiler:**
   - Add if/else statements
   - Add while/for loops
   - Add complex expressions

## Why This Should Work

The V8 compiler now matches the **exact specifications** from the Broken Face decompiler README:

- ✅ Code-based bytecode (not byte-based)
- ✅ Proper 0xFF extension codes
- ✅ Correct big-endian initial encoding
- ✅ Proper IdentTable structure
- ✅ Code count in header

This is the missing piece that was causing the IndexError in previous versions!

## Credits

- **Broken Face Decompiler** - The README provided the critical insight about code vs. byte indexing
- **Previous work (V1-V7.1)** - Established the foundation and most of the opcodes
- **This fix** - Implements the proper code/byte handling

---

**Status: V8 is theoretically correct and ready for testing!**

Let's try it out! 🚀
