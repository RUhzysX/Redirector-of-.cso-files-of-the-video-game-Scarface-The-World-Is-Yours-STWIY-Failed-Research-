#!/usr/bin/env py
"""
CSO Recompiler V14 - Extended Control Flow

New features:
- If/else statements
- While loops  
- Comparison operators (==, !=, <, >, <=, >=)
- Logical operators (&&, ||)
- Proper extended code handling for jumps > 255

Usage: py cso_recompiler_v14_extended.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional, Any

# Extended opcode set
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMPIF = 0x09
OP_JMPIFNOT_NP = 0x0A  # No pop - for && short circuit
OP_JMPIF_NP = 0x0B     # No pop - for || short circuit
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_CMPEQ = 0x0E
OP_CMPLT = 0x0F
OP_CMPLE = 0x10
OP_CMPGR = 0x11
OP_CMPGE = 0x12
OP_CMPNE = 0x13
OP_NOT = 0x18
OP_AND = 0x1D
OP_OR = 0x1E
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_STR_TO_UINT = 0x3C
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF

CALL_FUNCTION = 0x00
CALL_METHOD = 0x01

class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        if s in self.offsets:
            return self.offsets[s]
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)

class CodeBuilder:
    def __init__(self):
        self.codes = []
        self.string_refs = {}
        self.jump_patches = {}  # label -> [(index, needs_extended)]
        self.labels = {}  # label -> code_index
    
    def emit(self, code: int):
        """Emit a single code value"""
        if code > 0xFE:
            # Emit as extended code
            self.codes.append(EXT_CTRL_CODE)
            self.codes.append((code >> 8) & 0xFF)
            self.codes.append(code & 0xFF)
        else:
            self.codes.append(code & 0xFF)
    
    def emit_string_ref(self, offset: int, is_global: bool):
        high = (offset >> 8) & 0xFF
        low = offset & 0xFF
        code_idx = len(self.codes)
        self.string_refs[code_idx] = (offset, is_global)
        self.codes.append(high)
        self.codes.append(low)
    
    def emit_u16be(self, value: int):
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes.append(high)
        self.codes.append(low)
    
    def emit_jump_placeholder(self, label: str):
        """Emit placeholder for jump target - will be patched later"""
        idx = len(self.codes)
        if label not in self.jump_patches:
            self.jump_patches[label] = []
        self.jump_patches[label].append(idx)
        # Emit placeholder - we'll patch this with correct value later
        self.codes.append(0x00)
    
    def place_label(self, label: str):
        """Place a label at current position"""
        self.labels[label] = len(self.codes)
    
    def patch_jumps(self):
        """Patch all jump placeholders with actual targets"""
        for label, indices in self.jump_patches.items():
            if label not in self.labels:
                print(f"WARNING: Label {label} not found!")
                continue
            
            target = self.labels[label]
            
            for idx in indices:
                if target > 255:
                    # Need extended code
                    # Replace single byte placeholder with 3 bytes: 0xFF + high + low
                    self.codes[idx] = EXT_CTRL_CODE
                    self.codes.insert(idx + 1, (target >> 8) & 0xFF)
                    self.codes.insert(idx + 2, target & 0xFF)
                    
                    # Adjust all subsequent jump placeholders and labels
                    # that are after this insertion
                    for lbl, idxs in self.jump_patches.items():
                        self.jump_patches[lbl] = [i + 2 if i > idx else i for i in idxs]
                    
                    for lbl, lbl_idx in self.labels.items():
                        if lbl_idx > idx:
                            self.labels[lbl] = lbl_idx + 2
                else:
                    # Simple single byte
                    self.codes[idx] = target
    
    def get_code_index(self) -> int:
        return len(self.codes)
    
    def to_bytes(self) -> bytes:
        """Convert codes to bytes - codes are already properly formed"""
        return bytes(self.codes)

class IdentTable:
    def __init__(self):
        self.entries = {}
    
    def add(self, string_offset: int, code_index: int):
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def adjust_indices(self, after: int, shift: int):
        """Adjust all indices after a certain point by shift amount"""
        for offset, indices in self.entries.items():
            self.entries[offset] = [idx + shift if idx > after else idx for idx in indices]
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        return bytes(output)

# AST Nodes
class ASTNode:
    pass

class ObjectCreation(ASTNode):
    def __init__(self, var: str, class_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.properties = properties

class MethodCall(ASTNode):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(ASTNode):
    def __init__(self, func: str, args: List[Any]):
        self.func = func
        self.args = args

class Assignment(ASTNode):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStmt(ASTNode):
    def __init__(self, value: Optional[str] = None):
        self.value = value

class IfStatement(ASTNode):
    def __init__(self, condition: Any, then_body: List[ASTNode], else_body: List[ASTNode] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body or []

class WhileLoop(ASTNode):
    def __init__(self, condition: Any, body: List[ASTNode]):
        self.condition = condition
        self.body = body

class NotExpr(ASTNode):
    def __init__(self, expr: Any):
        self.expr = expr

class BinaryOp(ASTNode):
    def __init__(self, op: str, left: Any, right: Any):
        self.op = op
        self.left = left
        self.right = right

class VarRef(ASTNode):
    def __init__(self, name: str):
        self.name = name

class Literal(ASTNode):
    def __init__(self, value: str):
        self.value = value

# Parser
class Parser:
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
        self.pos = 0
    
    def parse(self) -> List[Tuple[str, List[str], List[ASTNode]]]:
        functions = []
        while self.pos < len(self.lines):
            line = self.lines[self.pos].strip()
            if line.startswith('function '):
                func = self.parse_function()
                if func:
                    functions.append(func)
            else:
                self.pos += 1
        return functions
    
    def parse_function(self) -> Optional[Tuple[str, List[str], List[ASTNode]]]:
        line = self.lines[self.pos].strip()
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            self.pos += 1
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        # Skip to opening brace
        while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
            self.pos += 1
        self.pos += 1
        
        body = self.parse_block()
        return (name, params, body)
    
    def parse_block(self) -> List[ASTNode]:
        """Parse block until closing brace"""
        statements = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                self.pos += 1
                if brace_count == 0:
                    break
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            # Check for control structures
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    statements.append(stmt)
            elif line.startswith('while '):
                stmt = self.parse_while_loop()
                if stmt:
                    statements.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    statements.append(stmt)
                self.pos += 1
        
        return statements
    
    def parse_if_statement(self) -> Optional[IfStatement]:
        """Parse if statement with optional else"""
        line = self.lines[self.pos].strip()
        
        # Extract condition
        match = re.match(r'if\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        # Check if opening brace is on same line
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        # Move to first line of body
        self.pos += 1
        
        # Parse then body
        then_body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    then_body.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    then_body.append(stmt)
                self.pos += 1
        
        # Check for else
        else_body = []
        if self.pos < len(self.lines):
            next_line = self.lines[self.pos].strip()
            if next_line.startswith('else'):
                self.pos += 1
                # Skip to opening brace
                while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                    self.pos += 1
                self.pos += 1
                
                # Parse else body
                brace_count = 1
                while self.pos < len(self.lines) and brace_count > 0:
                    line = self.lines[self.pos].strip()
                    
                    if '}' in line:
                        brace_count -= 1
                        if brace_count == 0:
                            self.pos += 1
                            break
                        self.pos += 1
                        continue
                    
                    if '{' in line:
                        brace_count += 1
                        self.pos += 1
                        continue
                    
                    if not line or line.startswith('//'):
                        self.pos += 1
                        continue
                    
                    stmt = self.parse_statement(line)
                    if stmt:
                        else_body.append(stmt)
                    self.pos += 1
        
        return IfStatement(condition, then_body, else_body)
    
    def parse_while_loop(self) -> Optional[WhileLoop]:
        """Parse while loop"""
        line = self.lines[self.pos].strip()
        
        # Extract condition
        match = re.match(r'while\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        # Skip to opening brace
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        self.pos += 1
        
        # Parse body
        body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            stmt = self.parse_statement(line)
            if stmt:
                body.append(stmt)
            self.pos += 1
        
        return WhileLoop(condition, body)
    
    def parse_condition(self, cond_str: str) -> Any:
        """Parse condition expression with operators"""
        cond_str = cond_str.strip()
        
        # Handle NOT: !(expr)
        if cond_str.startswith('!(') and cond_str.endswith(')'):
            inner = cond_str[2:-1].strip()
            inner_expr = self.parse_condition(inner)
            return NotExpr(inner_expr)
        
        # Handle comparison operators
        for op in ['==', '!=', '<=', '>=', '<', '>']:
            if op in cond_str:
                parts = cond_str.split(op, 1)
                if len(parts) == 2:
                    left = self.parse_condition(parts[0].strip())
                    right = self.parse_condition(parts[1].strip())
                    return BinaryOp(op, left, right)
        
        # Handle && and ||
        if '&&' in cond_str:
            parts = cond_str.split('&&', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('&&', left, right)
        
        if '||' in cond_str:
            parts = cond_str.split('||', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('||', left, right)
        
        # Handle function call
        match = re.match(r'(\w+)\s*\((.*)\)', cond_str)
        if match:
            func_name = match.group(1)
            args_str = match.group(2)
            args = []
            for arg in args_str.split(','):
                arg = arg.strip()
                if arg.startswith('%'):
                    args.append(VarRef(arg[1:]))
                else:
                    args.append(Literal(arg.strip('"')))
            return FunctionCall(func_name, args)
        
        # Variable reference
        if cond_str.startswith('%'):
            return VarRef(cond_str[1:])
        
        # Literal
        return Literal(cond_str.strip('"'))
    
    def parse_statement(self, line: str) -> Optional[ASTNode]:
        """Parse single statement"""
        line = line.rstrip(';').strip()
        
        if not line or line.startswith('//'):
            return None
        
        # Return
        if line.startswith('return'):
            rest = line[6:].strip()
            return ReturnStmt(rest if rest else None)
        
        # Object creation
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\((.*)\)', line)
        if match:
            var = match.group(1)
            class_name = match.group(2)
            props_str = match.group(3)
            properties = {}
            for prop in re.finditer(r'(\w+)\s*:\s*"([^"]*)"', props_str):
                properties[prop.group(1)] = prop.group(2)
            return ObjectCreation(var, class_name, properties)
        
        # Method call
        match = re.match(r'(%\w+)\.(\w+)\((.*)\)', line)
        if match:
            obj = match.group(1)
            method = match.group(2)
            args_str = match.group(3)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return MethodCall(obj, method, args)
        
        # Function call
        match = re.match(r'(\w+)\((.*)\)', line)
        if match:
            func = match.group(1)
            args_str = match.group(2)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return FunctionCall(func, args)
        
        # Assignment
        match = re.match(r'(%\w+)\s*=\s*(.+)', line)
        if match:
            var = match.group(1)
            value = match.group(2).strip().strip('"')
            return Assignment(var, value)
        
        return None

# Compiler
class Compiler:
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.code = CodeBuilder()
        self.ident_table = IdentTable()
        self.label_counter = 0
    
    def add_identifier(self, name: str) -> int:
        return self.global_strings.add(name)
    
    def add_value(self, value: str) -> int:
        return self.func_strings.add(value)
    
    def gen_label(self) -> str:
        self.label_counter += 1
        return f"L{self.label_counter}"
    
    def compile_function(self, name: str, params: List[str], statements: List[ASTNode]):
        """Compile function"""
        fn_offset = self.add_identifier(name)
        
        func_start = self.code.get_code_index()
        self.code.emit(OP_FUNC_DECL)
        self.code.emit_string_ref(fn_offset, is_global=True)
        self.ident_table.add(fn_offset, func_start + 1)
        
        self.code.emit_u16be(0x0000)  # namespace
        self.code.emit_u16be(0x0000)  # package
        self.code.emit(0x01)  # has body
        
        end_ip_idx = self.code.get_code_index()
        self.code.emit(0x00)  # placeholder
        
        self.code.emit(len(params))
        
        for param in params:
            param_name = param[1:] if param.startswith('%') else param
            param_offset = self.add_identifier(param_name)
            self.code.emit_string_ref(param_offset, is_global=True)
            self.ident_table.add(param_offset, self.code.get_code_index() - 2)
        
        # Compile body
        for stmt in statements:
            self.compile_statement(stmt)
        
        # Patch end_ip
        end_ip = self.code.get_code_index() - 1
        if end_ip > 255:
            self.code.codes[end_ip_idx] = EXT_CTRL_CODE
            self.code.codes.insert(end_ip_idx + 1, (end_ip >> 8) & 0xFF)
            self.code.codes.insert(end_ip_idx + 2, end_ip & 0xFF)
            self.ident_table.adjust_indices(end_ip_idx, 2)
        else:
            self.code.codes[end_ip_idx] = end_ip
    
    def compile_statement(self, stmt: ASTNode):
        """Compile statement"""
        if isinstance(stmt, IfStatement):
            self.compile_if(stmt)
        elif isinstance(stmt, WhileLoop):
            self.compile_while(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.compile_return(stmt)
    
    def compile_if(self, stmt: IfStatement):
        """Compile if/else statement"""
        else_label = self.gen_label() if stmt.else_body else None
        end_label = self.gen_label()
        
        # Compile condition
        self.compile_condition(stmt.condition)
        
        # Jump if false
        self.code.emit(OP_JMPIFNOT)
        if stmt.else_body:
            self.code.emit_jump_placeholder(else_label)
        else:
            self.code.emit_jump_placeholder(end_label)
        
        # Then body
        for s in stmt.then_body:
            self.compile_statement(s)
        
        if stmt.else_body:
            # Jump over else
            self.code.emit(OP_JMP)
            self.code.emit_jump_placeholder(end_label)
            
            # Else body
            self.code.place_label(else_label)
            for s in stmt.else_body:
                self.compile_statement(s)
        
        self.code.place_label(end_label)
    
    def compile_while(self, stmt: WhileLoop):
        """Compile while loop"""
        start_label = self.gen_label()
        end_label = self.gen_label()
        
        self.code.place_label(start_label)
        
        # Condition
        self.compile_condition(stmt.condition)
        
        # Jump if false
        self.code.emit(OP_JMPIFNOT)
        self.code.emit_jump_placeholder(end_label)
        
        # Body
        for s in stmt.body:
            self.compile_statement(s)
        
        # Jump back to start
        self.code.emit(OP_JMP)
        self.code.emit_jump_placeholder(start_label)
        
        self.code.place_label(end_label)
    
    def compile_condition(self, cond: Any):
        """Compile condition - result to intStack"""
        if isinstance(cond, NotExpr):
            self.compile_condition(cond.expr)
            self.code.emit(OP_NOT)
        
        elif isinstance(cond, BinaryOp):
            if cond.op == '&&':
                # Short-circuit AND
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit(OP_JMPIFNOT_NP)  # Jump if false, don't pop
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit(OP_AND)
                self.code.place_label(skip_label)
            
            elif cond.op == '||':
                # Short-circuit OR
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit(OP_JMPIF_NP)  # Jump if true, don't pop
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit(OP_OR)
                self.code.place_label(skip_label)
            
            elif cond.op in ['==', '!=', '<', '>', '<=', '>=']:
                # Comparison
                self.compile_condition(cond.left)
                self.compile_condition(cond.right)
                if cond.op == '==':
                    self.code.emit(OP_CMPEQ)
                elif cond.op == '!=':
                    self.code.emit(OP_CMPNE)
                elif cond.op == '<':
                    self.code.emit(OP_CMPLT)
                elif cond.op == '>':
                    self.code.emit(OP_CMPGR)
                elif cond.op == '<=':
                    self.code.emit(OP_CMPLE)
                elif cond.op == '>=':
                    self.code.emit(OP_CMPGE)
        
        elif isinstance(cond, FunctionCall):
            # Function call
            self.code.emit(OP_PUSHFRAME)
            
            for arg in cond.args:
                if isinstance(arg, VarRef):
                    var_offset = self.add_identifier(arg.name)
                    self.code.emit(OP_SETCURVAR)
                    self.code.emit_string_ref(var_offset, is_global=True)
                    self.ident_table.add(var_offset, self.code.get_code_index() - 2)
                    self.code.emit(OP_LOADVAR_STR)
                elif isinstance(arg, Literal):
                    arg_offset = self.add_value(arg.value)
                    self.code.emit(OP_LOADIMMED_STR)
                    self.code.emit_string_ref(arg_offset, is_global=False)
                self.code.emit(OP_PUSH)
            
            func_offset = self.add_identifier(cond.func)
            self.code.emit(OP_CALLFUNC)
            self.code.emit_string_ref(func_offset, is_global=True)
            self.ident_table.add(func_offset, self.code.get_code_index() - 2)
            self.code.emit_u16be(0x0000)
            self.code.emit(CALL_FUNCTION)
            self.code.emit(OP_STR_TO_UINT)
        
        elif isinstance(cond, VarRef):
            var_offset = self.add_identifier(cond.name)
            self.code.emit(OP_SETCURVAR)
            self.code.emit_string_ref(var_offset, is_global=True)
            self.ident_table.add(var_offset, self.code.get_code_index() - 2)
            self.code.emit(OP_LOADVAR_STR)
            self.code.emit(OP_STR_TO_UINT)
        
        elif isinstance(cond, Literal):
            # String literal - load and convert
            lit_offset = self.add_value(cond.value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(lit_offset, is_global=False)
            self.code.emit(OP_STR_TO_UINT)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        """Compile object creation"""
        self.code.emit(OP_PUSHFRAME)
        
        for prop_name, prop_value in stmt.properties.items():
            prop_offset = self.add_value(prop_name)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_string_ref(prop_offset, is_global=False)
            self.code.emit(OP_PUSH)
            
            val_offset = self.add_value(prop_value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(val_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        class_offset = self.add_identifier(stmt.class_name)
        self.code.emit(OP_CREATE_OBJECT)
        self.code.emit_string_ref(class_offset, is_global=True)
        self.ident_table.add(class_offset, self.code.get_code_index() - 2)
        self.code.emit(0x00)
        self.code.emit(0x01)
        
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(0x00)
        
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index() - 2)
        
        self.code.emit(OP_SAVEVAR_STR)
        self.code.emit(OP_END_OBJECT)
        self.code.emit(0x00)
    
    def compile_method_call(self, stmt: MethodCall):
        """Compile method call"""
        obj_name = stmt.obj[1:] if stmt.obj.startswith('%') else stmt.obj
        obj_offset = self.add_identifier(obj_name)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_string_ref(obj_offset, is_global=True)
        self.ident_table.add(obj_offset, self.code.get_code_index() - 2)
        
        self.code.emit(OP_SETCUROBJECT)
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        method_offset = self.add_identifier(stmt.method)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(method_offset, is_global=True)
        self.ident_table.add(method_offset, self.code.get_code_index() - 2)
        self.code.emit_u16be(0x0000)
        self.code.emit(CALL_METHOD)
    
    def compile_function_call(self, stmt: FunctionCall):
        """Compile function call"""
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_ref(arg_offset, is_global=False)
            self.code.emit(OP_PUSH)
        
        func_offset = self.add_identifier(stmt.func)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_ref(func_offset, is_global=True)
        self.ident_table.add(func_offset, self.code.get_code_index() - 2)
        self.code.emit_u16be(0x0000)
        self.code.emit(CALL_FUNCTION)
    
    def compile_assignment(self, stmt: Assignment):
        """Compile assignment"""
        val_offset = self.add_value(str(stmt.value))
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_string_ref(val_offset, is_global=False)
        
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_ref(var_offset, is_global=True)
        self.ident_table.add(var_offset, self.code.get_code_index() - 2)
        
        self.code.emit(OP_SAVEVAR_STR)
    
    def compile_return(self, stmt: ReturnStmt):
        """Compile return"""
        if stmt.value:
            if isinstance(stmt.value, str) and stmt.value.startswith('%'):
                var_name = stmt.value[1:]
                var_offset = self.add_identifier(var_name)
                self.code.emit(OP_SETCURVAR)
                self.code.emit_string_ref(var_offset, is_global=True)
                self.ident_table.add(var_offset, self.code.get_code_index() - 2)
                self.code.emit(OP_LOADVAR_STR)
        self.code.emit(OP_RETURN)
    
    def write_cso(self, output_path: str):
        """Write CSO file"""
        # Patch all jumps before writing
        self.code.patch_jumps()
        
        with open(output_path, 'wb') as f:
            f.write(struct.pack('<I', 1))
            
            global_str_bytes = self.global_strings.to_bytes()
            f.write(struct.pack('<I', len(global_str_bytes)))
            f.write(global_str_bytes)
            
            f.write(struct.pack('<I', 0))
            
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            f.write(struct.pack('<I', 0))
            
            code_count = len(self.code.codes)
            f.write(struct.pack('<I', code_count))
            f.write(self.code.to_bytes())
            
            f.write(self.ident_table.to_bytes())

def main():
    if len(sys.argv) != 3:
        print("Usage: py cso_recompiler_v14_extended.py input.cs output.cso")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        source = f.read()
    
    parser = Parser(source)
    functions = parser.parse()
    
    print(f"Parsed {len(functions)} functions")
    
    compiler = Compiler()
    for name, params, statements in functions:
        print(f"Compiling: {name}({', '.join(params)}) - {len(statements)} statements")
        compiler.compile_function(name, params, statements)
    
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V14 - FULL CONTROL FLOW)")
    print(f"  Codes: {len(compiler.code.codes)}")
    print(f"  Global strings: {len(compiler.global_strings.strings)}")
    print(f"  Function strings: {len(compiler.func_strings.strings)}")

if __name__ == '__main__':
    main()
