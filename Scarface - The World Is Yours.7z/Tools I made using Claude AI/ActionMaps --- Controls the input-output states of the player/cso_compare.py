#!/usr/bin/env python3
"""
CSO Comparison Tool
Compares original and recompiled CSO files to identify differences

Usage: python3 cso_compare.py original.cso recompiled.cso
"""

import sys
import struct


def read_strings(data, offset, size):
    """Read null-terminated strings from a region"""
    strings = []
    end = offset + size
    current = offset
    
    while current < end:
        null_pos = data.find(b'\x00', current)
        if null_pos == -1 or null_pos >= end:
            break
        string = data[current:null_pos].decode('ascii', errors='replace')
        if string:
            strings.append(string)
        current = null_pos + 1
    
    return strings


def analyze_cso(path):
    """Analyze a CSO file and return its structure"""
    with open(path, 'rb') as f:
        data = f.read()
    
    info = {
        'path': path,
        'size': len(data),
        'data': data
    }
    
    offset = 0
    
    # Version
    info['version'] = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    
    # Global strings
    global_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    info['global_str_size'] = global_str_size
    info['global_strings'] = read_strings(data, offset, global_str_size)
    offset += global_str_size
    
    # Function strings
    info['marker'] = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    info['func_str_size'] = func_str_size
    info['func_strings'] = read_strings(data, offset, func_str_size)
    offset += func_str_size
    
    # Code
    info['code_size_field'] = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    info['code_start'] = offset
    info['code_bytes'] = len(data) - offset
    
    return info


def compare_string_lists(name, list1, list2):
    """Compare two lists of strings"""
    set1 = set(list1)
    set2 = set(list2)
    
    only_in_1 = set1 - set2
    only_in_2 = set2 - set1
    common = set1 & set2
    
    print(f"\n{name}:")
    print(f"  Original: {len(list1)} strings")
    print(f"  Recompiled: {len(list2)} strings")
    print(f"  Common: {len(common)}")
    
    if only_in_1:
        print(f"  Only in original: {len(only_in_1)}")
        for s in sorted(only_in_1)[:10]:  # Show first 10
            print(f"    - '{s}'")
        if len(only_in_1) > 10:
            print(f"    ... and {len(only_in_1) - 10} more")
    
    if only_in_2:
        print(f"  Only in recompiled: {len(only_in_2)}")
        for s in sorted(only_in_2)[:10]:  # Show first 10
            print(f"    + '{s}'")
        if len(only_in_2) > 10:
            print(f"    ... and {len(only_in_2) - 10} more")


def compare_bytecode(info1, info2, num_instructions=50):
    """Compare bytecode between two CSO files"""
    print(f"\n### Bytecode Comparison (first {num_instructions} instructions) ###")
    
    data1 = info1['data']
    data2 = info2['data']
    offset1 = info1['code_start']
    offset2 = info2['code_start']
    
    for i in range(num_instructions):
        if offset1 + 4 > len(data1) or offset2 + 4 > len(data2):
            break
        
        val1 = struct.unpack_from('<I', data1, offset1)[0]
        val2 = struct.unpack_from('<I', data2, offset2)[0]
        
        match = "✓" if val1 == val2 else "✗"
        
        if val1 != val2:
            print(f"  [{i:3d}] {match}  0x{val1:08X} vs 0x{val2:08X}  ({val1} vs {val2})")
        
        offset1 += 4
        offset2 += 4


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_compare.py original.cso recompiled.cso")
        sys.exit(1)
    
    original_path = sys.argv[1]
    recompiled_path = sys.argv[2]
    
    print("=" * 80)
    print("CSO COMPARISON TOOL")
    print("=" * 80)
    
    print("\nAnalyzing original...")
    original = analyze_cso(original_path)
    
    print("Analyzing recompiled...")
    recompiled = analyze_cso(recompiled_path)
    
    # Summary
    print("\n### SUMMARY ###")
    print(f"Original size: {original['size']} bytes")
    print(f"Recompiled size: {recompiled['size']} bytes")
    print(f"Difference: {recompiled['size'] - original['size']:+d} bytes ({((recompiled['size'] / original['size'] - 1) * 100):+.1f}%)")
    
    # String tables
    compare_string_lists("Global Strings", original['global_strings'], recompiled['global_strings'])
    compare_string_lists("Function Strings", original['func_strings'], recompiled['func_strings'])
    
    # Bytecode
    print(f"\n### Bytecode ###")
    print(f"Original: {original['code_bytes']} bytes")
    print(f"Recompiled: {recompiled['code_bytes']} bytes")
    print(f"Difference: {recompiled['code_bytes'] - original['code_bytes']:+d} bytes")
    
    compare_bytecode(original, recompiled)
    
    print("\n" + "=" * 80)
    print("\nRecommendations:")
    print("1. Focus on matching the Global Strings exactly")
    print("2. Ensure Function Strings are in the correct order")
    print("3. Analyze bytecode differences to find optimization opportunities")
    print("4. Test the recompiled file in-game to see if differences matter")


if __name__ == "__main__":
    main()
