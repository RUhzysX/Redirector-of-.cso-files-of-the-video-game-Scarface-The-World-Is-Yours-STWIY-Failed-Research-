#!/usr/bin/env python3
"""
CSO Recompiler V9 - Direct String Embedding (Match Original Format)

This version writes strings directly as little-endian in bytecode,
matching the format used in the original Scarface CSO files.

Key differences from V8:
- NO IdentTable generation
- Strings written directly as little-endian (not big-endian)
- All strings in function string table (not global)

Usage: python3 cso_recompiler_v9_direct.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_RETURN = 0x0D
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x34
OP_SAVEFIELD_STR = 0x3B
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        """Add string and return its offset"""
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class CodeBuilder:
    """
    Builds bytecode with DIRECT string embedding (V9 approach).
    Strings are written directly as little-endian, NO IdentTable.
    """
    def __init__(self):
        self.codes = []
    
    def emit(self, code: int):
        """Emit a single code"""
        self.codes.append(code)
    
    def emit_string_direct(self, offset: int):
        """
        Emit string offset directly as little-endian (V9 approach).
        This matches the original Scarface CSO format.
        """
        low = offset & 0xFF
        high = (offset >> 8) & 0xFF
        self.codes.append(low)   # Low byte first (little-endian)
        self.codes.append(high)  # High byte second
    
    def emit_u16be(self, value: int):
        """
        Emit a 16-bit value as big-endian (for non-string values).
        """
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes.append(high)
        self.codes.append(low)
    
    def get_code_index(self) -> int:
        """Get current code index"""
        return len(self.codes)
    
    def to_bytes(self) -> bytes:
        """
        Convert code list to raw bytes.
        Since we use direct embedding, most codes are < 255,
        so minimal compression needed.
        """
        output = bytearray()
        for code in self.codes:
            if code > 0xFE:
                output.append(EXT_CTRL_CODE)
                output.append((code >> 8) & 0xFF)
                output.append(code & 0xFF)
            else:
                output.append(code & 0xFF)
        return bytes(output)


class SimpleParser:
    """Simplified parser"""
    
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
    
    def parse(self) -> List[Tuple[str, List[str], List[str]]]:
        """Returns list of (name, params, raw_statement_lines)"""
        functions = []
        
        i = 0
        while i < len(self.lines):
            line = self.lines[i].strip()
            
            if not line or line.startswith('//'):
                i += 1
                continue
            
            if line.startswith('function '):
                func_data = self.parse_function(i)
                if func_data:
                    functions.append(func_data)
                    name, params, stmts, end_line = func_data
                    i = end_line + 1
                else:
                    i += 1
            else:
                i += 1
        
        return [(n, p, s) for n, p, s, _ in functions]
    
    def parse_function(self, start_line: int) -> Optional[Tuple[str, List[str], List[str], int]]:
        """Parse function starting at line"""
        line = self.lines[start_line].strip()
        
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        i = start_line
        while i < len(self.lines) and '{' not in self.lines[i]:
            i += 1
        
        if i >= len(self.lines):
            return None
        
        statements = []
        i += 1
        brace_count = 1
        
        while i < len(self.lines) and brace_count > 0:
            line = self.lines[i].strip()
            brace_count += line.count('{') - line.count('}')
            
            if brace_count > 0 or (brace_count == 0 and line and line != '}'):
                if line and line != '{' and line != '}':
                    statements.append(line)
            
            i += 1
            if brace_count == 0:
                break
        
        return (name, params, statements, i - 1)


class Statement:
    pass

class ObjectCreation(Statement):
    def __init__(self, var: str, class_name: str, obj_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.obj_name = obj_name
        self.properties = properties

class MethodCall(Statement):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(Statement):
    def __init__(self, func: str, args: List[str]):
        self.func = func
        self.args = args

class Assignment(Statement):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStmt(Statement):
    def __init__(self, value: Optional[str] = None):
        self.value = value


def parse_statement(line: str) -> Optional[Statement]:
    """Parse a single statement line"""
    line = line.strip()
    if not line or line.startswith('//'):
        return None
    
    if line.endswith(';'):
        line = line[:-1].strip()
    
    # Return statement
    if line.startswith('return'):
        rest = line[6:].strip()
        return ReturnStmt(rest if rest else None)
    
    # Object creation
    match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(\s*(\w+)\s*:\s*\"([^"]+)\"(.*)\)', line)
    if match:
        var = match.group(1)
        class_name = match.group(2)
        prop_name = match.group(3)
        prop_value = match.group(4)
        rest = match.group(5)
        
        properties = {prop_name: prop_value}
        
        for prop_match in re.finditer(r',\s*(\w+)\s*:\s*\"([^"]+)\"', rest):
            properties[prop_match.group(1)] = prop_match.group(2)
        
        obj_name = properties.get('Name', properties.get('name', ''))
        return ObjectCreation(var, class_name, obj_name, properties)
    
    # Method call
    match = re.match(r'(%\w+)\.(\w+)\((.*)\)', line)
    if match:
        obj = match.group(1)
        method = match.group(2)
        args_str = match.group(3)
        args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
        return MethodCall(obj, method, args)
    
    # Function call
    match = re.match(r'(\w+)\((.*)\)', line)
    if match:
        func = match.group(1)
        args_str = match.group(2)
        args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
        return FunctionCall(func, args)
    
    # Assignment
    match = re.match(r'(%\w+)\s*=\s*(.+)', line)
    if match:
        var = match.group(1)
        value = match.group(2).strip().strip('"')
        return Assignment(var, value)
    
    return None


class Compiler:
    def __init__(self):
        self.global_strings = StringTable()  # Will be empty in V9
        self.func_strings = StringTable()    # All strings go here
        self.code = CodeBuilder()
    
    def compile_function(self, name: str, params: List[str], statements: List[str]):
        """Compile a single function"""
        fn_offset = self.func_strings.add(name)
        
        # OP_FUNC_DECL
        self.code.emit(OP_FUNC_DECL)
        
        # Function name (DIRECT, little-endian)
        self.code.emit_string_direct(fn_offset)
        
        # Namespace (0x0000)
        self.code.emit_u16be(0x0000)
        
        # Package (0x0000)
        self.code.emit_u16be(0x0000)
        
        # Has body
        self.code.emit(0x01)
        
        # End IP (placeholder)
        end_ip_idx = self.code.get_code_index()
        self.code.emit(0x00)
        
        # Parameter count
        self.code.emit(len(params))
        
        # Parameters (DIRECT, little-endian)
        for param in params:
            param_offset = self.func_strings.add(param)
            self.code.emit_string_direct(param_offset)
        
        # Compile statements
        for line in statements:
            stmt = parse_statement(line)
            if stmt:
                self.compile_statement(stmt)
        
        # Fix end IP
        end_ip = self.code.get_code_index()
        self.code.codes[end_ip_idx] = end_ip & 0xFF
    
    def compile_statement(self, stmt: Statement):
        """Compile a statement"""
        if isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.compile_return(stmt)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        """Compile object creation"""
        self.code.emit(OP_PUSHFRAME)
        
        for prop_name, prop_value in stmt.properties.items():
            # Property name
            prop_offset = self.func_strings.add(prop_name)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_string_direct(prop_offset)
            self.code.emit(OP_PUSH)
            
            # Property value
            val_offset = self.func_strings.add(prop_value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_direct(val_offset)
            self.code.emit(OP_PUSH)
        
        # CREATE_OBJECT
        class_offset = self.func_strings.add(stmt.class_name)
        self.code.emit(OP_CREATE_OBJECT)
        self.code.emit_string_direct(class_offset)
        self.code.emit(0x00)
        self.code.emit(0x01)
        
        # ADD_OBJECT
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(0x00)
        
        # SETCURVAR_CREATE
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.func_strings.add(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_direct(var_offset)
        
        # SAVEVAR_STR
        self.code.emit(OP_SAVEVAR_STR)
        
        # END_OBJECT
        self.code.emit(OP_END_OBJECT)
        self.code.emit(0x00)
    
    def compile_method_call(self, stmt: MethodCall):
        """Compile method call"""
        obj_name = stmt.obj[1:] if stmt.obj.startswith('%') else stmt.obj
        obj_offset = self.func_strings.add(obj_name)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_string_direct(obj_offset)
        
        self.code.emit(OP_SETCUROBJECT)
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.func_strings.add(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_direct(arg_offset)
            self.code.emit(OP_PUSH)
        
        method_offset = self.func_strings.add(stmt.method)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_direct(method_offset)
        self.code.emit_u16be(0x0000)
        self.code.emit(0x01)
    
    def compile_function_call(self, stmt: FunctionCall):
        """Compile function call"""
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            arg_offset = self.func_strings.add(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_string_direct(arg_offset)
            self.code.emit(OP_PUSH)
        
        func_offset = self.func_strings.add(stmt.func)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_string_direct(func_offset)
        self.code.emit_u16be(0x0000)
        self.code.emit(0x00)
    
    def compile_assignment(self, stmt: Assignment):
        """Compile assignment"""
        val_offset = self.func_strings.add(stmt.value)
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_string_direct(val_offset)
        
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.func_strings.add(var_name)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_string_direct(var_offset)
        
        self.code.emit(OP_SAVEVAR_STR)
    
    def compile_return(self, stmt: ReturnStmt):
        """Compile return"""
        if stmt.value:
            if stmt.value.startswith('%'):
                var_name = stmt.value[1:]
                var_offset = self.func_strings.add(var_name)
                self.code.emit(OP_SETCURVAR)
                self.code.emit_string_direct(var_offset)
                self.code.emit(OP_LOADVAR_STR)
        
        self.code.emit(OP_RETURN)
    
    def write_cso(self, output_path: str):
        """Write CSO file (V9 format - no IdentTable)"""
        with open(output_path, 'wb') as f:
            # Version
            f.write(struct.pack('<I', 1))
            
            # Global String Table (EMPTY in V9)
            f.write(struct.pack('<I', 0))
            
            # Global Float Table (empty)
            f.write(struct.pack('<I', 0))
            
            # Function String Table (ALL strings)
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            # Function Float Table (empty)
            f.write(struct.pack('<I', 0))
            
            # Bytecode - CODE COUNT
            code_count = len(self.code.codes)
            f.write(struct.pack('<I', code_count))
            f.write(self.code.to_bytes())
            
            # NO IdentTable in V9!
            # This matches the original Scarface format


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_recompiler_v9_direct.py input.cs output.cso")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        source = f.read()
    
    parser = SimpleParser(source)
    functions = parser.parse()
    
    print(f"Parsed {len(functions)} functions")
    
    compiler = Compiler()
    for name, params, statements in functions:
        print(f"Compiling function: {name}({', '.join(params)})")
        print(f"  Statements: {len(statements)}")
        compiler.compile_function(name, params, statements)
    
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V9 - Direct Embedding)")
    print(f"  Code count: {len(compiler.code.codes)}")
    print(f"  Global strings: 0 (all in function table)")
    print(f"  Function strings: {len(compiler.func_strings.strings)}")
    print(f"  Format: Direct string embedding (NO IdentTable)")


if __name__ == '__main__':
    main()
