#!/usr/bin/env python3
"""
CSO Diagnostic Tool - Analyze CSO structure to find issues
"""
import sys
import struct

def analyze_cso(filename):
    with open(filename, 'rb') as f:
        data = f.read()
    
    print(f"=== Analyzing {filename} ===")
    print(f"Total size: {len(data)} bytes\n")
    
    offset = 0
    
    # Version
    version = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Version: {version}")
    offset += 4
    
    # Global String Table
    gst_size = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Global String Table size: {gst_size} bytes")
    offset += 4
    gst_start = offset
    offset += gst_size
    
    # Parse strings
    strings = []
    pos = gst_start
    while pos < gst_start + gst_size:
        end = data.find(b'\x00', pos)
        if end == -1:
            break
        s = data[pos:end].decode('ascii', errors='replace')
        strings.append((pos - gst_start, s))
        pos = end + 1
    
    print(f"  Strings ({len(strings)}):")
    for off, s in strings[:10]:
        print(f"    [{off:4d}] '{s}'")
    if len(strings) > 10:
        print(f"    ... and {len(strings) - 10} more")
    
    # Global Float Table
    gft_count = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Global Float Table count: {gft_count}")
    offset += 4 + (gft_count * 4)
    
    # Function String Table
    fst_size = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Function String Table size: {fst_size} bytes")
    offset += 4 + fst_size
    
    # Function Float Table
    fft_count = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Function Float Table count: {fft_count}")
    offset += 4 + (fft_count * 4)
    
    # Bytecode
    code_count = struct.unpack_from('<I', data, offset)[0]
    print(f"[0x{offset:04X}] Bytecode CODE count: {code_count}")
    offset += 4
    
    bc_start = offset
    print(f"[0x{offset:04X}] Bytecode starts here")
    
    # Show first 20 bytes of bytecode
    print(f"\n  First 20 bytes of bytecode:")
    for i in range(min(20, len(data) - bc_start)):
        b = data[bc_start + i]
        print(f"    [{i:2d}] 0x{b:02X} ({b:3d})")
    
    # Try to parse bytecode codes
    print(f"\n  Parsing bytecode codes:")
    codes = []
    pos = bc_start
    for i in range(min(20, code_count)):
        if pos >= len(data):
            print(f"    ERROR: Reached end of file at code {i}")
            break
        
        b = data[pos]
        pos += 1
        
        if b == 0xFF:  # Extension code
            if pos + 1 >= len(data):
                print(f"    ERROR: Extension code at end of file")
                break
            high = data[pos]
            low = data[pos + 1]
            code = (high << 8) | low
            pos += 2
            codes.append(code)
        else:
            codes.append(b)
        
        if i < 15:
            print(f"    Code[{i:2d}] = 0x{codes[-1]:04X} ({codes[-1]:5d})")
    
    # Calculate expected bytecode size
    bc_bytes = pos - bc_start
    print(f"\n  Bytecode consumed: {bc_bytes} bytes for {len(codes)} codes")
    
    # IdentTable
    ident_offset = bc_start + (len(data) - bc_start) - 100  # Approximate
    # Try to find IdentTable
    print(f"\n  Looking for IdentTable...")
    
    # The IdentTable starts after all bytecode
    # Try reading from where we think it should be
    remaining = len(data) - pos
    print(f"  Remaining bytes after bytecode: {remaining}")
    
    if pos < len(data):
        try:
            ident_count = struct.unpack_from('<I', data, pos)[0]
            print(f"[0x{pos:04X}] IdentTable entry count: {ident_count}")
            
            if ident_count < 1000:  # Sanity check
                print(f"  (Looks reasonable)")
            else:
                print(f"  WARNING: Very large count, might be wrong offset")
        except:
            print(f"  ERROR: Can't read IdentTable")
    
    print(f"\n=== Analysis Complete ===")
    print(f"File appears to be: ", end='')
    if code_count > 0 and code_count < 100000:
        print("VALID (probably)")
    else:
        print("INVALID (code count suspicious)")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 diagnose_cso.py file.cso")
        sys.exit(1)
    
    analyze_cso(sys.argv[1])
