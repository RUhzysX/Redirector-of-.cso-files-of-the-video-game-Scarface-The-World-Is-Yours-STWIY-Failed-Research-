function stxlagdgapl()
{
	%stxkeipamak = new stxilbjjlhp(Name : "GlobalActionMap");
	%stxkeipamak.stxijmcdenl("Joystick", "DPadDown R3", "ToggleDebugMode();");
	%stxkeipamak.stxijmcdenl("Joystick", "DPadRight R3", "TOD_Advance();");
	%stxkeipamak.stxijmcdenl("Joystick", "DPadLeft R3", "ToggleTimeOfDay();");
	%stxbkkoegpo.stxbghnpjpk(%stxkeipamak);
	return %stxkeipamak;
	return %stxkeipamak;
}