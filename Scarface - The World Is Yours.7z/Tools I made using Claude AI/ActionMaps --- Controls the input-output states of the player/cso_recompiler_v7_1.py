#!/usr/bin/env python3
"""
CSO Recompiler V7.1 - Fixed Parser and Object Creation

Key fixes:
- Proper statement parsing  
- Correct object creation bytecode sequence
- Better expression handling

Usage: python3 cso_recompiler_v7_1.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional

# [Copy all the opcode definitions and helper classes from V7]
# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x34
OP_SAVEFIELD_STR = 0x3B
OP_LOADIMMED_UINT = 0x45
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        """Add string and return its offset"""
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class CodeBuilder:
    def __init__(self):
        self.codes = []
        self.string_refs = []
        self.labels = {}
        self.fixups = []
    
    def emit(self, code: int):
        self.codes.append(code)
    
    def emit_u16be(self, value: int, is_string_ref=False, string_offset=None):
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        
        if is_string_ref and string_offset is not None:
            code_idx = len(self.codes)
            self.string_refs.append((code_idx, string_offset))
        
        self.codes.append(high)
        self.codes.append(low)
    
    def get_code_index(self) -> int:
        return len(self.codes)
    
    def set_label(self, name: str):
        self.labels[name] = len(self.codes)
    
    def emit_jump(self, opcode: int, label: str):
        self.emit(opcode)
        fixup_idx = len(self.codes)
        self.emit(0)
        self.fixups.append((fixup_idx, label))
    
    def patch_jumps(self):
        for code_idx, label in self.fixups:
            if label not in self.labels:
                raise Exception(f"Undefined label: {label}")
            target = self.labels[label]
            self.codes[code_idx] = target & 0xFF
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        for code in self.codes:
            if code > 0xFF:
                output.append(EXT_CTRL_CODE)
                output.append((code >> 8) & 0xFF)
                output.append(code & 0xFF)
            else:
                output.append(code & 0xFF)
        return bytes(output)


class IdentTable:
    def __init__(self):
        self.entries = {}
    
    def add(self, string_offset: int, code_index: int):
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        
        return bytes(output)


class SimpleParser:
    """Simplified parser focusing on actionmaps patterns"""
    
    def __init__(self, source: str):
        # Normalize line endings
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
        self.pos = 0
    
    def parse(self) -> List[Tuple[str, List[str], List[str]]]:
        """Returns list of (name, params, raw_statement_lines)"""
        functions = []
        
        i = 0
        while i < len(self.lines):
            line = self.lines[i].strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('//'):
                i += 1
                continue
            
            # Function declaration
            if line.startswith('function '):
                func_data = self.parse_function(i)
                if func_data:
                    functions.append(func_data)
                    name, params, stmts, end_line = func_data
                    i = end_line + 1
                else:
                    i += 1
            else:
                i += 1
        
        return [(n, p, s) for n, p, s, _ in functions]
    
    def parse_function(self, start_line: int) -> Optional[Tuple[str, List[str], List[str], int]]:
        """Parse function starting at line"""
        line = self.lines[start_line].strip()
        
        # Extract function signature: function name(params)
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        # Find opening brace
        i = start_line
        while i < len(self.lines) and '{' not in self.lines[i]:
            i += 1
        
        if i >= len(self.lines):
            return None
        
        # Collect statement lines until closing brace
        statements = []
        i += 1
        brace_count = 1
        
        while i < len(self.lines) and brace_count > 0:
            line = self.lines[i].strip()
            
            # Count braces
            brace_count += line.count('{') - line.count('}')
            
            # Skip empty lines and comments
            if line and not line.startswith('//') and brace_count > 0:
                statements.append(line)
            
            i += 1
        
        return (name, params, statements, i - 1)


class StatementCompiler:
    """Compiles individual statements"""
    
    def __init__(self, global_strings: StringTable, func_strings: StringTable, 
                 bytecode: CodeBuilder, ident_table: IdentTable):
        self.global_strings = global_strings
        self.func_strings = func_strings
        self.bytecode = bytecode
        self.ident_table = ident_table
        self.label_counter = 0
    
    def compile_statement(self, stmt: str):
        """Compile a single statement"""
        stmt = stmt.rstrip(';').strip()
        
        if not stmt:
            return
        
        # Return statement
        if stmt.startswith('return'):
            self.compile_return(stmt)
        # Variable assignment with object creation
        elif '=' in stmt and 'new ' in stmt:
            self.compile_object_assignment(stmt)
        # Method call
        elif '.' in stmt and '(' in stmt:
            self.compile_method_call(stmt)
        # Function call
        elif '(' in stmt and not '=' in stmt:
            self.compile_function_call(stmt)
        # If statement
        elif stmt.startswith('if '):
            self.compile_if(stmt)
        # Simple assignment
        elif '=' in stmt:
            self.compile_assignment(stmt)
    
    def compile_return(self, stmt: str):
        """Compile return statement"""
        # Extract return value if present
        match = re.match(r'return\s*(.*)', stmt)
        if match and match.group(1):
            value = match.group(1).strip()
            if value:
                # Load the value
                if value.startswith('%'):
                    # Variable
                    var_name = value.lstrip('%')
                    var_offset = self.global_strings.add(var_name)
                    self.bytecode.emit(OP_SETCURVAR)
                    self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
                    self.bytecode.emit(OP_LOADVAR_STR)
        
        self.bytecode.emit(OP_RETURN)
    
    def compile_object_assignment(self, stmt: str):
        """Compile: %var = new Class(prop : val, ...);"""
        # Parse: %var = new Class(...)
        match = re.match(r'%(\w+)\s*=\s*new\s+(\w+)\s*\((.*?)\)', stmt)
        if not match:
            return
        
        var_name = match.group(1)
        class_name = match.group(2)
        props_str = match.group(3)
        
        # Parse properties: Name : "value", Prop : "val"
        properties = []
        if props_str.strip():
            # Simple regex for prop : "value" pattern
            for prop_match in re.finditer(r'(\w+)\s*:\s*"([^"]*)"', props_str):
                prop_name = prop_match.group(1)
                prop_value = prop_match.group(2)
                properties.append((prop_name, prop_value))
        
        # Generate bytecode
        # 1. Push frame
        self.bytecode.emit(OP_PUSHFRAME)
        
        # 2. Push properties (as identifier + string pairs)
        for prop_name, prop_value in properties:
            # Load property name as identifier
            name_offset = self.global_strings.add(prop_name)
            self.bytecode.emit(OP_LOADIMMED_IDENT)
            self.bytecode.emit_u16be(name_offset, is_string_ref=True, string_offset=name_offset)
            self.bytecode.emit(OP_PUSH)
            
            # Load property value as string
            val_offset = self.func_strings.add(prop_value)
            self.bytecode.emit(OP_LOADIMMED_STR)
            self.bytecode.emit_u16be(val_offset, is_string_ref=True, string_offset=val_offset)
            self.bytecode.emit(OP_PUSH)
        
        # 3. Create object
        class_offset = self.global_strings.add(class_name)
        self.bytecode.emit(OP_CREATE_OBJECT)
        self.bytecode.emit_u16be(class_offset, is_string_ref=True, string_offset=class_offset)
        self.bytecode.emit(0x00)  # Mystery byte
        
        # End IP - calculate position after END_OBJECT
        # From here: +1(end_ip) +1(ADD) +1(place) +1(SETCURVAR_CREATE) +2(offset) +1(SAVEVAR_STR) +1(END_OBJECT) = +8
        end_ip_pos = self.bytecode.get_code_index()
        end_ip_target = end_ip_pos + 8
        self.bytecode.emit(end_ip_target & 0xFF)
        
        # 4. Add object
        self.bytecode.emit(OP_ADD_OBJECT)
        self.bytecode.emit(0x01)  # place_at_root
        
        # 5. Set variable
        var_offset = self.global_strings.add(var_name)
        self.bytecode.emit(OP_SETCURVAR_CREATE)
        self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
        
        # 6. Save to variable
        self.bytecode.emit(OP_SAVEVAR_STR)
        
        # 7. End object
        self.bytecode.emit(OP_END_OBJECT)
        self.bytecode.emit(0x01)  # place_at_root
    
    def compile_method_call(self, stmt: str):
        """Compile: %obj.method(arg1, arg2, ...);"""
        # Parse: %obj.method(args)
        match = re.match(r'%(\w+)\.(\w+)\s*\((.*?)\)', stmt)
        if not match:
            return
        
        obj_name = match.group(1)
        method_name = match.group(2)
        args_str = match.group(3)
        
        # Parse arguments
        args = []
        if args_str.strip():
            # Split by comma (simple approach)
            for arg in args_str.split(','):
                arg = arg.strip()
                if arg:
                    args.append(arg)
        
        # Generate bytecode
        # 1. Set current variable to object
        obj_offset = self.global_strings.add(obj_name)
        self.bytecode.emit(OP_SETCURVAR)
        self.bytecode.emit_u16be(obj_offset, is_string_ref=True, string_offset=obj_offset)
        
        # 2. Set current object
        self.bytecode.emit(OP_SETCUROBJECT)
        
        # 3. Push frame
        self.bytecode.emit(OP_PUSHFRAME)
        
        # 4. Push arguments
        for arg in args:
            # Load argument (assume strings for now)
            if arg.startswith('"') and arg.endswith('"'):
                # String literal
                arg_val = arg.strip('"')
                arg_offset = self.func_strings.add(arg_val)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_u16be(arg_offset, is_string_ref=True, string_offset=arg_offset)
            elif arg.startswith('%'):
                # Variable reference
                var = arg.lstrip('%')
                var_offset = self.global_strings.add(var)
                self.bytecode.emit(OP_SETCURVAR)
                self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
                self.bytecode.emit(OP_LOADVAR_STR)
            else:
                # Treat as identifier/string
                arg_offset = self.func_strings.add(arg)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_u16be(arg_offset, is_string_ref=True, string_offset=arg_offset)
            
            self.bytecode.emit(OP_PUSH)
        
        # 5. Call method
        method_offset = self.global_strings.add(method_name)
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_u16be(method_offset, is_string_ref=True, string_offset=method_offset)
        self.bytecode.emit_u16be(0)  # No namespace
        self.bytecode.emit(0x01)  # Method call
    
    def compile_function_call(self, stmt: str):
        """Compile: function(arg1, arg2);"""
        match = re.match(r'(\w+)\s*\((.*?)\)', stmt)
        if not match:
            return
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        # Parse arguments
        args = []
        if args_str.strip():
            for arg in args_str.split(','):
                arg = arg.strip()
                if arg:
                    args.append(arg)
        
        # Generate bytecode
        # 1. Push frame
        self.bytecode.emit(OP_PUSHFRAME)
        
        # 2. Push arguments
        for arg in args:
            if arg.startswith('"') and arg.endswith('"'):
                arg_val = arg.strip('"')
                arg_offset = self.func_strings.add(arg_val)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_u16be(arg_offset, is_string_ref=True, string_offset=arg_offset)
            elif arg.startswith('%'):
                var = arg.lstrip('%')
                var_offset = self.global_strings.add(var)
                self.bytecode.emit(OP_SETCURVAR)
                self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
                self.bytecode.emit(OP_LOADVAR_STR)
            else:
                arg_offset = self.func_strings.add(arg)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_u16be(arg_offset, is_string_ref=True, string_offset=arg_offset)
            
            self.bytecode.emit(OP_PUSH)
        
        # 3. Call function
        func_offset = self.global_strings.add(func_name)
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_u16be(func_offset, is_string_ref=True, string_offset=func_offset)
        self.bytecode.emit_u16be(0)  # No namespace
        self.bytecode.emit(0x00)  # Function call
    
    def compile_if(self, stmt: str):
        """Compile if statement"""
        # For now, just skip - need proper block parsing
        pass
    
    def compile_assignment(self, stmt: str):
        """Compile simple assignment: %var = value;"""
        match = re.match(r'%(\w+)\s*=\s*(.+)', stmt)
        if not match:
            return
        
        var_name = match.group(1)
        value = match.group(2).strip()
        
        # Load value
        if value.startswith('"') and value.endswith('"'):
            val_str = value.strip('"')
            val_offset = self.func_strings.add(val_str)
            self.bytecode.emit(OP_LOADIMMED_STR)
            self.bytecode.emit_u16be(val_offset, is_string_ref=True, string_offset=val_offset)
        elif value.isdigit():
            self.bytecode.emit(OP_LOADIMMED_UINT)
            self.bytecode.emit_u16be(int(value))
        elif value.startswith('%'):
            src_var = value.lstrip('%')
            src_offset = self.global_strings.add(src_var)
            self.bytecode.emit(OP_SETCURVAR)
            self.bytecode.emit_u16be(src_offset, is_string_ref=True, string_offset=src_offset)
            self.bytecode.emit(OP_LOADVAR_STR)
        
        # Set variable
        var_offset = self.global_strings.add(var_name)
        self.bytecode.emit(OP_SETCURVAR_CREATE)
        self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
        
        # Save to variable
        self.bytecode.emit(OP_SAVEVAR_STR)


class CSOCompiler:
    """Main compiler"""
    
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.bytecode = CodeBuilder()
        self.ident_table = IdentTable()
    
    def compile(self, source: str) -> bytes:
        """Compile source to CSO binary"""
        # Parse
        parser = SimpleParser(source)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions:")
        for name, params, stmts in functions:
            param_str = ", ".join(params) if params else ""
            print(f"  - {name}({param_str}) - {len(stmts)} statements")
        
        # Compile each function
        for name, params, statements in functions:
            self.compile_function(name, params, statements)
        
        # Patch jumps
        self.bytecode.patch_jumps()
        
        # Build IdentTable
        for code_idx, string_offset in self.bytecode.string_refs:
            self.ident_table.add(string_offset, code_idx)
        
        return self.build_cso()
    
    def compile_function(self, name: str, params: List[str], statements: List[str]):
        """Compile a function"""
        # OP_FUNC_DECL
        self.bytecode.emit(OP_FUNC_DECL)
        
        # Function name
        name_offset = self.global_strings.add(name)
        self.bytecode.emit_u16be(name_offset, is_string_ref=True, string_offset=name_offset)
        
        # Namespace (empty)
        ns_offset = self.global_strings.add("")
        self.bytecode.emit_u16be(ns_offset, is_string_ref=True, string_offset=ns_offset)
        
        # Package (empty)
        pkg_offset = self.global_strings.add("")
        self.bytecode.emit_u16be(pkg_offset, is_string_ref=True, string_offset=pkg_offset)
        
        # Has body
        self.bytecode.emit(0x01)
        
        # End IP (will patch later)
        end_ip_idx = self.bytecode.get_code_index()
        self.bytecode.emit(0)
        
        # Argc
        argc = len(params)
        self.bytecode.emit(argc)
        
        # Parameter names
        for param in params:
            param = param.lstrip('%')
            param_offset = self.global_strings.add(param)
            self.bytecode.emit_u16be(param_offset, is_string_ref=True, string_offset=param_offset)
        
        # Compile statements
        stmt_compiler = StatementCompiler(
            self.global_strings, self.func_strings, 
            self.bytecode, self.ident_table
        )
        
        for stmt in statements:
            stmt_compiler.compile_statement(stmt)
        
        # Patch end IP
        end_ip = self.bytecode.get_code_index()
        self.bytecode.codes[end_ip_idx] = end_ip & 0xFF
    
    def build_cso(self) -> bytes:
        """Build final CSO binary"""
        output = bytearray()
        
        # Version
        output.extend(struct.pack('<I', 1))
        
        # Global String Table
        gst_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(gst_bytes)))
        output.extend(gst_bytes)
        
        # Global Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # Function String Table
        fst_bytes = self.func_strings.to_bytes()
        output.extend(struct.pack('<I', len(fst_bytes)))
        output.extend(fst_bytes)
        
        # Function Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # Bytecode
        bc_bytes = self.bytecode.to_bytes()
        code_count = len(self.bytecode.codes)
        output.extend(struct.pack('<I', code_count))
        output.extend(bc_bytes)
        
        # IdentTable
        ident_bytes = self.ident_table.to_bytes()
        output.extend(ident_bytes)
        
        return bytes(output)


def main():
    if len(sys.argv) != 3:
        print("CSO Recompiler V7.1 - Fixed Parser")
        print()
        print("Usage: python3 cso_recompiler_v7_1.py input.cs output.cso")
        print()
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    print(f"Compiling {input_file}...\n")
    
    try:
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
            source = f.read()
        
        compiler = CSOCompiler()
        cso_data = compiler.compile(source)
        
        with open(output_file, 'wb') as f:
            f.write(cso_data)
        
        print(f"\n✓ Compilation complete!")
        print(f"Output: {output_file}")
        print(f"Size: {len(cso_data)} bytes")
        print(f"Global strings: {len(compiler.global_strings.strings)}")
        print(f"Function strings: {len(compiler.func_strings.strings)}")
        print(f"Bytecode codes: {len(compiler.bytecode.codes)}")
        print(f"IdentTable entries: {len(compiler.ident_table.entries)}")
        
    except Exception as e:
        print(f"\n✗ Compilation failed!")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
