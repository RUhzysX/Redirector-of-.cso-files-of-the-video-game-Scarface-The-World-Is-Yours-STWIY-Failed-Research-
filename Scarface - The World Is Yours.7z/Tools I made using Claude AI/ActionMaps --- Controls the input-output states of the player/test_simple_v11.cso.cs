// Decompiled file: test_simple_v11.cso;
function testSimple()
{
}
return;
function testWithParam(name)
{
	new "Name"(Name : "TestMap")
	{
		%obj = "TestMap";
	}
}
return "keyboard".bind("escape", "quit");
