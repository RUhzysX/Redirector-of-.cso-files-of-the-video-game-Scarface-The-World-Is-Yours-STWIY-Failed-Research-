#!/usr/bin/env python3
"""
CSO Recompiler V18 - SCARFACE FORMAT

Based on Torque3D but with Scarface's modifications:
- code[] is U32 array (not bytes!)
- codeSize = number of U32 elements
- File compression: <255 as 1 byte, >=255 as 0xFF + 2-byte value (NOT 4-byte!)
- Scarface uses modified Torque3D compatible with BrokenFace

Usage: python3 cso_recompiler_v18_torque.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional, Any

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMPIF = 0x09
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_CMPEQ = 0x0E
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x36
OP_SETCURFIELD_ARRAY = 0x37
OP_LOADIMMED_UINT = 0x45
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

CALL_FUNCTION = 0x00
CALL_METHOD = 0x01

class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        if s in self.offsets:
            return self.offsets[s]
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)

class CodeBuilder:
    """
    Torque3D Format: code[] is array of U32 values
    - Each element is a U32 (can be 0 to 0xFFFFFFFF)
    - File format compresses: <255 as 1 byte, >=255 as 5 bytes
    """
    def __init__(self):
        self.code = []            # Array of U32 values
        self.jump_patches = {}    # label -> list of code indices
        self.labels = {}          # label -> code index
    
    def emit(self, value: int):
        """Emit a U32 value to the code array"""
        self.code.append(value & 0xFFFFFFFF)
    
    def emit_u16_bigendian(self, value: int):
        """Emit 16-bit big-endian as TWO U32s (high byte, low byte)"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.code.append(high)
        self.code.append(low)
    
    def emit_jump_placeholder(self, label: str):
        """Emit placeholder for jump target"""
        code_idx = len(self.code)
        if label not in self.jump_patches:
            self.jump_patches[label] = []
        self.jump_patches[label].append(code_idx)
        self.code.append(0)  # Placeholder U32
    
    def place_label(self, label: str):
        """Place label at current code position"""
        self.labels[label] = len(self.code)
    
    def patch_jumps(self):
        """Patch jump targets with actual code indices"""
        for label, code_positions in self.jump_patches.items():
            if label not in self.labels:
                print(f"WARNING: Label {label} not found!")
                continue
            
            target_code_idx = self.labels[label]
            for code_pos in code_positions:
                self.code[code_pos] = target_code_idx
    
    def get_code_index(self) -> int:
        """Return current code index"""
        return len(self.code)
    
    def to_bytes(self) -> bytes:
        """
        Convert U32 array to bytes using Scarface/BrokenFace format:
        - Values < 255: write as 1 byte
        - Values >= 255: write as 0xFF + 2-byte value (3 bytes total)
        NOTE: This is DIFFERENT from standard Torque3D (which uses 4 bytes)!
        Scarface uses a modified format compatible with BrokenFace.
        """
        output = bytearray()
        for value in self.code:
            if value < 0xFF:
                output.append(value & 0xFF)
            else:
                # Scarface/BrokenFace format: 0xFF + 2-byte value
                output.append(0xFF)
                output.extend(struct.pack('>H', value & 0xFFFF))
        return bytes(output)

class IdentTable:
    """Maps global string offsets to code indices where they're referenced"""
    def __init__(self):
        self.entries = {}  # string_offset -> [code_indices...]
    
    def add(self, string_offset: int, code_index: int):
        """Add a reference: string at offset is used at this code index"""
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')  # padding
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        return bytes(output)

# AST Nodes
class ASTNode:
    pass

class ObjectCreation(ASTNode):
    def __init__(self, var: str, class_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.properties = properties

class MethodCall(ASTNode):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(ASTNode):
    def __init__(self, func: str, args: List[Any]):
        self.func = func
        self.args = args

class Assignment(ASTNode):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStatement(ASTNode):
    def __init__(self, value: Optional[str] = None):
        self.value = value

class IfStatement(ASTNode):
    def __init__(self, condition: str, then_body: List[ASTNode], else_body: Optional[List[ASTNode]] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body

class WhileLoop(ASTNode):
    def __init__(self, condition: str, body: List[ASTNode]):
        self.condition = condition
        self.body = body

class FunctionDecl(ASTNode):
    def __init__(self, name: str, params: List[str], body: List[ASTNode]):
        self.name = name
        self.params = params
        self.body = body

# Parser
class Parser:
    def __init__(self, script: str):
        self.script = script
        self.functions = []
    
    def parse(self):
        # Match function declarations
        func_pattern = r'function\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}'
        
        for match in re.finditer(func_pattern, self.script, re.DOTALL):
            func_name = match.group(1)
            params_str = match.group(2).strip()
            body_str = match.group(3)
            
            # Parse parameters
            params = []
            if params_str:
                params = [p.strip() for p in params_str.split(',')]
            
            # Parse body
            body = self.parse_statements(body_str)
            
            self.functions.append(FunctionDecl(func_name, params, body))
        
        return self.functions
    
    def parse_statements(self, body_str: str) -> List[ASTNode]:
        statements = []
        body_str = body_str.strip()
        
        i = 0
        while i < len(body_str):
            # Skip whitespace
            while i < len(body_str) and body_str[i].isspace():
                i += 1
            if i >= len(body_str):
                break
            
            # Try to match if statement
            if body_str[i:i+2] == 'if':
                # Find the condition
                paren_start = body_str.find('(', i)
                if paren_start == -1:
                    i += 1
                    continue
                
                # Find matching closing paren
                paren_count = 1
                paren_end = paren_start + 1
                while paren_end < len(body_str) and paren_count > 0:
                    if body_str[paren_end] == '(':
                        paren_count += 1
                    elif body_str[paren_end] == ')':
                        paren_count -= 1
                    paren_end += 1
                
                condition = body_str[paren_start+1:paren_end-1].strip()
                
                # Find the then block
                brace_start = body_str.find('{', paren_end)
                if brace_start == -1:
                    i += 1
                    continue
                
                # Find matching closing brace
                brace_count = 1
                brace_end = brace_start + 1
                while brace_end < len(body_str) and brace_count > 0:
                    if body_str[brace_end] == '{':
                        brace_count += 1
                    elif body_str[brace_end] == '}':
                        brace_count -= 1
                    brace_end += 1
                
                then_body_str = body_str[brace_start+1:brace_end-1]
                then_body = self.parse_statements(then_body_str)
                
                # TODO: Handle else clause
                else_body = None
                
                statements.append(IfStatement(condition, then_body, else_body))
                i = brace_end
                continue
            
            # Try to match while loop
            if body_str[i:i+5] == 'while':
                # Similar logic to if statement
                paren_start = body_str.find('(', i)
                if paren_start == -1:
                    i += 1
                    continue
                
                paren_count = 1
                paren_end = paren_start + 1
                while paren_end < len(body_str) and paren_count > 0:
                    if body_str[paren_end] == '(':
                        paren_count += 1
                    elif body_str[paren_end] == ')':
                        paren_count -= 1
                    paren_end += 1
                
                condition = body_str[paren_start+1:paren_end-1].strip()
                
                brace_start = body_str.find('{', paren_end)
                if brace_start == -1:
                    i += 1
                    continue
                
                brace_count = 1
                brace_end = brace_start + 1
                while brace_end < len(body_str) and brace_count > 0:
                    if body_str[brace_end] == '{':
                        brace_count += 1
                    elif body_str[brace_end] == '}':
                        brace_count -= 1
                    brace_end += 1
                
                loop_body_str = body_str[brace_start+1:brace_end-1]
                loop_body = self.parse_statements(loop_body_str)
                
                statements.append(WhileLoop(condition, loop_body))
                i = brace_end
                continue
            
            # Find next statement (ends with semicolon)
            semi = body_str.find(';', i)
            if semi == -1:
                # No more statements
                break
            
            line = body_str[i:semi].strip()
            if not line:
                i = semi + 1
                continue
            
            # Object creation
            obj_match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\((.+?)\)', line)
            if obj_match:
                var = obj_match.group(1)
                class_name = obj_match.group(2)
                props_str = obj_match.group(3)
                properties = {}
                for prop in props_str.split(','):
                    if ':' in prop:
                        k, v = prop.split(':', 1)
                        properties[k.strip()] = v.strip().strip('"')
                statements.append(ObjectCreation(var, class_name, properties))
                i = semi + 1
                continue
            
            # Method call
            method_match = re.match(r'(%?\w+)\.(\w+)\s*\((.+?)\)', line)
            if method_match:
                obj = method_match.group(1)
                method = method_match.group(2)
                args_str = method_match.group(3)
                args = [a.strip().strip('"') for a in args_str.split(',')]
                statements.append(MethodCall(obj, method, args))
                i = semi + 1
                continue
            
            # Function call
            func_match = re.match(r'(\w+)\s*\((.+?)\)', line)
            if func_match:
                func = func_match.group(1)
                args_str = func_match.group(2)
                args = [a.strip() for a in args_str.split(',')]
                statements.append(FunctionCall(func, args))
                i = semi + 1
                continue
            
            # Assignment
            assign_match = re.match(r'(%\w+)\s*=\s*(.+)', line)
            if assign_match:
                var = assign_match.group(1)
                value = assign_match.group(2).strip()
                statements.append(Assignment(var, value))
                i = semi + 1
                continue
            
            # Return statement
            if line.startswith('return'):
                value = line[6:].strip()
                statements.append(ReturnStatement(value if value else None))
                i = semi + 1
                continue
            
            # Skip unrecognized
            i = semi + 1
        
        return statements
    

# Compiler
class Compiler:
    def __init__(self):
        self.code = CodeBuilder()
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.ident_table = IdentTable()
        self.label_counter = 0
    
    def add_identifier(self, name: str) -> int:
        """Add identifier to global string table and return offset"""
        return self.global_strings.add(name)
    
    def add_function_string(self, s: str) -> int:
        """Add string to function string table and return offset"""
        return self.func_strings.add(s)
    
    def gen_label(self) -> str:
        """Generate unique label"""
        self.label_counter += 1
        return f"L{self.label_counter}"
    
    def compile_function(self, name: str, params: List[str], statements: List[ASTNode]):
        """
        Compile function declaration
        OP_FUNC_DECL is 1 U32, followed by data U32s:
          - fnName offset (2 U32s: high, low)
          - namespace offset (2 U32s: high, low)
          - package offset (2 U32s: high, low)
          - hasBody (1 U32)
          - end_ip (1 U32)
          - argc (1 U32)
          - for each arg: param offset (2 U32s)
        """
        fn_offset = self.add_identifier(name)
        func_start = self.code.get_code_index()
        
        # Emit OP_FUNC_DECL
        self.code.emit(OP_FUNC_DECL)
        
        # String reference at next code index
        self.ident_table.add(fn_offset, self.code.get_code_index())
        
        # Emit function name offset (big-endian 16-bit as 2 U32s)
        self.code.emit_u16_bigendian(fn_offset)
        
        # Namespace offset (0)
        self.code.emit_u16_bigendian(0x0000)
        
        # Package offset (0)
        self.code.emit_u16_bigendian(0x0000)
        
        # hasBody (1 U32)
        self.code.emit(0x01)
        
        # end_ip placeholder (1 U32)
        end_ip_idx = self.code.get_code_index()
        self.code.emit(0x00)
        
        # argc (1 U32)
        self.code.emit(len(params))
        
        # Parameter names (each as 2 U32s for big-endian offset)
        for param in params:
            param_name = param[1:] if param.startswith('%') else param
            param_offset = self.add_identifier(param_name)
            self.ident_table.add(param_offset, self.code.get_code_index())
            self.code.emit_u16_bigendian(param_offset)
        
        # Compile function body
        for stmt in statements:
            self.compile_statement(stmt)
        
        # Patch end_ip (now can be ANY value!)
        end_ip = self.code.get_code_index()
        self.code.code[end_ip_idx] = end_ip
        
        print(f"Compiling: {name}({', '.join(params)}) - {len(statements)} statements")
        if end_ip > 255:
            print(f"  end_ip = {end_ip} (will be compressed as 0xFF + U32)")
    
    def compile_statement(self, stmt: ASTNode):
        if isinstance(stmt, IfStatement):
            self.compile_if(stmt)
        elif isinstance(stmt, WhileLoop):
            self.compile_while(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStatement):
            self.compile_return(stmt)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        """
        Compile: %var = new ClassName(param1: "value1", param2: "value2");
        
        Correct sequence:
        1. OP_LOADIMMED_UINT (parent object - usually 0)
        2. OP_PUSHFRAME (create arg frame)
        3. OP_TAG_TO_STR (convert parent tag to string)
        4. OP_PUSH (push parent to argFrame)
        5. For each property:
           - OP_LOADIMMED_IDENT (param name)
           - OP_PUSH
           - OP_LOADIMMED_STR (param value)
           - OP_PUSH
        6. OP_CREATE_OBJECT (class name, flags)
        7. OP_END_OBJECT
        8. OP_ADD_OBJECT
        9. OP_SETCURVAR_CREATE (assign to variable)
        10. OP_SETCUROBJECT (make it current)
        """
        
        # 1. OP_LOADIMMED_UINT - parent object (0 for root)
        self.code.emit(OP_LOADIMMED_UINT)  # 0x45
        self.code.emit(0x00)  # parent = 0 (high byte)
        self.code.emit(0x00)  # parent = 0 (low byte)
        
        # 2. OP_PUSHFRAME - create argument frame
        self.code.emit(OP_PUSHFRAME)  # 0x55
        
        # 3. OP_TAG_TO_STR - convert parent tag to string  
        self.code.emit(0x49)  # OP_TAG_TO_STR
        self.code.emit(0x00)  # tag offset high
        self.code.emit(0x00)  # tag offset low
        
        # 4. OP_PUSH - push parent to argFrame
        self.code.emit(OP_PUSH)  # 0x54
        
        # 5. Push all properties as arguments
        for key, value in stmt.properties.items():
            # Push property name (identifier)
            self.code.emit(OP_LOADIMMED_IDENT)  # 0x48
            key_offset = self.add_identifier(key)
            self.ident_table.add(key_offset, self.code.get_code_index())
            self.code.emit_u16_bigendian(key_offset)
            self.code.emit(OP_PUSH)  # 0x54
            
            # Push property value (string)
            self.code.emit(OP_LOADIMMED_STR)  # 0x47
            val_offset = self.add_function_string(value)
            self.code.emit_u16_bigendian(val_offset)
            self.code.emit(OP_PUSH)  # 0x54
        
        # 6. OP_CREATE_OBJECT
        self.code.emit(OP_CREATE_OBJECT)  # 0x01
        
        # Parent class name
        class_offset = self.add_identifier(stmt.class_name)
        self.ident_table.add(class_offset, self.code.get_code_index())
        self.code.emit_u16_bigendian(class_offset)
        
        # Mystery byte (seen in real files, always 0x00)
        self.code.emit(0x00)
        
        # End IP (where object creation ends)
        # We'll calculate this later - for now use placeholder
        end_ip_placeholder = self.code.get_code_index()
        self.code.emit(0x00)  # Will be patched
        
        # 7. OP_ADD_OBJECT  
        self.code.emit(OP_ADD_OBJECT)  # 0x04
        self.code.emit(0x00)  # placeAtRoot = false
        
        # 8. OP_END_OBJECT
        self.code.emit(OP_END_OBJECT)  # 0x05
        self.code.emit(0x00)  # placeAtRoot = false
        
        # Patch end_ip
        current_ip = self.code.get_code_index()
        self.code.code[end_ip_placeholder] = current_ip
        
        # 9. Assign to variable if specified
        if stmt.var:
            self.code.emit(OP_SETCURVAR_CREATE)  # 0x25
            var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
            var_offset = self.add_identifier(var_name)
            self.ident_table.add(var_offset, self.code.get_code_index())
            self.code.emit_u16_bigendian(var_offset)
            
            # 10. OP_SETCUROBJECT - make it current object
            self.code.emit(OP_SETCUROBJECT)  # 0x32
    
    def compile_method_call(self, stmt: MethodCall):
        # OP_PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # Push arguments
        for arg in stmt.args:
            if arg.startswith('"') or not arg.startswith('%'):
                # String literal
                self.code.emit(OP_LOADIMMED_STR)
                str_offset = self.add_function_string(arg.strip('"'))
                self.code.emit_u16_bigendian(str_offset)
            else:
                # Variable
                self.code.emit(OP_LOADIMMED_IDENT)
                var_name = arg[1:] if arg.startswith('%') else arg
                var_offset = self.add_identifier(var_name)
                self.ident_table.add(var_offset, self.code.get_code_index())
                self.code.emit_u16_bigendian(var_offset)
            
            self.code.emit(OP_PUSH)
        
        # Load object
        if stmt.obj.startswith('%'):
            self.code.emit(OP_SETCURVAR)
            var_name = stmt.obj[1:]
            var_offset = self.add_identifier(var_name)
            self.ident_table.add(var_offset, self.code.get_code_index())
            self.code.emit_u16_bigendian(var_offset)
            self.code.emit(OP_SETCUROBJECT)
        
        # OP_CALLFUNC
        self.code.emit(OP_CALLFUNC)
        
        # Method name
        method_offset = self.add_identifier(stmt.method)
        self.ident_table.add(method_offset, self.code.get_code_index())
        self.code.emit_u16_bigendian(method_offset)
        
        # Namespace (0)
        self.code.emit_u16_bigendian(0x0000)
        
        # Call type (METHOD)
        self.code.emit(CALL_METHOD)
    
    def compile_function_call(self, stmt: FunctionCall):
        # Similar to method call but with CALL_FUNCTION
        self.code.emit(OP_PUSHFRAME)
        
        for arg in stmt.args:
            self.code.emit(OP_LOADIMMED_STR)
            str_offset = self.add_function_string(arg.strip('"'))
            self.code.emit_u16_bigendian(str_offset)
            self.code.emit(OP_PUSH)
        
        self.code.emit(OP_CALLFUNC)
        func_offset = self.add_identifier(stmt.func)
        self.ident_table.add(func_offset, self.code.get_code_index())
        self.code.emit_u16_bigendian(func_offset)
        self.code.emit_u16_bigendian(0x0000)
        self.code.emit(CALL_FUNCTION)
    
    def compile_assignment(self, stmt: Assignment):
        # Load value
        if stmt.value.startswith('"'):
            self.code.emit(OP_LOADIMMED_STR)
            str_offset = self.add_function_string(stmt.value.strip('"'))
            self.code.emit_u16_bigendian(str_offset)
        else:
            self.code.emit(OP_LOADIMMED_IDENT)
            val_offset = self.add_identifier(stmt.value)
            self.ident_table.add(val_offset, self.code.get_code_index())
            self.code.emit_u16_bigendian(val_offset)
        
        # Set variable
        self.code.emit(OP_SETCURVAR_CREATE)
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.ident_table.add(var_offset, self.code.get_code_index())
        self.code.emit_u16_bigendian(var_offset)
    
    def compile_return(self, stmt: ReturnStatement):
        if stmt.value:
            # Load return value
            if stmt.value.startswith('%'):
                self.code.emit(OP_SETCURVAR)
                var_name = stmt.value[1:]
                var_offset = self.add_identifier(var_name)
                self.ident_table.add(var_offset, self.code.get_code_index())
                self.code.emit_u16_bigendian(var_offset)
        
        self.code.emit(OP_RETURN)
    
    def compile_if(self, stmt: IfStatement):
        else_label = self.gen_label() if stmt.else_body else None
        end_label = self.gen_label()
        
        # Evaluate condition (simplified)
        self.compile_condition(stmt.condition)
        
        # Jump if false
        self.code.emit(OP_JMPIFNOT)
        if stmt.else_body:
            self.code.emit_jump_placeholder(else_label)
        else:
            self.code.emit_jump_placeholder(end_label)
        
        # Then body
        for s in stmt.then_body:
            self.compile_statement(s)
        
        if stmt.else_body:
            # Jump over else
            self.code.emit(OP_JMP)
            self.code.emit_jump_placeholder(end_label)
            
            # Else body
            self.code.place_label(else_label)
            for s in stmt.else_body:
                self.compile_statement(s)
        
        self.code.place_label(end_label)
    
    def compile_while(self, stmt: WhileLoop):
        start_label = self.gen_label()
        end_label = self.gen_label()
        
        self.code.place_label(start_label)
        self.compile_condition(stmt.condition)
        
        self.code.emit(OP_JMPIFNOT)
        self.code.emit_jump_placeholder(end_label)
        
        for s in stmt.body:
            self.compile_statement(s)
        
        self.code.emit(OP_JMP)
        self.code.emit_jump_placeholder(start_label)
        
        self.code.place_label(end_label)
    
    def compile_condition(self, condition: str):
        # Very simplified condition compilation
        # Just load as string and compare
        if '$=' in condition or '==' in condition:
            parts = re.split(r'\$=|==', condition)
            if len(parts) == 2:
                left = parts[0].strip()
                right = parts[1].strip().strip('"')
                
                # Load left
                if left.startswith('%'):
                    self.code.emit(OP_SETCURVAR)
                    var_name = left[1:]
                    var_offset = self.add_identifier(var_name)
                    self.ident_table.add(var_offset, self.code.get_code_index())
                    self.code.emit_u16_bigendian(var_offset)
                
                # Load right
                self.code.emit(OP_LOADIMMED_STR)
                str_offset = self.add_function_string(right)
                self.code.emit_u16_bigendian(str_offset)
                
                # Compare
                self.code.emit(OP_CMPEQ)
        else:
            # Just push true for now
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16_bigendian(0)
    
    def write_cso(self, output_path: str):
        """Write CSO file in Torque3D/Scarface format"""
        self.code.patch_jumps()
        
        with open(output_path, 'wb') as f:
            # Version
            f.write(struct.pack('<I', 1))
            
            # Global strings
            global_str_bytes = self.global_strings.to_bytes()
            f.write(struct.pack('<I', len(global_str_bytes)))
            f.write(global_str_bytes)
            
            # Global floats (BEFORE function strings!)
            f.write(struct.pack('<I', 0))
            
            # Function strings
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            # Function floats
            f.write(struct.pack('<I', 0))
            
            # Code section
            # CRITICAL: Write U32 count, not byte count!
            f.write(struct.pack('<I', len(self.code.code)))
            
            # NO LINE BREAK PAIRS - BrokenFace doesn't expect them!
            # (Real Scarface files have them but BrokenFace ignores)
            
            # Write compressed code
            f.write(self.code.to_bytes())
            
            # IdentTable
            f.write(self.ident_table.to_bytes())
    
    def compile_script(self, script: str):
        """Compile a script"""
        parser = Parser(script)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions")
        
        for func in functions:
            self.compile_function(func.name, func.params, func.body)
        
        # Add final return
        self.code.emit(OP_RETURN)

def main():
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.cs> <output.cso>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        script = f.read()
    
    compiler = Compiler()
    compiler.compile_script(script)
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V18 - TORQUE3D FORMAT)")
    print(f"  Code size (U32 elements): {len(compiler.code.code)}")
    compressed_bytes = compiler.code.to_bytes()
    print(f"  Compressed bytes: {len(compressed_bytes)}")
    print(f"  Compression ratio: {len(compressed_bytes)/len(compiler.code.code):.2f} bytes/U32")
    print(f"  Global strings: {len(compiler.global_strings.strings)}")
    print(f"  Function strings: {len(compiler.func_strings.strings)}")
    print(f"  IdentTable entries: {len(compiler.ident_table.entries)}")

if __name__ == '__main__':
    main()
