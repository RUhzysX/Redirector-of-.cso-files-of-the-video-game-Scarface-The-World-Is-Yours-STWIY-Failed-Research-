#!/usr/bin/env python3
"""
CSO Recompiler for Torque3D (Scarface: The World Is Yours)
Author: Kunal (III Least I Professor 0)
Version: 0.1 - ActionMaps Initial Implementation

This recompiler takes decompiled .cs TorqueScript files and recompiles them 
back into .cso binary format that the game can load.

Usage:
    python3 cso_recompiler.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import IntEnum


# ============================================================================
# OPCODES (from CodeBlock.h)
# ============================================================================

class OpCode(IntEnum):
    """TorqueScript VM Opcodes"""
    OP_FUNC_DECL = 0
    OP_CREATE_OBJECT = 1
    OP_ADD_OBJECT = 4
    OP_END_OBJECT = 5
    OP_JMPIFFNOT = 6
    OP_JMPIFNOT = 7
    OP_JMPIFF = 8
    OP_JMPIF = 9
    OP_JMP = 12
    OP_RETURN = 13
    OP_CMPEQ = 14
    OP_SETCURVAR = 36
    OP_SETCURVAR_CREATE = 37
    OP_SETCURVAR_ARRAY = 40
    OP_SETCURVAR_ARRAY_CREATE = 41
    OP_LOADVAR_UINT = 44
    OP_LOADVAR_FLT = 45
    OP_LOADVAR_STR = 46
    OP_SAVEVAR_UINT = 47
    OP_SAVEVAR_FLT = 48
    OP_SAVEVAR_STR = 49
    OP_SETCUROBJECT = 50
    OP_SETCUROBJECT_NEW = 51
    OP_SETCURFIELD = 52
    OP_SETCURFIELD_ARRAY = 53
    OP_LOADFIELD_UINT = 54
    OP_LOADFIELD_FLT = 55
    OP_LOADFIELD_STR = 56
    OP_SAVEFIELD_UINT = 57
    OP_SAVEFIELD_FLT = 58
    OP_SAVEFIELD_STR = 59
    OP_LOADIMMED_UINT = 69
    OP_LOADIMMED_FLT = 70
    OP_LOADIMMED_STR = 71
    OP_LOADIMMED_IDENT = 72
    OP_TAG_TO_STR = 73
    OP_CALLFUNC_RESOLVE = 74
    OP_CALLFUNC = 75
    OP_PUSH = 84
    OP_PUSH_FRAME = 85


class CallType(IntEnum):
    """Function call types"""
    FUNCTION_CALL = 0
    METHOD_CALL = 1
    PARENT_CALL = 2


# ============================================================================
# STRING TABLE MANAGEMENT
# ============================================================================

class StringTable:
    """Manages a string table for CSO files"""
    
    def __init__(self, name: str = ""):
        self.name = name
        self.strings: List[str] = []
        self.offsets: Dict[str, int] = {}
        
    def add(self, string: str) -> int:
        """Add a string to the table and return its offset"""
        if string in self.offsets:
            return self.offsets[string]
        
        # Calculate offset (sum of all previous strings + null terminators)
        offset = sum(len(s) + 1 for s in self.strings)
        self.strings.append(string)
        self.offsets[string] = offset
        return offset
    
    def get_offset(self, string: str) -> Optional[int]:
        """Get the offset of a string if it exists"""
        return self.offsets.get(string)
    
    def to_bytes(self) -> bytes:
        """Convert the string table to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)
    
    def __len__(self) -> int:
        """Return the total size in bytes"""
        return sum(len(s) + 1 for s in self.strings)


# ============================================================================
# BYTECODE BUILDER
# ============================================================================

class BytecodeBuilder:
    """Builds bytecode instruction stream"""
    
    def __init__(self):
        self.code: List[int] = []
        
    def emit(self, *values: int):
        """Emit one or more uint32 values"""
        self.code.extend(values)
    
    def get_ip(self) -> int:
        """Get current instruction pointer"""
        return len(self.code)
    
    def patch(self, index: int, value: int):
        """Patch a value at a specific index"""
        if 0 <= index < len(self.code):
            self.code[index] = value
    
    def to_bytes(self) -> bytes:
        """Convert bytecode to binary format"""
        return b''.join(struct.pack('<I', val) for val in self.code)
    
    def __len__(self) -> int:
        """Return number of instructions"""
        return len(self.code)


# ============================================================================
# AST NODES (Abstract Syntax Tree)
# ============================================================================

class ASTNode:
    """Base class for AST nodes"""
    def __init__(self, line: int = 0):
        self.line = line


@dataclass
class FunctionDecl:
    """Function declaration"""
    name: str
    params: List[str]
    body: List['ASTNode']
    line: int = 0


@dataclass
class VarAssignment:
    """Variable assignment: %var = value"""
    var_name: str
    value: 'ASTNode'
    line: int = 0


@dataclass
class ObjectCreation:
    """Object creation: %var = new ClassName(...)"""
    var_name: str
    class_name: str
    properties: Dict[str, str]
    line: int = 0


@dataclass
class MethodCall:
    """Method call: %obj.method(args)"""
    object_var: str
    method_name: str
    arguments: List[str]
    line: int = 0


@dataclass
class FunctionCall:
    """Function call: funcName(args)"""
    function_name: str
    arguments: List[str]
    line: int = 0


@dataclass
class ReturnStmt:
    """Return statement"""
    value: Optional['ASTNode'] = None
    line: int = 0


@dataclass
class IfStmt:
    """If statement"""
    condition: 'ASTNode'
    then_block: List['ASTNode']
    else_block: Optional[List['ASTNode']] = None
    line: int = 0


@dataclass
class StringLiteral:
    """String literal"""
    value: str
    line: int = 0


@dataclass
class IntLiteral:
    """Integer literal"""
    value: int
    line: int = 0


@dataclass
class VarReference:
    """Variable reference"""
    var_name: str
    line: int = 0


@dataclass
class Identifier:
    """Identifier (bare word)"""
    name: str
    line: int = 0


# ============================================================================
# PARSER
# ============================================================================

class TorqueScriptParser:
    """Parse decompiled TorqueScript into AST"""
    
    def __init__(self, source: str):
        self.source = source
        self.functions: List[FunctionDecl] = []
    
    def parse(self) -> List[FunctionDecl]:
        """Parse the entire source file"""
        # Match function definitions
        func_pattern = r'function\s+(\w+)\s*\(\s*([^)]*)\s*\)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}'
        
        for match in re.finditer(func_pattern, self.source, re.MULTILINE | re.DOTALL):
            func_name = match.group(1)
            params_str = match.group(2).strip()
            body_str = match.group(3)
            
            # Parse parameters
            params = [p.strip() for p in params_str.split(',') if p.strip()]
            
            # Parse function body
            body = self.parse_statements(body_str)
            
            func = FunctionDecl(name=func_name, params=params, body=body)
            self.functions.append(func)
        
        return self.functions
    
    def parse_statements(self, body: str) -> List[ASTNode]:
        """Parse statements in a block"""
        statements = []
        
        # Split by semicolons (simple approach)
        lines = body.split(';')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            stmt = self.parse_statement(line)
            if stmt:
                statements.append(stmt)
        
        return statements
    
    def parse_statement(self, stmt: str) -> Optional[ASTNode]:
        """Parse a single statement"""
        stmt = stmt.strip()
        
        if not stmt:
            return None
        
        # Return statement
        if stmt.startswith('return'):
            return ReturnStmt()
        
        # Variable assignment with object creation
        if '=' in stmt and 'new ' in stmt:
            return self.parse_object_creation(stmt)
        
        # Variable assignment
        if '=' in stmt and stmt.startswith('%'):
            return self.parse_var_assignment(stmt)
        
        # Method call
        if '.' in stmt and '(' in stmt:
            return self.parse_method_call(stmt)
        
        # Function call
        if '(' in stmt:
            return self.parse_function_call(stmt)
        
        return None
    
    def parse_var_assignment(self, stmt: str) -> Optional[VarAssignment]:
        """Parse variable assignment"""
        parts = stmt.split('=', 1)
        if len(parts) != 2:
            return None
        
        var_name = parts[0].strip()
        value_str = parts[1].strip()
        
        # Parse the value (simplified)
        value = self.parse_expression(value_str)
        
        return VarAssignment(var_name=var_name, value=value)
    
    def parse_object_creation(self, stmt: str) -> Optional[ObjectCreation]:
        """Parse object creation: %var = new ClassName(...)"""
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return None
        
        var_name = match.group(1)
        class_name = match.group(2)
        args_str = match.group(3)
        
        # Parse properties (Name : "value", ...)
        properties = {}
        if args_str.strip():
            # Simple parsing - handle Name : "value" pairs
            prop_pattern = r'(\w+)\s*:\s*"([^"]*)"'
            for prop_match in re.finditer(prop_pattern, args_str):
                prop_name = prop_match.group(1)
                prop_value = prop_match.group(2)
                properties[prop_name] = prop_value
        
        return ObjectCreation(var_name=var_name, class_name=class_name, 
                            properties=properties)
    
    def parse_method_call(self, stmt: str) -> Optional[MethodCall]:
        """Parse method call: %obj.method(args)"""
        match = re.match(r'(%\w+)\.(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return None
        
        object_var = match.group(1)
        method_name = match.group(2)
        args_str = match.group(3)
        
        # Parse arguments
        arguments = [arg.strip() for arg in args_str.split(',') if arg.strip()]
        
        return MethodCall(object_var=object_var, method_name=method_name,
                         arguments=arguments)
    
    def parse_function_call(self, stmt: str) -> Optional[FunctionCall]:
        """Parse function call: funcName(args)"""
        match = re.match(r'(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return None
        
        function_name = match.group(1)
        args_str = match.group(2)
        
        # Parse arguments
        arguments = [arg.strip() for arg in args_str.split(',') if arg.strip()]
        
        return FunctionCall(function_name=function_name, arguments=arguments)
    
    def parse_expression(self, expr: str) -> ASTNode:
        """Parse an expression"""
        expr = expr.strip()
        
        # String literal
        if expr.startswith('"') and expr.endswith('"'):
            return StringLiteral(value=expr[1:-1])
        
        # Integer literal
        if expr.isdigit():
            return IntLiteral(value=int(expr))
        
        # Variable reference
        if expr.startswith('%'):
            return VarReference(var_name=expr)
        
        # Identifier
        return Identifier(name=expr)


# ============================================================================
# CODE GENERATOR
# ============================================================================

class CSOCodeGenerator:
    """Generate CSO bytecode from AST"""
    
    def __init__(self):
        self.global_strings = StringTable("global")
        self.function_strings = StringTable("function")
        self.bytecode = BytecodeBuilder()
    
    def generate(self, functions: List[FunctionDecl]) -> bytes:
        """Generate complete CSO binary from function list"""
        
        # Generate bytecode for all functions
        for func in functions:
            self.generate_function(func)
        
        # Build the final binary
        return self.build_cso()
    
    def generate_function(self, func: FunctionDecl):
        """Generate bytecode for a function"""
        
        # Add function name to global strings
        fn_name_offset = self.global_strings.add(func.name)
        fn_namespace_offset = 0  # Empty namespace
        fn_package_offset = 0  # Empty package
        
        # Emit OP_FUNC_DECL
        self.bytecode.emit(OpCode.OP_FUNC_DECL)
        self.bytecode.emit(fn_name_offset)
        self.bytecode.emit(fn_namespace_offset)
        self.bytecode.emit(fn_package_offset)
        self.bytecode.emit(1)  # has_body = true
        
        # Reserve space for newip
        newip_index = self.bytecode.get_ip()
        self.bytecode.emit(0)  # Will be patched later
        
        # Emit argument count
        self.bytecode.emit(len(func.params))
        
        # Emit argument names
        for param in func.params:
            param_offset = self.global_strings.add(param)
            self.bytecode.emit(param_offset)
        
        # Generate body
        for stmt in func.body:
            self.generate_statement(stmt)
        
        # Add return if not present
        if not func.body or not isinstance(func.body[-1], ReturnStmt):
            self.bytecode.emit(OpCode.OP_RETURN)
        
        # Patch the newip
        func_end_ip = self.bytecode.get_ip()
        self.bytecode.patch(newip_index, func_end_ip)
    
    def generate_statement(self, stmt: ASTNode):
        """Generate bytecode for a statement"""
        
        if isinstance(stmt, VarAssignment):
            self.generate_var_assignment(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.generate_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.generate_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.generate_function_call(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.bytecode.emit(OpCode.OP_RETURN)
    
    def generate_var_assignment(self, stmt: VarAssignment):
        """Generate variable assignment"""
        var_offset = self.global_strings.add(stmt.var_name)
        
        # SETCURVAR_CREATE
        self.bytecode.emit(OpCode.OP_SETCURVAR_CREATE)
        self.bytecode.emit(var_offset)
        
        # Generate value expression
        self.generate_expression(stmt.value)
        
        # SAVEVAR_STR (assume string for now)
        self.bytecode.emit(OpCode.OP_SAVEVAR_STR)
    
    def generate_object_creation(self, stmt: ObjectCreation):
        """Generate object creation"""
        class_offset = self.global_strings.add(stmt.class_name)
        
        # OP_CREATE_OBJECT
        self.bytecode.emit(OpCode.OP_CREATE_OBJECT)
        self.bytecode.emit(class_offset)
        self.bytecode.emit(0)  # is_datablock
        self.bytecode.emit(0)  # is_internal
        self.bytecode.emit(0)  # is_singleton
        self.bytecode.emit(0)  # line_number
        self.bytecode.emit(0)  # fail_jump
        
        # Set object properties
        for prop_name, prop_value in stmt.properties.items():
            # SETCURFIELD
            field_offset = self.global_strings.add(prop_name)
            self.bytecode.emit(OpCode.OP_SETCURFIELD)
            self.bytecode.emit(field_offset)
            
            # Load property value
            value_offset = self.function_strings.add(prop_value)
            self.bytecode.emit(OpCode.OP_LOADIMMED_STR)
            self.bytecode.emit(value_offset)
            
            # SAVEFIELD_STR
            self.bytecode.emit(OpCode.OP_SAVEFIELD_STR)
        
        # OP_ADD_OBJECT
        self.bytecode.emit(OpCode.OP_ADD_OBJECT)
        self.bytecode.emit(0)  # place_at_root
        
        # OP_END_OBJECT
        self.bytecode.emit(OpCode.OP_END_OBJECT)
        self.bytecode.emit(0)  # place_at_root
        
        # SETCUROBJECT_NEW
        self.bytecode.emit(OpCode.OP_SETCUROBJECT_NEW)
        
        # Assign to variable
        var_offset = self.global_strings.add(stmt.var_name)
        self.bytecode.emit(OpCode.OP_SETCURVAR_CREATE)
        self.bytecode.emit(var_offset)
        self.bytecode.emit(OpCode.OP_SAVEVAR_STR)
    
    def generate_method_call(self, stmt: MethodCall):
        """Generate method call"""
        # Load object
        obj_offset = self.global_strings.add(stmt.object_var)
        self.bytecode.emit(OpCode.OP_SETCURVAR)
        self.bytecode.emit(obj_offset)
        self.bytecode.emit(OpCode.OP_LOADVAR_STR)
        self.bytecode.emit(OpCode.OP_SETCUROBJECT)
        
        # Push arguments
        for arg in stmt.arguments:
            self.generate_argument(arg)
            self.bytecode.emit(OpCode.OP_PUSH)
        
        # Call method
        method_offset = self.global_strings.add(stmt.method_name)
        self.bytecode.emit(OpCode.OP_CALLFUNC)
        self.bytecode.emit(method_offset)
        self.bytecode.emit(0)  # namespace
        self.bytecode.emit(CallType.METHOD_CALL)
    
    def generate_function_call(self, stmt: FunctionCall):
        """Generate function call"""
        # Push arguments
        for arg in stmt.arguments:
            self.generate_argument(arg)
            self.bytecode.emit(OpCode.OP_PUSH)
        
        # Call function
        func_offset = self.global_strings.add(stmt.function_name)
        self.bytecode.emit(OpCode.OP_CALLFUNC)
        self.bytecode.emit(func_offset)
        self.bytecode.emit(0)  # namespace
        self.bytecode.emit(CallType.FUNCTION_CALL)
    
    def generate_argument(self, arg: str):
        """Generate code for a function/method argument"""
        arg = arg.strip()
        
        # String literal
        if arg.startswith('"') and arg.endswith('"'):
            str_val = arg[1:-1]
            str_offset = self.function_strings.add(str_val)
            self.bytecode.emit(OpCode.OP_LOADIMMED_STR)
            self.bytecode.emit(str_offset)
        
        # Integer literal  
        elif arg.isdigit():
            self.bytecode.emit(OpCode.OP_LOADIMMED_UINT)
            self.bytecode.emit(int(arg))
        
        # Variable reference
        elif arg.startswith('%'):
            var_offset = self.global_strings.add(arg)
            self.bytecode.emit(OpCode.OP_SETCURVAR)
            self.bytecode.emit(var_offset)
            self.bytecode.emit(OpCode.OP_LOADVAR_STR)
        
        # Identifier
        else:
            ident_offset = self.global_strings.add(arg)
            self.bytecode.emit(OpCode.OP_LOADIMMED_IDENT)
            self.bytecode.emit(ident_offset)
    
    def generate_expression(self, expr: ASTNode):
        """Generate code for an expression"""
        if isinstance(expr, StringLiteral):
            str_offset = self.function_strings.add(expr.value)
            self.bytecode.emit(OpCode.OP_LOADIMMED_STR)
            self.bytecode.emit(str_offset)
        
        elif isinstance(expr, IntLiteral):
            self.bytecode.emit(OpCode.OP_LOADIMMED_UINT)
            self.bytecode.emit(expr.value)
        
        elif isinstance(expr, VarReference):
            var_offset = self.global_strings.add(expr.var_name)
            self.bytecode.emit(OpCode.OP_SETCURVAR)
            self.bytecode.emit(var_offset)
            self.bytecode.emit(OpCode.OP_LOADVAR_STR)
        
        elif isinstance(expr, Identifier):
            ident_offset = self.global_strings.add(expr.name)
            self.bytecode.emit(OpCode.OP_LOADIMMED_IDENT)
            self.bytecode.emit(ident_offset)
    
    def build_cso(self) -> bytes:
        """Build the final CSO binary"""
        output = bytearray()
        
        # Header: Version
        output.extend(struct.pack('<I', 1))
        
        # Global string table
        global_strings_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(global_strings_bytes)))
        output.extend(global_strings_bytes)
        
        # Function string table marker and size
        output.extend(struct.pack('<I', 0))  # Marker
        function_strings_bytes = self.function_strings.to_bytes()
        output.extend(struct.pack('<I', len(function_strings_bytes)))
        output.extend(function_strings_bytes)
        
        # Code size field (0 in the original)
        output.extend(struct.pack('<I', 0))
        
        # Actual bytecode size
        bytecode_bytes = self.bytecode.to_bytes()
        output.extend(struct.pack('<I', len(bytecode_bytes)))
        
        # Bytecode
        output.extend(bytecode_bytes)
        
        return bytes(output)


# ============================================================================
# MAIN COMPILER CLASS
# ============================================================================

class CSOCompiler:
    """Main CSO compiler"""
    
    def __init__(self):
        self.parser = None
        self.generator = None
    
    def compile_file(self, input_path: str, output_path: str):
        """Compile a .cs file to .cso"""
        
        print(f"Reading {input_path}...")
        with open(input_path, 'r', encoding='utf-8') as f:
            source = f.read()
        
        print("Parsing...")
        self.parser = TorqueScriptParser(source)
        functions = self.parser.parse()
        print(f"Found {len(functions)} functions")
        
        print("Generating bytecode...")
        self.generator = CSOCodeGenerator()
        cso_binary = self.generator.generate(functions)
        
        print(f"Writing {output_path}...")
        with open(output_path, 'wb') as f:
            f.write(cso_binary)
        
        print(f"Success! Generated {len(cso_binary)} bytes")
        print(f"  Global strings: {len(self.generator.global_strings.strings)}")
        print(f"  Function strings: {len(self.generator.function_strings.strings)}")
        print(f"  Bytecode instructions: {len(self.generator.bytecode)}")


# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

def main():
    """Main entry point"""
    if len(sys.argv) != 3:
        print("CSO Recompiler for Scarface: The World Is Yours")
        print("Usage: python3 cso_recompiler.py input.cs output.cso")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    try:
        compiler = CSOCompiler()
        compiler.compile_file(input_file, output_file)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
