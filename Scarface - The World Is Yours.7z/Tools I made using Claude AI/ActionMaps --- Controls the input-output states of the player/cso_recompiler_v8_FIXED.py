#!/usr/bin/env python3
"""
CSO Recompiler V8 - CRITICAL FIXES

KEY FIXES based on Bytecode-Parsing-README.md:
1. Extended codes (0xFF prefix) use LITTLE-ENDIAN, not big-endian!
   - 0xFF 0x11 0x22 = code 0x2211 (LE), NOT 0x1122
2. IdentTable structure uses 4-byte fields, not 2-byte!
   - Offset: 4 bytes LE
   - Count: 4 bytes LE  
   - Locations: 4 bytes LE each
3. String encoding in bytecode:
   - Unpatched: 2 bytes big-endian
   - Patched: 2 bytes little-endian (IdentTable patches them)

Usage: python3 cso_recompiler_v8_FIXED.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x34
OP_SAVEFIELD_STR = 0x3B
OP_LOADIMMED_UINT = 0x45
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        """Add string and return its offset"""
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class CodeBuilder:
    def __init__(self):
        self.codes = []
        self.string_refs = []  # List of (code_index, string_offset)
        self.labels = {}
        self.fixups = []
    
    def emit(self, code: int):
        """Emit a single code (1 byte if <256, 3 bytes if >=256)"""
        self.codes.append(code)
    
    def emit_u16be(self, value: int, is_string_ref=False, string_offset=None):
        """Emit 16-bit value as big-endian (used for unpatched string refs)"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        
        # Track string references for IdentTable
        if is_string_ref and string_offset is not None:
            code_idx = len(self.codes)
            self.string_refs.append((code_idx, string_offset))
        
        self.codes.append(high)
        self.codes.append(low)
    
    def get_code_index(self) -> int:
        return len(self.codes)
    
    def set_label(self, name: str):
        self.labels[name] = len(self.codes)
    
    def emit_jump(self, opcode: int, label: str):
        self.emit(opcode)
        fixup_idx = len(self.codes)
        self.emit(0)
        self.fixups.append((fixup_idx, label))
    
    def patch_jumps(self):
        for code_idx, label in self.fixups:
            if label not in self.labels:
                raise ValueError(f"Undefined label: {label}")
            target = self.labels[label]
            self.codes[code_idx] = target
    
    def to_bytes(self) -> bytes:
        """
        Convert codes to binary format.
        CRITICAL: Extended codes (>255) are encoded as:
        0xFF <low_byte> <high_byte>  (LITTLE-ENDIAN!)
        """
        result = bytearray()
        for code in self.codes:
            if code < 256:
                result.append(code)
            else:
                # Extended code: 0xFF + 16-bit LITTLE-ENDIAN
                result.append(EXT_CTRL_CODE)
                # Little-endian encoding!
                low = code & 0xFF
                high = (code >> 8) & 0xFF
                result.append(low)
                result.append(high)
        return bytes(result)
    
    def get_code_count(self) -> int:
        """Return number of codes (not bytes)"""
        return len(self.codes)


class Statement:
    pass


class FunctionDecl(Statement):
    def __init__(self, name: str, params: List[str], body: List[Statement]):
        self.name = name
        self.params = params
        self.body = body


class ObjectCreation(Statement):
    def __init__(self, var: str, classname: str, name: str, properties: List[Tuple[str, str]]):
        self.var = var
        self.classname = classname
        self.name = name
        self.properties = properties


class MethodCall(Statement):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args


class FunctionCall(Statement):
    def __init__(self, func: str, args: List[str]):
        self.func = func
        self.args = args


class Assignment(Statement):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value


class Return(Statement):
    def __init__(self, value: Optional[str] = None):
        self.value = value


class IfStatement(Statement):
    def __init__(self, condition: str, then_body: List[Statement], else_body: Optional[List[Statement]] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body


class Parser:
    def __init__(self, source: str):
        self.source = source
        self.lines = [line.strip() for line in source.split('\n')]
        self.pos = 0
    
    def parse(self) -> List[Statement]:
        statements = []
        while self.pos < len(self.lines):
            line = self.lines[self.pos]
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            if line.startswith('function '):
                statements.append(self.parse_function())
            else:
                self.pos += 1
        
        return statements
    
    def parse_function(self) -> FunctionDecl:
        line = self.lines[self.pos]
        self.pos += 1
        
        # Parse: function name(param1, param2, ...)
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            raise ValueError(f"Invalid function declaration: {line}")
        
        name = match.group(1)
        params_str = match.group(2).strip()
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        # Expect opening brace
        if self.pos < len(self.lines) and self.lines[self.pos] == '{':
            self.pos += 1
        
        # Parse body
        body = []
        while self.pos < len(self.lines):
            line = self.lines[self.pos]
            
            if line == '}':
                self.pos += 1
                break
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)
        
        return FunctionDecl(name, params, body)
    
    def parse_statement(self) -> Optional[Statement]:
        line = self.lines[self.pos]
        self.pos += 1
        
        # Return statement
        if line.startswith('return'):
            match = re.match(r'return\s*(.*?);', line)
            value = match.group(1).strip() if match and match.group(1) else None
            return Return(value)
        
        # Object creation: %var = new Class(Name) : prop;
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(\s*(\w+)(?:\s*:\s*"([^"]*)")?\s*\)\s*(?::\s*prop)?;', line)
        if match:
            var = match.group(1)
            classname = match.group(2)
            name = match.group(3)
            
            # Look for property block
            properties = []
            if self.pos < len(self.lines) and self.lines[self.pos] == '{':
                self.pos += 1
                while self.pos < len(self.lines):
                    prop_line = self.lines[self.pos]
                    if prop_line == '};':
                        self.pos += 1
                        break
                    
                    prop_match = re.match(r'(\w+)\s*=\s*"([^"]*)";', prop_line)
                    if prop_match:
                        properties.append((prop_match.group(1), prop_match.group(2)))
                    self.pos += 1
            
            return ObjectCreation(var, classname, name, properties)
        
        # Method call: %obj.method(args);
        match = re.match(r'(%\w+)\.(\w+)\s*\((.*?)\);', line)
        if match:
            obj = match.group(1)
            method = match.group(2)
            args_str = match.group(3)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return MethodCall(obj, method, args)
        
        # Function call: func(args);
        match = re.match(r'(\w+)\s*\((.*?)\);', line)
        if match:
            func = match.group(1)
            args_str = match.group(2)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return FunctionCall(func, args)
        
        # Assignment: %var = value;
        match = re.match(r'(%\w+)\s*=\s*"?([^";]+)"?;', line)
        if match:
            var = match.group(1)
            value = match.group(2).strip().strip('"')
            return Assignment(var, value)
        
        return None


class Compiler:
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.code = CodeBuilder()
    
    def compile(self, statements: List[Statement]) -> bytes:
        """Compile statements to CSO binary"""
        
        # Compile all functions
        for stmt in statements:
            if isinstance(stmt, FunctionDecl):
                self.compile_function(stmt)
        
        # Patch jumps
        self.code.patch_jumps()
        
        # Build final binary
        return self.build_cso()
    
    def compile_function(self, func: FunctionDecl):
        """Compile a function declaration"""
        fn_name_off = self.global_strings.add(func.name)
        
        # Emit OP_FUNC_DECL
        self.code.emit(OP_FUNC_DECL)
        
        # Function name (big-endian, will be patched)
        self.code.emit_u16be(fn_name_off, is_string_ref=True, string_offset=fn_name_off)
        
        # Namespace (0x0000)
        self.code.emit_u16be(0x0000)
        
        # Package (0x0000)
        self.code.emit_u16be(0x0000)
        
        # Has body (0x01)
        self.code.emit(0x01)
        
        # End IP (will be set after body)
        end_ip_idx = self.code.get_code_index()
        self.code.emit(0)  # Placeholder
        
        # Parameter count
        self.code.emit(len(func.params))
        
        # Parameter names
        for param in func.params:
            param_off = self.func_strings.add(param)
            self.code.emit_u16be(param_off, is_string_ref=True, string_offset=param_off)
        
        # Compile body
        for stmt in func.body:
            self.compile_statement(stmt)
        
        # Set end IP
        end_ip = self.code.get_code_index()
        self.code.codes[end_ip_idx] = end_ip
    
    def compile_statement(self, stmt: Statement):
        """Compile a single statement"""
        if isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, Return):
            self.compile_return(stmt)
    
    def compile_object_creation(self, obj: ObjectCreation):
        """Compile object creation"""
        # PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # Properties
        for prop_name, prop_value in obj.properties:
            # Property name
            prop_name_off = self.func_strings.add(prop_name)
            self.code.emit(OP_LOADIMMED_IDENT)
            self.code.emit_u16be(prop_name_off, is_string_ref=True, string_offset=prop_name_off)
            self.code.emit(OP_PUSH)
            
            # Property value
            prop_value_off = self.func_strings.add(prop_value)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16be(prop_value_off, is_string_ref=True, string_offset=prop_value_off)
            self.code.emit(OP_PUSH)
        
        # CREATE_OBJECT
        class_off = self.global_strings.add(obj.classname)
        self.code.emit(OP_CREATE_OBJECT)
        self.code.emit_u16be(class_off, is_string_ref=True, string_offset=class_off)
        self.code.emit(0x00)  # Mystery byte
        self.code.emit(0xFF)  # End IP placeholder
        
        # ADD_OBJECT
        self.code.emit(OP_ADD_OBJECT)
        self.code.emit(0x01)  # place_at_root
        
        # SETCURVAR_CREATE (assign to variable)
        var_off = self.func_strings.add(obj.var)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_u16be(var_off, is_string_ref=True, string_offset=var_off)
        
        # SAVEVAR_STR
        self.code.emit(OP_SAVEVAR_STR)
        
        # END_OBJECT
        self.code.emit(OP_END_OBJECT)
        self.code.emit(0x01)  # place_at_root
    
    def compile_method_call(self, call: MethodCall):
        """Compile method call"""
        # SETCURVAR (object)
        obj_off = self.func_strings.add(call.obj)
        self.code.emit(OP_SETCURVAR)
        self.code.emit_u16be(obj_off, is_string_ref=True, string_offset=obj_off)
        
        # SETCUROBJECT
        self.code.emit(OP_SETCUROBJECT)
        
        # PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # Arguments
        for arg in call.args:
            arg_off = self.func_strings.add(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16be(arg_off, is_string_ref=True, string_offset=arg_off)
            self.code.emit(OP_PUSH)
        
        # CALLFUNC (method)
        method_off = self.global_strings.add(call.method)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_u16be(method_off, is_string_ref=True, string_offset=method_off)
        self.code.emit_u16be(0x0000)  # No namespace
        self.code.emit(0x01)  # Method call
    
    def compile_function_call(self, call: FunctionCall):
        """Compile function call"""
        # PUSHFRAME
        self.code.emit(OP_PUSHFRAME)
        
        # Arguments
        for arg in call.args:
            arg_off = self.func_strings.add(arg)
            self.code.emit(OP_LOADIMMED_STR)
            self.code.emit_u16be(arg_off, is_string_ref=True, string_offset=arg_off)
            self.code.emit(OP_PUSH)
        
        # CALLFUNC
        func_off = self.global_strings.add(call.func)
        self.code.emit(OP_CALLFUNC)
        self.code.emit_u16be(func_off, is_string_ref=True, string_offset=func_off)
        self.code.emit_u16be(0x0000)  # No namespace
        self.code.emit(0x00)  # Function call
    
    def compile_assignment(self, assign: Assignment):
        """Compile assignment"""
        # SETCURVAR_CREATE
        var_off = self.func_strings.add(assign.var)
        self.code.emit(OP_SETCURVAR_CREATE)
        self.code.emit_u16be(var_off, is_string_ref=True, string_offset=var_off)
        
        # Load value
        value_off = self.func_strings.add(assign.value)
        self.code.emit(OP_LOADIMMED_STR)
        self.code.emit_u16be(value_off, is_string_ref=True, string_offset=value_off)
        
        # SAVEVAR_STR
        self.code.emit(OP_SAVEVAR_STR)
    
    def compile_return(self, ret: Return):
        """Compile return statement"""
        if ret.value:
            # Load return value
            if ret.value.startswith('%'):
                # Variable
                var_off = self.func_strings.add(ret.value)
                self.code.emit(OP_SETCURVAR)
                self.code.emit_u16be(var_off, is_string_ref=True, string_offset=var_off)
                self.code.emit(OP_LOADVAR_STR)
            else:
                # String literal
                str_off = self.func_strings.add(ret.value)
                self.code.emit(OP_LOADIMMED_STR)
                self.code.emit_u16be(str_off, is_string_ref=True, string_offset=str_off)
        
        self.code.emit(OP_RETURN)
    
    def build_cso(self) -> bytes:
        """Build final CSO binary file"""
        result = bytearray()
        
        # Version (4 bytes LE)
        result.extend(struct.pack('<I', 1))
        
        # Global string table
        global_str_data = self.global_strings.to_bytes()
        result.extend(struct.pack('<I', len(global_str_data)))
        result.extend(global_str_data)
        
        # Global float table (empty)
        result.extend(struct.pack('<I', 0))
        
        # Function string table
        func_str_data = self.func_strings.to_bytes()
        result.extend(struct.pack('<I', len(func_str_data)))
        result.extend(func_str_data)
        
        # Function float table (empty)
        result.extend(struct.pack('<I', 0))
        
        # Bytecode
        bytecode_data = self.code.to_bytes()
        code_count = self.code.get_code_count()
        result.extend(struct.pack('<I', code_count))
        result.extend(bytecode_data)
        
        # Build IdentTable
        # CRITICAL FIX: Use 4-byte fields (little-endian)!
        ident_table = self.build_ident_table()
        result.extend(ident_table)
        
        return bytes(result)
    
    def build_ident_table(self) -> bytes:
        """
        Build IdentTable with CORRECT structure:
        - Offset: 4 bytes LE (not 2!)
        - Count: 4 bytes LE
        - Locations: 4 bytes LE each
        """
        # Group string references by offset
        refs_by_offset = {}
        for code_idx, string_offset in self.code.string_refs:
            if string_offset not in refs_by_offset:
                refs_by_offset[string_offset] = []
            refs_by_offset[string_offset].append(code_idx)
        
        result = bytearray()
        
        # Entry count (4 bytes LE)
        result.extend(struct.pack('<I', len(refs_by_offset)))
        
        # Entries
        for offset in sorted(refs_by_offset.keys()):
            locations = refs_by_offset[offset]
            
            # Offset (4 bytes LE) - CRITICAL FIX!
            result.extend(struct.pack('<I', offset))
            
            # Count (4 bytes LE)
            result.extend(struct.pack('<I', len(locations)))
            
            # Locations (4 bytes LE each) - CRITICAL FIX!
            for loc in locations:
                result.extend(struct.pack('<I', loc))
        
        return bytes(result)


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_recompiler_v8_FIXED.py input.cs output.cso")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # Read source
    with open(input_file, 'r') as f:
        source = f.read()
    
    # Parse
    parser = Parser(source)
    statements = parser.parse()
    
    print(f"Parsed {len(statements)} functions")
    
    # Compile
    compiler = Compiler()
    binary = compiler.compile(statements)
    
    # Write output
    with open(output_file, 'wb') as f:
        f.write(binary)
    
    print(f"Compiled to {output_file}")
    print(f"Size: {len(binary)} bytes")
    print(f"Code count: {compiler.code.get_code_count()}")
    print(f"Global strings: {len(compiler.global_strings.strings)}")
    print(f"Function strings: {len(compiler.func_strings.strings)}")


if __name__ == '__main__':
    main()
