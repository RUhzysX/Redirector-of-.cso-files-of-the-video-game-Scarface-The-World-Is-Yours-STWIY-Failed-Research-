#!/usr/bin/env python3
"""
CSO (Compiled Script Object) File Analyzer for Torque3D (Scarface Edition)
Analyzes the binary format to understand structure for recompilation
"""

import struct
import sys

# Opcode definitions from CodeBlock.h
OPCODES = {
    0: "OP_FUNC_DECL",
    1: "OP_CREATE_OBJECT",
    2: "OP_2",
    3: "OP_3",
    4: "OP_ADD_OBJECT",
    5: "OP_END_OBJECT",
    6: "OP_JMPIFFNOT",
    7: "OP_JMPIFNOT",
    8: "OP_JMPIFF",
    9: "OP_JMPIF",
    10: "OP_JMPIFNOT_NP",
    11: "OP_JMPIF_NP",
    12: "OP_JMP",
    13: "OP_RETURN",
    14: "OP_CMPEQ",
    15: "OP_CMPLT",
    16: "OP_CMPLE",
    17: "OP_CMPGR",
    18: "OP_CMPGE",
    19: "OP_CMPNE",
    20: "OP_XOR",
    21: "OP_MOD",
    22: "OP_BITAND",
    23: "OP_BITOR",
    24: "OP_NOT",
    25: "OP_NOTF",
    26: "OP_ONESCOMPLEMENT",
    27: "OP_SHR",
    28: "OP_SHL",
    29: "OP_AND",
    30: "OP_OR",
    31: "OP_ADD",
    32: "OP_SUB",
    33: "OP_MUL",
    34: "OP_DIV",
    35: "OP_NEG",
    36: "OP_SETCURVAR",
    37: "OP_SETCURVAR_CREATE",
    38: "OP_SETCURVAR_KURVA",
    39: "OP_SETCURVAR_ANYAD",
    40: "OP_SETCURVAR_ARRAY",
    41: "OP_SETCURVAR_ARRAY_CREATE",
    42: "OP_SETCURVAR_ARRAY_DUNNOWHATISTHIS",
    43: "OP_SETCURVAR_ARRAY_DUNNOWHATISTHIS2",
    44: "OP_LOADVAR_UINT",
    45: "OP_LOADVAR_FLT",
    46: "OP_LOADVAR_STR",
    47: "OP_SAVEVAR_UINT",
    48: "OP_SAVEVAR_FLT",
    49: "OP_SAVEVAR_STR",
    50: "OP_SETCUROBJECT",
    51: "OP_SETCUROBJECT_NEW",
    52: "OP_SETCURFIELD",
    53: "OP_SETCURFIELD_ARRAY",
    54: "OP_LOADFIELD_UINT",
    55: "OP_LOADFIELD_FLT",
    56: "OP_LOADFIELD_STR",
    57: "OP_SAVEFIELD_UINT",
    58: "OP_SAVEFIELD_FLT",
    59: "OP_SAVEFIELD_STR",
    60: "OP_STR_TO_UINT",
    61: "OP_STR_TO_FLT",
    62: "OP_STR_TO_NONE",
    63: "OP_FLT_TO_UINT",
    64: "OP_FLT_TO_STR",
    65: "OP_FLT_TO_NONE",
    66: "OP_UINT_TO_FLT",
    67: "OP_UINT_TO_STR",
    68: "OP_UINT_TO_NONE",
    69: "OP_LOADIMMED_UINT",
    70: "OP_LOADIMMED_FLT",
    71: "OP_LOADIMMED_STR",
    72: "OP_LOADIMMED_IDENT",
    73: "OP_TAG_TO_STR",
    74: "OP_CALLFUNC_RESOLVE",
    75: "OP_CALLFUNC",
    76: "OP_76",
    77: "OP_ADVANCE_STR",
    78: "OP_ADVANCE_STR_APPENDCHAR",
    79: "OP_ADVANCE_STR_COMMA",
    80: "OP_ADVANCE_STR_NUL",
    81: "OP_REWIND_STR",
    82: "OP_TERMINATE_REWIND_STR",
    83: "OP_COMPARE_STR",
    84: "OP_PUSH",
    85: "OP_PUSH_FRAME",
}


class CSOAnalyzer:
    def __init__(self, filepath):
        with open(filepath, 'rb') as f:
            self.data = f.read()
        self.offset = 0
        
    def read_u32(self):
        """Read a little-endian uint32"""
        value = struct.unpack_from('<I', self.data, self.offset)[0]
        self.offset += 4
        return value
    
    def read_bytes(self, count):
        """Read raw bytes"""
        value = self.data[self.offset:self.offset + count]
        self.offset += count
        return value
    
    def read_cstring(self):
        """Read a null-terminated C string"""
        end = self.data.find(b'\x00', self.offset)
        if end == -1:
            return ""
        value = self.data[self.offset:end].decode('ascii', errors='replace')
        self.offset = end + 1
        return value
    
    def analyze(self):
        print("=" * 80)
        print("CSO FILE ANALYSIS")
        print("=" * 80)
        print(f"File size: {len(self.data)} bytes")
        print()
        
        # Header
        print("--- HEADER ---")
        version = self.read_u32()
        print(f"Version: {version}")
        
        global_string_table_size = self.read_u32()
        print(f"Global String Table Size: {global_string_table_size} (0x{global_string_table_size:X})")
        
        # Global string table
        print(f"\n--- GLOBAL STRING TABLE (offset 0x{self.offset:X}) ---")
        global_strings_start = self.offset
        global_strings_end = self.offset + global_string_table_size
        
        global_strings = []
        while self.offset < global_strings_end:
            str_offset = self.offset - global_strings_start
            string = self.read_cstring()
            if string:
                global_strings.append((str_offset, string))
                print(f"  [0x{str_offset:04X}] {string}")
        
        # Function strings table size
        print(f"\n--- FUNCTION STRING TABLE (offset 0x{self.offset:X}) ---")
        function_string_table_offset_marker = self.read_u32()
        function_string_table_size = self.read_u32()
        print(f"Function String Table Size: {function_string_table_size} (0x{function_string_table_size:X})")
        
        function_strings_start = self.offset
        function_strings_end = self.offset + function_string_table_size
        
        function_strings = []
        while self.offset < function_strings_end:
            str_offset = self.offset - function_strings_start
            string = self.read_cstring()
            if string:
                function_strings.append((str_offset, string))
                print(f"  [0x{str_offset:04X}] {string}")
        
        # Code size and bytecode
        print(f"\n--- BYTECODE (offset 0x{self.offset:X}) ---")
        code_size = self.read_u32()
        print(f"Code Size: {code_size} DWORDs ({code_size * 4} bytes)")
        
        # Read and disassemble bytecode
        print(f"\nDisassembling {code_size} instructions:")
        code_start = self.offset
        
        ip = 0
        instruction_count = 0
        while ip < code_size and instruction_count < 200:  # Limit output
            opcode = self.read_u32()
            opcode_name = OPCODES.get(opcode, f"UNKNOWN(0x{opcode:X})")
            
            print(f"  [{ip:4d}] {opcode_name}", end='')
            
            # Handle opcodes with arguments
            if opcode == 0:  # OP_FUNC_DECL
                fn_name_offset = self.read_u32()
                fn_namespace_offset = self.read_u32()
                fn_package_offset = self.read_u32()
                has_body = self.read_u32()
                new_ip = self.read_u32()
                argc = self.read_u32()
                print(f" hasBody={has_body} newIp={new_ip} argc={argc}")
                # Skip argument identifiers
                for _ in range(argc):
                    self.read_u32()
                ip += 6 + argc
            elif opcode == 1:  # OP_CREATE_OBJECT
                obj_parent = self.read_u32()
                is_datablock = self.read_u32()
                is_internal = self.read_u32()
                is_singleton = self.read_u32()
                line_number = self.read_u32()
                fail_jump = self.read_u32()
                print(f" isDataBlock={is_datablock} isInternal={is_internal} isSingleton={is_singleton}")
                ip += 6
            elif opcode in [4, 5]:  # OP_ADD_OBJECT, OP_END_OBJECT
                place_at_root = self.read_u32()
                print(f" placeAtRoot={place_at_root}")
                ip += 1
            elif opcode in [6, 7, 8, 9, 10, 11, 12]:  # Jump instructions
                jump_ip = self.read_u32()
                print(f" -> {jump_ip}")
                ip += 1
            elif opcode in [36, 37, 52]:  # SETCURVAR*, SETCURFIELD
                var_offset = self.read_u32()
                print(f" varOffset=0x{var_offset:X}")
                ip += 1
            elif opcode == 69:  # OP_LOADIMMED_UINT
                value = self.read_u32()
                print(f" value={value}")
                ip += 1
            elif opcode in [70, 71, 72, 73]:  # OP_LOADIMMED_FLT, STR, IDENT, TAG_TO_STR
                str_offset = self.read_u32()
                print(f" offset=0x{str_offset:X}")
                ip += 1
            elif opcode in [74, 75]:  # OP_CALLFUNC_RESOLVE, OP_CALLFUNC
                fn_name = self.read_u32()
                fn_namespace = self.read_u32()
                call_type = self.read_u32()
                call_type_str = ["FunctionCall", "MethodCall", "ParentCall"][call_type] if call_type < 3 else "Unknown"
                print(f" callType={call_type_str}")
                ip += 3
            elif opcode == 78:  # OP_ADVANCE_STR_APPENDCHAR
                char = self.read_u32()
                print(f" char='{chr(char) if 32 <= char < 127 else '?'}'")
                ip += 1
            else:
                print()  # Just newline for simple opcodes
            
            ip += 1
            instruction_count += 1
        
        print(f"\n... (showing first {instruction_count} instructions)")
        
        # Show remaining data size
        remaining = len(self.data) - self.offset
        print(f"\nRemaining data: {remaining} bytes")
        print("=" * 80)


if __name__ == "__main__":
    analyzer = CSOAnalyzer('/mnt/user-data/uploads/actionmaps_Win32.cso')
    analyzer.analyze()
