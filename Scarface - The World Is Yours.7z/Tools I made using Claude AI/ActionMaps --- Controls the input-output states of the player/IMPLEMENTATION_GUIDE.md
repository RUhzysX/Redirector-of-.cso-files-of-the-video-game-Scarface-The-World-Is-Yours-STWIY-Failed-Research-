# Complete CSO Compiler Implementation Guide

## Based on BrokenFace Decompiler & Torque3D Source Analysis

### Key Insights from BrokenFace Decompiler

#### 1. Jump Instructions Pattern

**OP_JMPIFNOT** (0x07) - Jump if condition FALSE:
```
- Read target code index (1 byte, or extended if > 255)
- Pop condition from intStack
- If forward jump (target > current): Create IF statement
- If backward jump (target < current): Create WHILE loop
```

**OP_JMPIF** (0x09) - Jump if condition TRUE:
```
- Same as JMPIFNOT but inverted logic
```

**OP_JMP** (0x0C) - Unconditional jump:
```
- Used for loop continues, breaks, and else blocks
- Forward jump: Jump over else block
- Backward jump: Loop back to start
```

#### 2. If/Else Compilation Pattern

**Simple If:**
```javascript
if (condition) {
    statements...
}
```

**Bytecode:**
```
[evaluate condition] →  intStack
OP_JMPIFNOT <end_label>
[then statements]
<end_label>:
```

**If/Else:**
```javascript
if (condition) {
    then_statements...
} else {
    else_statements...
}
```

**Bytecode:**
```
[evaluate condition] → intStack
OP_JMPIFNOT <else_label>
[then statements]
OP_JMP <end_label>
<else_label>:
[else statements]
<end_label>:
```

#### 3. While Loop Compilation Pattern

```javascript
while (condition) {
    statements...
}
```

**Bytecode:**
```
<start_label>:
[evaluate condition] → intStack
OP_JMPIFNOT <end_label>
[body statements]
OP_JMP <start_label>      // Backward jump!
<end_label>:
```

#### 4. Expression Evaluation

**NOT operator:**
```javascript
!(expression)
```

**Bytecode:**
```
[evaluate expression] → intStack
OP_NOT                    // 0x18
```

**AND operator:**
```javascript
expr1 && expr2
```

**Bytecode:**
```
[evaluate expr1] → intStack
OP_JMPIFNOT_NP <short_circuit>  // 0x0A - No Pop
[evaluate expr2] → intStack
OP_AND                           // 0x1D
<short_circuit>:
```

**OR operator:**
```javascript
expr1 || expr2
```

**Bytecode:**
```
[evaluate expr1] → intStack
OP_JMPIF_NP <short_circuit>     // 0x0B - No Pop
[evaluate expr2] → intStack
OP_OR                            // 0x1E
<short_circuit>:
```

**Comparison operators:**
```javascript
a == b  → OP_CMPEQ (0x0E)
a != b  → OP_CMPNE (0x13)
a < b   → OP_CMPLT (0x0F)
a <= b  → OP_CMPLE (0x10)
a > b   → OP_CMPGR (0x11)
a >= b  → OP_CMPGE (0x12)
```

**Pattern:**
```
[evaluate a] → intStack/fltStack
[evaluate b] → intStack/fltStack
OP_CMPxx
→ result on intStack (1 = true, 0 = false)
```

#### 5. Function Call in Expressions

```javascript
if (!(someFunc(%var)))
```

**Bytecode:**
```
OP_PUSHFRAME
[push arguments]
OP_CALLFUNC <func_name>
→ result on strStack
OP_STR_TO_UINT        // 0x3C - Convert to bool
OP_NOT                // 0x18 - Negate
→ result on intStack
OP_JMPIFNOT <end_if>
[if body]
<end_if>:
```

#### 6. Variable Loading

**Load string variable:**
```
OP_SETCURVAR <var_name>       // 0x24
OP_LOADVAR_STR                // 0x2E
→ value on strStack
```

**Load uint variable:**
```
OP_SETCURVAR <var_name>
OP_LOADVAR_UINT               // 0x2C
→ value on intStack
```

**Load float variable:**
```
OP_SETCURVAR <var_name>
OP_LOADVAR_FLT                // 0x2D
→ value on fltStack
```

#### 7. Arrays

**Set array element:**
```javascript
%array[%index] = value;
```

**Bytecode:**
```
[evaluate value] → strStack
[evaluate index] → intStack/strStack
OP_SETCURVAR_ARRAY <array_name>  // 0x28
OP_SAVEVAR_STR                   // 0x31
```

**Get array element:**
```javascript
%val = %array[%index];
```

**Bytecode:**
```
[evaluate index] → intStack/strStack
OP_SETCURVAR_ARRAY <array_name>
OP_LOADVAR_STR
→ value on strStack
```

### Implementation Priority

**Phase 1: Expression Parser** (CRITICAL)
- Tokenizer/Lexer
- Expression parser with precedence
- Convert expressions to AST

**Phase 2: Control Flow** (HIGH)
- If/else statements
- While loops
- Jump label management

**Phase 3: Operators** (HIGH)
- Logical: !, &&, ||
- Comparison: ==, !=, <, >, <=, >=
- Math: +, -, *, /, %

**Phase 4: Arrays** (MEDIUM)
- Array indexing
- Array assignment

**Phase 5: Advanced** (LOW)
- For loops
- Switch statements
- Break/continue

### Critical Implementation Details

#### Jump Target Calculation

When emitting jumps:
1. Emit placeholder (0x00)
2. Store label name and placeholder index
3. After all code emitted, patch placeholders with actual code indices
4. **IMPORTANT**: Target is CODE INDEX, not byte offset!

#### Extended Codes for Jumps

If jump target > 255:
```
Instead of: [OP_JMPIFNOT] [target_byte]
Emit:       [OP_JMPIFNOT] [0xFF] [high_byte] [low_byte]
```

But this requires careful handling to not break subsequent code indices!

#### Stack Management

The VM uses multiple stacks:
- **intStack**: Integers, booleans
- **fltStack**: Floats
- **strStack**: Strings
- **binStack**: Binary operators (for complex expressions)

Know which stack each operation uses!

### Test Case: Complex If Statement

```javascript
if (!(stxaomnhgdn(%stxlpjnmnhi))) {
    %stxlpjnmnhi = new stxilbjjlhp(Name : "gMovieActionMap");
}
```

**Required Bytecode:**
```
// Evaluate condition: !(stxaomnhgdn(%stxlpjnmnhi))

// Push argument
OP_PUSHFRAME
OP_SETCURVAR <stxlpjnmnhi>
OP_LOADVAR_STR
OP_PUSH

// Call function
OP_CALLFUNC <stxaomnhgdn>
[namespace: 0x0000]
[call_type: 0x00]
→ result on strStack

// Convert to bool and negate
OP_STR_TO_UINT      // strStack → intStack
OP_NOT              // Negate
→ condition on intStack

// Jump if false
OP_JMPIFNOT <end_if>

// Then body: object creation
[... object creation bytecode ...]

<end_if>:
```

### Next Steps

1. **Build proper expression parser**
2. **Implement jump label system**
3. **Add all comparison/logical operators**
4. **Test with actual Scarface scripts**

The foundation (V11) works. Now we need to add expression parsing and control flow!

---

*Based on analysis of:*
- BrokenFace decompiler (codec.py)
- CodeBlock.h/cpp from Scarface
- Actual Scarface CSO files*
