// Test all V14 features

function testIfElse() {
    if (checkCondition()) {
        %result = "then";
    } else {
        %result = "else";
    }
    return;
}

function testWhile() {
    %counter = "0";
    while (isRunning()) {
        doSomething();
        %counter = "1";
    }
    return;
}

function testComparisons() {
    if (%a == %b) {
        equal();
    }
    if (%a != %b) {
        notEqual();
    }
    if (%a < %b) {
        lessThan();
    }
    return;
}

function testLogical() {
    if (%a && %b) {
        bothTrue();
    }
    if (%a || %b) {
        oneTrue();
    }
    return;
}
