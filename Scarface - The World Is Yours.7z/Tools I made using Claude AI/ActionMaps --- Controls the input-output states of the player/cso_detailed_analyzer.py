#!/usr/bin/env python3
"""
Detailed CSO Binary Analysis Tool
Analyzes existing CSO file to understand exact format by comparing with decompiled source
"""

import struct
import sys


def analyze_cso_detailed(cso_path, cs_path):
    """Analyze CSO binary structure in detail"""
    
    with open(cso_path, 'rb') as f:
        data = f.read()
    
    with open(cs_path, 'r') as f:
        source = f.read()
    
    print("=" * 100)
    print("DETAILED CSO BINARY ANALYSIS")
    print("=" * 100)
    print(f"CSO File: {cso_path} ({len(data)} bytes)")
    print(f"Source File: {cs_path}")
    print()
    
    offset = 0
    
    # ===== HEADER =====
    print("### HEADER ###")
    version = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    print(f"[0x0000] Version: {version}")
    
    # ===== GLOBAL STRING TABLE =====
    global_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    print(f"[0x0004] Global String Table Size: {global_str_size} bytes (0x{global_str_size:X})")
    
    print(f"\n### GLOBAL STRING TABLE [0x{offset:04X} - 0x{offset + global_str_size:04X}] ###")
    global_strings = {}
    global_str_start = offset
    while offset < global_str_start + global_str_size:
        str_offset_in_table = offset - global_str_start
        null_pos = data.find(b'\x00', offset)
        if null_pos == -1 or null_pos >= global_str_start + global_str_size:
            break
        string = data[offset:null_pos].decode('ascii', errors='replace')
        if string:
            global_strings[str_offset_in_table] = string
            print(f"  [0x{str_offset_in_table:04X}] '{string}'")
        offset = null_pos + 1
    
    # Align to global string table end
    offset = global_str_start + global_str_size
    
    # ===== FUNCTION STRING TABLE =====
    marker = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    print(f"\n### FUNCTION STRING TABLE [0x{offset:04X} - 0x{offset + func_str_size:04X}] ###")
    print(f"Marker: 0x{marker:08X}")
    print(f"Function String Table Size: {func_str_size} bytes (0x{func_str_size:X})")
    
    function_strings = {}
    func_str_start = offset
    while offset < func_str_start + func_str_size:
        str_offset_in_table = offset - func_str_start
        null_pos = data.find(b'\x00', offset)
        if null_pos == -1 or null_pos >= func_str_start + func_str_size:
            break
        string = data[offset:null_pos].decode('ascii', errors='replace')
        if string:
            function_strings[str_offset_in_table] = string
            if len(function_strings) <= 100:  # Limit output
                print(f"  [0x{str_offset_in_table:04X}] '{string}'")
        offset = null_pos + 1
    
    if len(function_strings) > 100:
        print(f"  ... ({len(function_strings) - 100} more strings)")
    
    # Align to function string table end
    offset = func_str_start + func_str_size
    
    # ===== CODE SECTION =====
    print(f"\n### CODE SECTION [0x{offset:04X}] ###")
    code_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    print(f"Code Size Field: {code_size} DWORDs")
    
    # The actual bytecode follows here
    print(f"\nBytecode starts at: 0x{offset:04X}")
    print(f"Remaining bytes: {len(data) - offset}")
    
    # Let's dump the actual structure as a series of uint32 values
    print(f"\n### RAW BYTECODE DUMP (First 200 DWORDs) ###")
    for i in range(min(200, (len(data) - offset) // 4)):
        value = struct.unpack_from('<I', data, offset + i * 4)[0]
        
        # Try to interpret the value
        interpretation = ""
        if value in global_strings:
            interpretation = f" -> GlobalStr: '{global_strings[value]}'"
        elif value in function_strings:
            interpretation = f" -> FuncStr: '{function_strings[value]}'"
        elif value < 100:  # Likely an opcode or small constant
            interpretation = f" -> Likely opcode/const"
        
        print(f"  [{i:4d}] 0x{offset + i*4:04X}: 0x{value:08X} = {value:10d}{interpretation}")
    
    print("\n" + "=" * 100)
    
    # Now let's try to understand the actual structure
    print("\n### STRUCTURE INTERPRETATION ###")
    print("\nThe CSO file appears to have this structure:")
    print("1. uint32: Version (1)")
    print("2. uint32: Global string table size")
    print("3. [bytes]: Global string table (null-terminated strings)")
    print("4. uint32: Marker (0)")
    print("5. uint32: Function string table size")
    print("6. [bytes]: Function string table (null-terminated strings)")
    print("7. uint32: Code size (appears to be 0 in this file)")
    print("8. [bytes]: Actual bytecode/data")
    
    print("\nNote: The 'Code size' being 0 suggests the actual format may differ from")
    print("the CodeBlock.h structure, or there's additional metadata we're missing.")


if __name__ == "__main__":
    analyze_cso_detailed(
        '/mnt/user-data/uploads/actionmaps_Win32.cso',
        '/mnt/user-data/uploads/actionmaps_Win32_cso.cs'
    )
