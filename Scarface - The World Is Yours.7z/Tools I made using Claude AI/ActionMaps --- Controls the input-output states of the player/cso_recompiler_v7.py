#!/usr/bin/env python3
"""
CSO Recompiler V7 - FULL TorqueScript Compiler
Implements complete language features for actionmaps compilation

Features:
- Variable assignments
- Object creation with properties
- Method calls
- Function calls
- If/else statements
- Return with values
- Complex expressions

Usage: python3 cso_recompiler_v7.py input.cs output.cso
"""

import sys
import struct
import re
import json
from typing import List, Dict, Tuple, Optional
from pathlib import Path

# Opcodes from decompiler
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFFNOT = 0x06
OP_JMPIFNOT = 0x07
OP_JMPIFF = 0x08
OP_JMPIF = 0x09
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_CMPEQ = 0x0E
OP_NOT = 0x18
OP_NOTF = 0x19
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_UINT = 0x2C
OP_LOADVAR_FLT = 0x2D
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_UINT = 0x2F
OP_SAVEVAR_FLT = 0x30
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCUROBJECT_NEW = 0x33
OP_SETCURFIELD = 0x34
OP_SETCURFIELD_ARRAY = 0x35
OP_LOADFIELD_UINT = 0x36
OP_LOADFIELD_FLT = 0x37
OP_LOADFIELD_STR = 0x38
OP_SAVEFIELD_UINT = 0x39
OP_SAVEFIELD_FLT = 0x3A
OP_SAVEFIELD_STR = 0x3B
OP_STR_TO_UINT = 0x3C
OP_STR_TO_FLT = 0x3D
OP_STR_TO_NONE = 0x3E
OP_FLT_TO_UINT = 0x3F
OP_FLT_TO_STR = 0x40
OP_FLT_TO_NONE = 0x41
OP_UINT_TO_FLT = 0x42
OP_UINT_TO_STR = 0x43
OP_UINT_TO_NONE = 0x44
OP_LOADIMMED_UINT = 0x45
OP_LOADIMMED_FLT = 0x46
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_ADVANCE_STR = 0x4D
OP_ADVANCE_STR_APPENDCHAR = 0x4E
OP_ADVANCE_STR_COMMA = 0x4F
OP_ADVANCE_STR_NUL = 0x50
OP_REWIND_STR = 0x51
OP_TERMINATE_REWIND_STR = 0x52
OP_COMPARE_STR = 0x53
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        """Add string and return its offset"""
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class CodeBuilder:
    """Builds bytecode as CODES (not raw bytes)"""
    
    def __init__(self):
        self.codes = []  # List of code values
        self.string_refs = []  # List of (code_index, offset) for IdentTable
        self.labels = {}  # name -> code_index
        self.fixups = []  # (code_index, label_name) for patching jumps
    
    def emit(self, code: int):
        """Emit a single code"""
        self.codes.append(code)
    
    def emit_u16be(self, value: int, is_string_ref=False, string_offset=None):
        """Emit 16-bit big-endian value as 2 codes"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        
        if is_string_ref and string_offset is not None:
            code_idx = len(self.codes)
            self.string_refs.append((code_idx, string_offset))
        
        self.codes.append(high)
        self.codes.append(low)
    
    def get_code_index(self) -> int:
        """Get current code index"""
        return len(self.codes)
    
    def set_label(self, name: str):
        """Mark current position with a label"""
        self.labels[name] = len(self.codes)
    
    def emit_jump(self, opcode: int, label: str):
        """Emit a jump instruction (will be patched later)"""
        self.emit(opcode)
        fixup_idx = len(self.codes)
        self.emit(0)  # Placeholder for jump target
        self.fixups.append((fixup_idx, label))
    
    def patch_jumps(self):
        """Patch all jump targets"""
        for code_idx, label in self.fixups:
            if label not in self.labels:
                raise CompileError(f"Undefined label: {label}")
            target = self.labels[label]
            self.codes[code_idx] = target & 0xFF
    
    def to_bytes(self) -> bytes:
        """Convert codes to compressed bytecode format"""
        output = bytearray()
        
        for code in self.codes:
            if code > 0xFF:
                output.append(EXT_CTRL_CODE)
                output.append((code >> 8) & 0xFF)
                output.append(code & 0xFF)
            else:
                output.append(code & 0xFF)
        
        return bytes(output)


class IdentTable:
    """Tracks string references for patching"""
    
    def __init__(self):
        self.entries = {}  # offset -> list of code indices
    
    def add(self, string_offset: int, code_index: int):
        """Record that string at offset is referenced at code_index"""
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        output = bytearray()
        
        # Entry count
        output.extend(struct.pack('<I', len(self.entries)))
        
        # Each entry
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            
            # Offset (2 bytes LE)
            output.extend(struct.pack('<H', offset & 0xFFFF))
            
            # Padding (2 bytes)
            output.extend(b'\x00\x00')
            
            # Count
            output.extend(struct.pack('<I', len(indices)))
            
            # Indices
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        
        return bytes(output)


class CompileError(Exception):
    pass


class Expression:
    """Represents an expression in the AST"""
    pass

class StringLiteral(Expression):
    def __init__(self, value: str):
        self.value = value

class IntLiteral(Expression):
    def __init__(self, value: int):
        self.value = value

class Variable(Expression):
    def __init__(self, name: str):
        self.name = name

class FunctionCall(Expression):
    def __init__(self, name: str, args: List[Expression]):
        self.name = name
        self.args = args

class MethodCall(Expression):
    def __init__(self, obj: Expression, method: str, args: List[Expression]):
        self.obj = obj
        self.method = method
        self.args = args

class ObjectCreation(Expression):
    def __init__(self, class_name: str, properties: Dict[str, Expression], init_block: Optional[Dict[str, str]] = None):
        self.class_name = class_name
        self.properties = properties
        self.init_block = init_block


class Statement:
    """Base class for statements"""
    pass

class ReturnStatement(Statement):
    def __init__(self, value: Optional[Expression] = None):
        self.value = value

class Assignment(Statement):
    def __init__(self, var_name: str, value: Expression):
        self.var_name = var_name
        self.value = value

class ExpressionStatement(Statement):
    def __init__(self, expr: Expression):
        self.expr = expr

class IfStatement(Statement):
    def __init__(self, condition: Expression, then_block: List[Statement], else_block: Optional[List[Statement]] = None):
        self.condition = condition
        self.then_block = then_block
        self.else_block = else_block


class Parser:
    """Parse TorqueScript source into AST"""
    
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
    
    def parse(self) -> List[Tuple[str, List[str], List[Statement]]]:
        """Returns list of (name, params, statements)"""
        functions = []
        
        while self.pos < len(self.source):
            self.skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                break
            
            if self.peek_keyword('function'):
                func = self.parse_function()
                if func:
                    functions.append(func)
            else:
                self.pos += 1
        
        return functions
    
    def skip_whitespace_and_comments(self):
        """Skip whitespace and comments"""
        while self.pos < len(self.source):
            # Skip whitespace
            while self.pos < len(self.source) and self.source[self.pos] in ' \t\n\r':
                self.pos += 1
            
            # Skip // comments
            if self.pos < len(self.source) - 1 and self.source[self.pos:self.pos+2] == '//':
                while self.pos < len(self.source) and self.source[self.pos] != '\n':
                    self.pos += 1
                continue
            
            # Skip /* */ comments
            if self.pos < len(self.source) - 1 and self.source[self.pos:self.pos+2] == '/*':
                self.pos += 2
                while self.pos < len(self.source) - 1:
                    if self.source[self.pos:self.pos+2] == '*/':
                        self.pos += 2
                        break
                    self.pos += 1
                continue
            
            break
    
    def peek_keyword(self, keyword: str) -> bool:
        """Check if keyword is at current position"""
        self.skip_whitespace_and_comments()
        return self.source[self.pos:self.pos+len(keyword)] == keyword
    
    def consume_keyword(self, keyword: str) -> bool:
        """Consume keyword if present"""
        if self.peek_keyword(keyword):
            self.pos += len(keyword)
            return True
        return False
    
    def parse_identifier(self) -> Optional[str]:
        """Parse an identifier"""
        self.skip_whitespace_and_comments()
        start = self.pos
        
        # Identifier can start with letter, underscore, or % (for variables)
        if self.pos < len(self.source) and (self.source[self.pos].isalpha() or self.source[self.pos] in '_%'):
            self.pos += 1
            while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] in '_'):
                self.pos += 1
            return self.source[start:self.pos]
        
        return None
    
    def parse_function(self) -> Optional[Tuple[str, List[str], List[Statement]]]:
        """Parse a function definition"""
        if not self.consume_keyword('function'):
            return None
        
        # Function name
        name = self.parse_identifier()
        if not name:
            return None
        
        # Parameters
        self.skip_whitespace_and_comments()
        if self.pos >= len(self.source) or self.source[self.pos] != '(':
            return None
        
        self.pos += 1  # Skip '('
        params = []
        
        while True:
            self.skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                return None
            
            if self.source[self.pos] == ')':
                self.pos += 1
                break
            
            param = self.parse_identifier()
            if param:
                params.append(param)
            
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == ',':
                self.pos += 1
        
        # Function body
        self.skip_whitespace_and_comments()
        if self.pos >= len(self.source) or self.source[self.pos] != '{':
            return None
        
        self.pos += 1  # Skip '{'
        
        statements = self.parse_block()
        
        self.skip_whitespace_and_comments()
        if self.pos < len(self.source) and self.source[self.pos] == '}':
            self.pos += 1
        
        return (name, params, statements)
    
    def parse_block(self) -> List[Statement]:
        """Parse a block of statements"""
        statements = []
        
        while True:
            self.skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                break
            
            if self.source[self.pos] == '}':
                break
            
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            else:
                # Skip unknown character
                self.pos += 1
        
        return statements
    
    def parse_statement(self) -> Optional[Statement]:
        """Parse a single statement"""
        self.skip_whitespace_and_comments()
        
        if self.pos >= len(self.source):
            return None
        
        # Return statement
        if self.peek_keyword('return'):
            return self.parse_return()
        
        # If statement
        if self.peek_keyword('if'):
            return self.parse_if()
        
        # Try to parse as expression or assignment
        return self.parse_expression_or_assignment()
    
    def parse_return(self) -> Optional[ReturnStatement]:
        """Parse return statement"""
        if not self.consume_keyword('return'):
            return None
        
        self.skip_whitespace_and_comments()
        
        # Check for semicolon (empty return)
        if self.pos < len(self.source) and self.source[self.pos] == ';':
            self.pos += 1
            return ReturnStatement()
        
        # Parse return value
        value = self.parse_expression()
        
        self.skip_whitespace_and_comments()
        if self.pos < len(self.source) and self.source[self.pos] == ';':
            self.pos += 1
        
        return ReturnStatement(value)
    
    def parse_if(self) -> Optional[IfStatement]:
        """Parse if statement"""
        if not self.consume_keyword('if'):
            return None
        
        self.skip_whitespace_and_comments()
        if self.pos >= len(self.source) or self.source[self.pos] != '(':
            return None
        
        self.pos += 1  # Skip '('
        
        condition = self.parse_expression()
        
        self.skip_whitespace_and_comments()
        if self.pos >= len(self.source) or self.source[self.pos] != ')':
            return None
        
        self.pos += 1  # Skip ')'
        
        # Then block
        self.skip_whitespace_and_comments()
        if self.pos >= len(self.source) or self.source[self.pos] != '{':
            return None
        
        self.pos += 1  # Skip '{'
        then_block = self.parse_block()
        
        self.skip_whitespace_and_comments()
        if self.pos < len(self.source) and self.source[self.pos] == '}':
            self.pos += 1
        
        # Else block (optional)
        else_block = None
        self.skip_whitespace_and_comments()
        if self.peek_keyword('else'):
            self.consume_keyword('else')
            self.skip_whitespace_and_comments()
            
            if self.pos < len(self.source) and self.source[self.pos] == '{':
                self.pos += 1
                else_block = self.parse_block()
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == '}':
                    self.pos += 1
        
        return IfStatement(condition, then_block, else_block)
    
    def parse_expression_or_assignment(self) -> Optional[Statement]:
        """Parse expression or assignment"""
        # Save position in case we need to backtrack
        saved_pos = self.pos
        
        # Try to parse as assignment
        var = self.parse_identifier()
        if var and var.startswith('%'):
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == '=':
                self.pos += 1  # Skip '='
                value = self.parse_expression()
                
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == ';':
                    self.pos += 1
                
                return Assignment(var, value)
        
        # Not an assignment, restore and parse as expression
        self.pos = saved_pos
        expr = self.parse_expression()
        
        if expr:
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == ';':
                self.pos += 1
            return ExpressionStatement(expr)
        
        return None
    
    def parse_expression(self) -> Optional[Expression]:
        """Parse an expression"""
        self.skip_whitespace_and_comments()
        
        if self.pos >= len(self.source):
            return None
        
        # String literal
        if self.source[self.pos] == '"':
            return self.parse_string_literal()
        
        # Number literal
        if self.source[self.pos].isdigit():
            return self.parse_number()
        
        # Variable or function call
        if self.source[self.pos].isalpha() or self.source[self.pos] in '_%':
            return self.parse_identifier_expression()
        
        # Object creation
        if self.peek_keyword('new'):
            return self.parse_object_creation()
        
        # Negation
        if self.source[self.pos] == '!':
            self.pos += 1
            expr = self.parse_expression()
            # For now, just return the inner expression
            # TODO: Create proper negation expression
            return expr
        
        # Parenthesized expression
        if self.source[self.pos] == '(':
            self.pos += 1
            expr = self.parse_expression()
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == ')':
                self.pos += 1
            return expr
        
        return None
    
    def parse_string_literal(self) -> Optional[StringLiteral]:
        """Parse a string literal"""
        if self.pos >= len(self.source) or self.source[self.pos] != '"':
            return None
        
        self.pos += 1  # Skip opening quote
        start = self.pos
        
        while self.pos < len(self.source) and self.source[self.pos] != '"':
            if self.source[self.pos] == '\\':
                self.pos += 2  # Skip escape sequence
            else:
                self.pos += 1
        
        value = self.source[start:self.pos]
        
        if self.pos < len(self.source):
            self.pos += 1  # Skip closing quote
        
        return StringLiteral(value)
    
    def parse_number(self) -> Optional[IntLiteral]:
        """Parse a number literal"""
        start = self.pos
        
        while self.pos < len(self.source) and self.source[self.pos].isdigit():
            self.pos += 1
        
        return IntLiteral(int(self.source[start:self.pos]))
    
    def parse_identifier_expression(self) -> Optional[Expression]:
        """Parse identifier, function call, or method call"""
        ident = self.parse_identifier()
        if not ident:
            return None
        
        self.skip_whitespace_and_comments()
        
        # Method call: %obj.method()
        if self.pos < len(self.source) and self.source[self.pos] == '.':
            self.pos += 1
            method = self.parse_identifier()
            if method:
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == '(':
                    self.pos += 1
                    args = self.parse_argument_list()
                    self.skip_whitespace_and_comments()
                    if self.pos < len(self.source) and self.source[self.pos] == ')':
                        self.pos += 1
                    return MethodCall(Variable(ident), method, args)
        
        # Function call: func()
        if self.pos < len(self.source) and self.source[self.pos] == '(':
            self.pos += 1
            args = self.parse_argument_list()
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == ')':
                self.pos += 1
            return FunctionCall(ident, args)
        
        # Just a variable
        return Variable(ident)
    
    def parse_argument_list(self) -> List[Expression]:
        """Parse a comma-separated list of arguments"""
        args = []
        
        while True:
            self.skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                break
            
            if self.source[self.pos] == ')':
                break
            
            arg = self.parse_expression()
            if arg:
                args.append(arg)
            
            self.skip_whitespace_and_comments()
            if self.pos < len(self.source) and self.source[self.pos] == ',':
                self.pos += 1
            else:
                break
        
        return args
    
    def parse_object_creation(self) -> Optional[ObjectCreation]:
        """Parse object creation: new ClassName(prop : val)"""
        if not self.consume_keyword('new'):
            return None
        
        class_name = self.parse_identifier()
        if not class_name:
            return None
        
        properties = {}
        init_block = None
        
        self.skip_whitespace_and_comments()
        if self.pos < len(self.source) and self.source[self.pos] == '(':
            self.pos += 1
            
            # Parse property list: Name : "value"
            while True:
                self.skip_whitespace_and_comments()
                if self.pos >= len(self.source) or self.source[self.pos] == ')':
                    break
                
                prop_name = self.parse_identifier()
                if not prop_name:
                    break
                
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == ':':
                    self.pos += 1
                    prop_value = self.parse_expression()
                    if prop_value:
                        properties[prop_name] = prop_value
                
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == ',':
                    self.pos += 1
            
            if self.pos < len(self.source) and self.source[self.pos] == ')':
                self.pos += 1
        
        # Check for initialization block: { property = "value"; }
        self.skip_whitespace_and_comments()
        if self.pos < len(self.source) and self.source[self.pos] == '{':
            self.pos += 1
            init_block = {}
            
            while True:
                self.skip_whitespace_and_comments()
                if self.pos >= len(self.source) or self.source[self.pos] == '}':
                    break
                
                prop_name = self.parse_identifier()
                if not prop_name:
                    break
                
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == '=':
                    self.pos += 1
                    # For now, just store as string
                    self.skip_whitespace_and_comments()
                    start = self.pos
                    while self.pos < len(self.source) and self.source[self.pos] not in ';\n}':
                        self.pos += 1
                    prop_value = self.source[start:self.pos].strip().strip('"')
                    init_block[prop_name] = prop_value
                
                self.skip_whitespace_and_comments()
                if self.pos < len(self.source) and self.source[self.pos] == ';':
                    self.pos += 1
            
            if self.pos < len(self.source) and self.source[self.pos] == '}':
                self.pos += 1
        
        return ObjectCreation(class_name, properties, init_block)


class CodeGenerator:
    """Generate bytecode from AST"""
    
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.bytecode = CodeBuilder()
        self.ident_table = IdentTable()
        self.label_counter = 0
    
    def generate_label(self) -> str:
        """Generate a unique label"""
        label = f"L{self.label_counter}"
        self.label_counter += 1
        return label
    
    def compile_function(self, name: str, params: List[str], statements: List[Statement]):
        """Compile a function"""
        # OP_FUNC_DECL
        self.bytecode.emit(OP_FUNC_DECL)
        
        # Function name
        name_offset = self.global_strings.add(name)
        self.bytecode.emit_u16be(name_offset, is_string_ref=True, string_offset=name_offset)
        
        # Namespace (empty)
        ns_offset = self.global_strings.add("")
        self.bytecode.emit_u16be(ns_offset, is_string_ref=True, string_offset=ns_offset)
        
        # Package (empty)
        pkg_offset = self.global_strings.add("")
        self.bytecode.emit_u16be(pkg_offset, is_string_ref=True, string_offset=pkg_offset)
        
        # Has body
        self.bytecode.emit(0x01)
        
        # End IP (will patch later)
        end_ip_idx = self.bytecode.get_code_index()
        self.bytecode.emit(0)
        
        # Argc
        argc = len(params)
        self.bytecode.emit(argc)
        
        # Parameter names
        for param in params:
            param = param.lstrip('%')
            param_offset = self.global_strings.add(param)
            self.bytecode.emit_u16be(param_offset, is_string_ref=True, string_offset=param_offset)
        
        # Compile body
        for stmt in statements:
            self.compile_statement(stmt)
        
        # Patch end IP
        end_ip = self.bytecode.get_code_index()
        self.bytecode.codes[end_ip_idx] = end_ip & 0xFF
        
        # Emit return if not already present
        # (Most functions end with explicit return)
    
    def compile_statement(self, stmt: Statement):
        """Compile a statement"""
        if isinstance(stmt, ReturnStatement):
            self.compile_return(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ExpressionStatement):
            self.compile_expression_statement(stmt)
        elif isinstance(stmt, IfStatement):
            self.compile_if(stmt)
    
    def compile_return(self, stmt: ReturnStatement):
        """Compile return statement"""
        if stmt.value:
            # Return with value
            self.compile_expression(stmt.value)
            # Value is now on string stack
        
        self.bytecode.emit(OP_RETURN)
    
    def compile_assignment(self, stmt: Assignment):
        """Compile variable assignment: %var = expr"""
        # Compile expression (leaves result on stack)
        self.compile_expression(stmt.value)
        
        # Set current variable
        var_name = stmt.var_name.lstrip('%')
        var_offset = self.global_strings.add(var_name)
        self.bytecode.emit(OP_SETCURVAR_CREATE)
        self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
        
        # Save to variable (string type)
        self.bytecode.emit(OP_SAVEVAR_STR)
    
    def compile_expression_statement(self, stmt: ExpressionStatement):
        """Compile an expression as a statement"""
        self.compile_expression(stmt.expr)
    
    def compile_if(self, stmt: IfStatement):
        """Compile if statement"""
        # Compile condition
        self.compile_expression(stmt.condition)
        
        # Jump if false
        else_label = self.generate_label()
        end_label = self.generate_label()
        
        if stmt.else_block:
            self.bytecode.emit_jump(OP_JMPIFNOT, else_label)
        else:
            self.bytecode.emit_jump(OP_JMPIFNOT, end_label)
        
        # Then block
        for s in stmt.then_block:
            self.compile_statement(s)
        
        if stmt.else_block:
            # Jump over else block
            self.bytecode.emit_jump(OP_JMP, end_label)
            
            # Else block
            self.bytecode.set_label(else_label)
            for s in stmt.else_block:
                self.compile_statement(s)
        
        self.bytecode.set_label(end_label)
    
    def compile_expression(self, expr: Expression):
        """Compile an expression (leaves result on string stack)"""
        if isinstance(expr, StringLiteral):
            self.compile_string_literal(expr)
        elif isinstance(expr, IntLiteral):
            self.compile_int_literal(expr)
        elif isinstance(expr, Variable):
            self.compile_variable(expr)
        elif isinstance(expr, FunctionCall):
            self.compile_function_call(expr)
        elif isinstance(expr, MethodCall):
            self.compile_method_call(expr)
        elif isinstance(expr, ObjectCreation):
            self.compile_object_creation(expr)
    
    def compile_string_literal(self, expr: StringLiteral):
        """Compile string literal"""
        str_offset = self.func_strings.add(expr.value)
        self.bytecode.emit(OP_LOADIMMED_STR)
        self.bytecode.emit_u16be(str_offset, is_string_ref=True, string_offset=str_offset)
    
    def compile_int_literal(self, expr: IntLiteral):
        """Compile integer literal"""
        self.bytecode.emit(OP_LOADIMMED_UINT)
        self.bytecode.emit_u16be(expr.value)
    
    def compile_variable(self, expr: Variable):
        """Compile variable reference"""
        var_name = expr.name.lstrip('%')
        var_offset = self.global_strings.add(var_name)
        
        # Set current variable
        self.bytecode.emit(OP_SETCURVAR)
        self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
        
        # Load variable value (assume string type)
        self.bytecode.emit(OP_LOADVAR_STR)
    
    def compile_function_call(self, expr: FunctionCall):
        """Compile function call"""
        # Push frame for arguments
        self.bytecode.emit(OP_PUSHFRAME)
        
        # Compile arguments
        for arg in expr.args:
            self.compile_expression(arg)
            self.bytecode.emit(OP_PUSH)
        
        # Call function
        func_offset = self.global_strings.add(expr.name)
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_u16be(func_offset, is_string_ref=True, string_offset=func_offset)
        self.bytecode.emit_u16be(0)  # No namespace
        self.bytecode.emit(0x00)  # Function call (not method)
    
    def compile_method_call(self, expr: MethodCall):
        """Compile method call: %obj.method()"""
        # Set current variable to object
        if isinstance(expr.obj, Variable):
            var_name = expr.obj.name.lstrip('%')
            var_offset = self.global_strings.add(var_name)
            self.bytecode.emit(OP_SETCURVAR)
            self.bytecode.emit_u16be(var_offset, is_string_ref=True, string_offset=var_offset)
        
        # Set current object
        self.bytecode.emit(OP_SETCUROBJECT)
        
        # Push frame for arguments
        self.bytecode.emit(OP_PUSHFRAME)
        
        # Compile arguments
        for arg in expr.args:
            self.compile_expression(arg)
            self.bytecode.emit(OP_PUSH)
        
        # Call method
        method_offset = self.global_strings.add(expr.method)
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_u16be(method_offset, is_string_ref=True, string_offset=method_offset)
        self.bytecode.emit_u16be(0)  # No namespace
        self.bytecode.emit(0x01)  # Method call
    
    def compile_object_creation(self, expr: ObjectCreation):
        """Compile object creation"""
        # Push frame for constructor arguments
        self.bytecode.emit(OP_PUSHFRAME)
        
        # Compile property arguments (Name : "value")
        for prop_name, prop_value in expr.properties.items():
            # Load property name as identifier
            prop_offset = self.global_strings.add(prop_name)
            self.bytecode.emit(OP_LOADIMMED_IDENT)
            self.bytecode.emit_u16be(prop_offset, is_string_ref=True, string_offset=prop_offset)
            self.bytecode.emit(OP_PUSH)
            
            # Load property value
            self.compile_expression(prop_value)
            self.bytecode.emit(OP_PUSH)
        
        # Create object
        class_offset = self.global_strings.add(expr.class_name)
        self.bytecode.emit(OP_CREATE_OBJECT)
        self.bytecode.emit_u16be(class_offset, is_string_ref=True, string_offset=class_offset)
        self.bytecode.emit(0x00)  # Mystery byte
        
        # End IP for object (will be patched if needed)
        # For now, just point to next instruction
        end_ip = self.bytecode.get_code_index() + 1
        self.bytecode.emit(end_ip & 0xFF)
        
        # Add object
        self.bytecode.emit(OP_ADD_OBJECT)
        self.bytecode.emit(0x01)  # place_at_root
        
        # Handle initialization block
        if expr.init_block:
            # Set current object to newly created one
            self.bytecode.emit(OP_SETCUROBJECT_NEW)
            
            # Set each property
            for prop_name, prop_value in expr.init_block.items():
                prop_offset = self.global_strings.add(prop_name)
                self.bytecode.emit(OP_SETCURFIELD)
                self.bytecode.emit_u16be(prop_offset, is_string_ref=True, string_offset=prop_offset)
                
                # Load value
                val_offset = self.func_strings.add(prop_value)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_u16be(val_offset, is_string_ref=True, string_offset=val_offset)
                
                # Save to field
                self.bytecode.emit(OP_SAVEFIELD_STR)
        
        # End object
        self.bytecode.emit(OP_END_OBJECT)
        self.bytecode.emit(0x01)  # place_at_root


class CSOCompiler:
    """Main compiler"""
    
    def __init__(self):
        self.codegen = CodeGenerator()
    
    def compile(self, source: str) -> bytes:
        """Compile source to CSO binary"""
        # Parse
        parser = Parser(source)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions:")
        for name, params, stmts in functions:
            param_str = ", ".join(params) if params else ""
            print(f"  - {name}({param_str}) - {len(stmts)} statements")
        
        # Generate code
        for name, params, statements in functions:
            self.codegen.compile_function(name, params, statements)
        
        # Patch jumps
        self.codegen.bytecode.patch_jumps()
        
        # Build IdentTable
        for code_idx, string_offset in self.codegen.bytecode.string_refs:
            self.codegen.ident_table.add(string_offset, code_idx)
        
        return self.build_cso()
    
    def build_cso(self) -> bytes:
        """Build final CSO binary"""
        output = bytearray()
        
        # Version
        output.extend(struct.pack('<I', 1))
        
        # Global String Table
        gst_bytes = self.codegen.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(gst_bytes)))
        output.extend(gst_bytes)
        
        # Global Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # Function String Table
        fst_bytes = self.codegen.func_strings.to_bytes()
        output.extend(struct.pack('<I', len(fst_bytes)))
        output.extend(fst_bytes)
        
        # Function Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # Bytecode
        bc_bytes = self.codegen.bytecode.to_bytes()
        code_count = len(self.codegen.bytecode.codes)
        output.extend(struct.pack('<I', code_count))
        output.extend(bc_bytes)
        
        # IdentTable
        ident_bytes = self.codegen.ident_table.to_bytes()
        output.extend(ident_bytes)
        
        return bytes(output)


def main():
    if len(sys.argv) != 3:
        print("CSO Recompiler V7 - Full TorqueScript Compiler")
        print()
        print("Usage: python3 cso_recompiler_v7.py input.cs output.cso")
        print()
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    print(f"Compiling {input_file}...\n")
    
    try:
        with open(input_file, 'r') as f:
            source = f.read()
        
        compiler = CSOCompiler()
        cso_data = compiler.compile(source)
        
        with open(output_file, 'wb') as f:
            f.write(cso_data)
        
        print(f"\n✓ Compilation complete!")
        print(f"Output: {output_file}")
        print(f"Size: {len(cso_data)} bytes")
        print(f"Global strings: {len(compiler.codegen.global_strings.strings)}")
        print(f"Function strings: {len(compiler.codegen.func_strings.strings)}")
        print(f"Bytecode codes: {len(compiler.codegen.bytecode.codes)}")
        print(f"IdentTable entries: {len(compiler.codegen.ident_table.entries)}")
        
    except Exception as e:
        print(f"\n✗ Compilation failed!")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
