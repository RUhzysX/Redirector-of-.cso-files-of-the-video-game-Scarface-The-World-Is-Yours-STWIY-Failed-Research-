#!/usr/bin/env python3
"""
Minimal CSO Compiler - Attempts to exactly replicate ActionMaps binary structure
This version focuses on getting the EXACT binary layout correct
"""

import struct
import sys

# After extensive analysis, the CSO format is:
# 1. uint32: version (1)
# 2. uint32: global_string_size
# 3. bytes: global_string_table (null-terminated strings)
# 4. uint32: marker (0)
# 5. uint32: function_string_size
# 6. bytes: function_string_table (null-terminated strings)
# 7. uint32: code_size_field (0)
# 8. uint32: actual_bytecode_size_in_bytes
# 9. bytes: bytecode (actual_bytecode_size_in_bytes)
# 10. bytes: linebreak_data (remaining to end)

# THE KEY PROBLEM: The bytecode contains values that don't match string offsets
# These appear to be HASHES or POINTERS from the original compilation

# Let me try to extract the EXACT bytecode from the original and reuse it

def extract_original_structure(original_path):
    """Extract all sections from original CSO"""
    with open(original_path, 'rb') as f:
        data = f.read()
    
    offset = 0
    
    # Version
    version = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    
    # Global strings
    global_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    global_strings_data = data[offset:offset + global_str_size]
    offset += global_str_size
    
    # Function strings
    marker = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_strings_data = data[offset:offset + func_str_size]
    offset += func_str_size
    
    # Code section
    code_size_field = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    bytecode_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    bytecode_data = data[offset:offset + bytecode_size]
    offset += bytecode_size
    
    # Rest is metadata
    metadata = data[offset:]
    
    return {
        'version': version,
        'global_strings': global_strings_data,
        'func_strings': func_strings_data,
        'bytecode': bytecode_data,
        'metadata': metadata
    }


def rebuild_cso(parts, output_path):
    """Rebuild CSO from parts"""
    output = bytearray()
    
    # Version
    output.extend(struct.pack('<I', parts['version']))
    
    # Global strings
    output.extend(struct.pack('<I', len(parts['global_strings'])))
    output.extend(parts['global_strings'])
    
    # Function strings
    output.extend(struct.pack('<I', 0))  # Marker
    output.extend(struct.pack('<I', len(parts['func_strings'])))
    output.extend(parts['func_strings'])
    
    # Code
    output.extend(struct.pack('<I', 0))  # code_size_field
    output.extend(struct.pack('<I', len(parts['bytecode'])))
    output.extend(parts['bytecode'])
    
    # Metadata
    output.extend(parts['metadata'])
    
    with open(output_path, 'wb') as f:
        f.write(output)
    
    print(f"Rebuilt CSO: {len(output)} bytes")


if __name__ == "__main__":
    # Test: extract and rebuild the original to verify we understand the format
    original = '/mnt/user-data/uploads/actionmaps_Win32.cso'
    test_output = '/home/claude/actionmaps_rebuilt.cso'
    
    print("Extracting original structure...")
    parts = extract_original_structure(original)
    
    print(f"Version: {parts['version']}")
    print(f"Global strings: {len(parts['global_strings'])} bytes")
    print(f"Function strings: {len(parts['func_strings'])} bytes")
    print(f"Bytecode: {len(parts['bytecode'])} bytes")
    print(f"Metadata: {len(parts['metadata'])} bytes")
    
    print("\nRebuilding...")
    rebuild_cso(parts, test_output)
    
    # Verify
    with open(original, 'rb') as f:
        orig_data = f.read()
    with open(test_output, 'rb') as f:
        rebuilt_data = f.read()
    
    if orig_data == rebuilt_data:
        print("✓ Perfect match! Binary is identical.")
    else:
        print(f"✗ Mismatch: original={len(orig_data)}, rebuilt={len(rebuilt_data)}")
        # Find first difference
        for i in range(min(len(orig_data), len(rebuilt_data))):
            if orig_data[i] != rebuilt_data[i]:
                print(f"First difference at offset 0x{i:04X}")
                print(f"  Original: 0x{orig_data[i]:02X}")
                print(f"  Rebuilt: 0x{rebuilt_data[i]:02X}")
                break
