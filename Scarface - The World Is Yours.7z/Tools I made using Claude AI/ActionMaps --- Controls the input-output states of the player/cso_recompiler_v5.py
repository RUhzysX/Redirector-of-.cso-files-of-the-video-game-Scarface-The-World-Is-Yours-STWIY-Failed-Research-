#!/usr/bin/env python3
"""
CSO Recompiler V5 - CORRECT VERSION
Based on analysis of the BrokenFace decompiler source code

Key discoveries:
1. String offsets are 16-bit (2 bytes), not 32-bit
2. Bytecode uses BIG-ENDIAN for values
3. Float tables exist (even if empty)
4. IdentTable patches string references
5. Bytecode is COMPRESSED with 0xFF extension codes

File structure:
- Version (4 bytes)
- Global String Table (size + data)
- Global Float Table (count + floats)
- Function String Table (size + data)  
- Function Float Table (count + floats)
- ByteCode (code_count + compressed data)
- IdentTable (entry_count + entries)

Usage: python3 cso_recompiler_v5.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple

# Opcodes from codec.py
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_RETURN = 0x0D
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_SETCUROBJECT = 0x32
OP_SETCUROBJECT_NEW = 0x33
OP_SETCURFIELD = 0x34
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_CALLFUNC_RESOLVE = 0x4C
OP_PUSH = 0x54

# Extension control code
EXT_CTRL_CODE = 0xFF


class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        if s in self.offsets:
            return self.offsets[s]
        
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class BytecodeBuilder:
    def __init__(self):
        self.codes = []  # List of bytecode values
        self.string_refs = {}  # code_index -> string_offset mapping
    
    def emit_code(self, code: int):
        """Emit a single bytecode"""
        self.codes.append(code)
    
    def emit_uint16_be(self, value: int):
        """Emit 16-bit big-endian value as 2 codes"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes.append(high)
        self.codes.append(low)
    
    def emit_string_ref(self, offset: int):
        """Emit string reference (16-bit big-endian)"""
        # Mark this location for IdentTable
        code_index = len(self.codes)
        self.string_refs[code_index] = offset
        
        # Emit as big-endian 16-bit
        self.emit_uint16_be(offset)
    
    def get_ip(self) -> int:
        """Get current instruction pointer (code count)"""
        return len(self.codes)
    
    def patch_uint16(self, index: int, value: int):
        """Patch a 16-bit value at given index"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.codes[index] = high
        self.codes[index + 1] = low
    
    def to_bytes(self) -> bytes:
        """Convert codes to compressed bytecode"""
        output = bytearray()
        
        for code in self.codes:
            if code > 0xFF:
                # Extended code: 0xFF + 2 bytes
                output.append(EXT_CTRL_CODE)
                output.append((code >> 8) & 0xFF)
                output.append(code & 0xFF)
            else:
                output.append(code)
        
        return bytes(output)


class IdentTable:
    def __init__(self):
        self.entries = {}  # offset -> list of code indices
    
    def add(self, offset: int, code_index: int):
        if offset not in self.entries:
            self.entries[offset] = []
        self.entries[offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        """Convert to binary format"""
        output = bytearray()
        
        # Entry count
        output.extend(struct.pack('<I', len(self.entries)))
        
        # Each entry: offset(2) + padding(2) + count(4) + indices(4 each)
        for offset, indices in self.entries.items():
            # Offset as 2 bytes, then 2 padding bytes
            output.extend(struct.pack('<H', offset))
            output.extend(b'\x00\x00')
            
            # Count
            output.extend(struct.pack('<I', len(indices)))
            
            # Indices
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        
        return bytes(output)


class Parser:
    def __init__(self, source: str):
        self.source = source
    
    def parse(self) -> List[Tuple[str, str, str]]:
        """Parse all functions, returns list of (name, params, body)"""
        functions = []
        lines = self.source.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            if line.startswith('function '):
                func_match = re.match(r'function\s+(\w+)\s*\(([^)]*)\)', line)
                if func_match:
                    func_name = func_match.group(1)
                    params = func_match.group(2).strip()
                    
                    # Find body
                    if '{' not in line:
                        i += 1
                        while i < len(lines) and '{' not in lines[i]:
                            i += 1
                    
                    # Collect body
                    brace_count = 0
                    body_lines = []
                    found_open = False
                    
                    while i < len(lines):
                        current = lines[i]
                        
                        for char in current:
                            if char == '{':
                                brace_count += 1
                                found_open = True
                            elif char == '}':
                                brace_count -= 1
                        
                        if found_open:
                            body_lines.append(current)
                        
                        if found_open and brace_count == 0:
                            break
                        
                        i += 1
                    
                    # Extract body
                    body = '\n'.join(body_lines)
                    body = re.sub(r'function\s+\w+\s*\([^)]*\)\s*\{', '', body, count=1)
                    body = body.rstrip().rstrip('}')
                    
                    functions.append((func_name, params, body))
            
            i += 1
        
        return functions


class CSOCompiler:
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.bytecode = BytecodeBuilder()
        self.ident_table = IdentTable()
    
    def compile(self, source: str) -> bytes:
        parser = Parser(source)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions:")
        for name, params, _ in functions:
            param_str = f"({params})" if params else "()"
            print(f"  - {name}{param_str}")
        
        # Compile all functions
        for func_name, params, body in functions:
            self.compile_function(func_name, params, body)
        
        return self.build_cso()
    
    def compile_function(self, name: str, params: str, body: str):
        # OP_FUNC_DECL
        self.bytecode.emit_code(OP_FUNC_DECL)
        
        # Function name
        name_offset = self.global_strings.add(name)
        code_idx = self.bytecode.get_ip()
        self.bytecode.emit_string_ref(name_offset)
        self.ident_table.add(name_offset, code_idx)
        
        # Namespace (empty)
        ns_offset = self.global_strings.add("")
        code_idx = self.bytecode.get_ip()
        self.bytecode.emit_string_ref(ns_offset)
        self.ident_table.add(ns_offset, code_idx)
        
        # Package (empty)
        pkg_offset = self.global_strings.add("")
        code_idx = self.bytecode.get_ip()
        self.bytecode.emit_string_ref(pkg_offset)
        self.ident_table.add(pkg_offset, code_idx)
        
        # Has body (boolean as byte)
        self.bytecode.emit_code(0x01)
        
        # New IP (will patch)
        newip_index = self.bytecode.get_ip()
        self.bytecode.emit_uint16_be(0)
        
        # Argc
        param_count = 0
        if params.strip():
            param_count = len([p.strip() for p in params.split(',') if p.strip()])
        self.bytecode.emit_code(param_count)
        
        # Parameter names
        if param_count > 0:
            for param in params.split(','):
                param = param.strip()
                if param:
                    param_offset = self.global_strings.add(param)
                    code_idx = self.bytecode.get_ip()
                    self.bytecode.emit_string_ref(param_offset)
                    self.ident_table.add(param_offset, code_idx)
        
        # Compile body (simplified for now)
        # Just add a return
        self.bytecode.emit_code(OP_RETURN)
        
        # Patch newip
        end_ip = self.bytecode.get_ip()
        self.bytecode.patch_uint16(newip_index, end_ip)
    
    def build_cso(self) -> bytes:
        output = bytearray()
        
        # Version
        output.extend(struct.pack('<I', 1))
        
        # Global String Table
        gst_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(gst_bytes)))
        output.extend(gst_bytes)
        
        # Global Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # Function String Table
        fst_bytes = self.func_strings.to_bytes()
        output.extend(struct.pack('<I', len(fst_bytes)))
        output.extend(fst_bytes)
        
        # Function Float Table (empty)
        output.extend(struct.pack('<I', 0))
        
        # ByteCode
        bc_bytes = self.bytecode.to_bytes()
        output.extend(struct.pack('<I', len(self.bytecode.codes)))  # Code count, not byte count!
        output.extend(bc_bytes)
        
        # IdentTable
        ident_bytes = self.ident_table.to_bytes()
        output.extend(ident_bytes)
        
        return bytes(output)


def main():
    if len(sys.argv) != 3:
        print("CSO Recompiler V5 - Correct Implementation")
        print()
        print("Usage: python3 cso_recompiler_v5.py input.cs output.cso")
        print()
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    print(f"Compiling {input_file}...")
    
    with open(input_file, 'r') as f:
        source = f.read()
    
    compiler = CSOCompiler()
    cso_data = compiler.compile(source)
    
    with open(output_file, 'wb') as f:
        f.write(cso_data)
    
    print(f"\nOutput: {output_file} ({len(cso_data)} bytes)")
    print(f"Global strings: {len(compiler.global_strings.strings)}")
    print(f"Function strings: {len(compiler.func_strings.strings)}")
    print(f"Bytecode codes: {len(compiler.bytecode.codes)}")
    print(f"IdentTable entries: {len(compiler.ident_table.entries)}")


if __name__ == "__main__":
    main()
