#!/usr/bin/env python3
"""
CSO Recompiler V3 - Hybrid Approach
- Uses original bytecode as template
- Uses original metadata (line breaks, etc.)
- Only modifies what's necessary

This approach is safer for initial testing
"""

import struct
import sys

def extract_cso_parts(filepath):
    """Extract all parts from a CSO file"""
    with open(filepath, 'rb') as f:
        data = f.read()
    
    offset = 0
    
    # Header
    version = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    
    # Global strings
    global_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    global_str_data = data[offset:offset + global_str_size]
    offset += global_str_size
    
    # Function strings
    marker = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    func_str_data = data[offset:offset + func_str_size]
    offset += func_str_size
    
    # Code
    code_size_field = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    bytecode_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4
    bytecode_data = data[offset:offset + bytecode_size]
    offset += bytecode_size
    
    # Everything else (metadata)
    metadata = data[offset:]
    
    return {
        'version': version,
        'global_strings': global_str_data,
        'function_strings': func_str_data,
        'bytecode': bytecode_data,
        'metadata': metadata,
        'code_size_field': code_size_field
    }


def rebuild_cso(parts):
    """Rebuild CSO from parts"""
    output = bytearray()
    
    # Version
    output.extend(struct.pack('<I', parts['version']))
    
    # Global strings
    output.extend(struct.pack('<I', len(parts['global_strings'])))
    output.extend(parts['global_strings'])
    
    # Function strings
    output.extend(struct.pack('<I', 0))  # Marker
    output.extend(struct.pack('<I', len(parts['function_strings'])))
    output.extend(parts['function_strings'])
    
    # Code
    output.extend(struct.pack('<I', parts.get('code_size_field', 0)))
    output.extend(struct.pack('<I', len(parts['bytecode'])))
    output.extend(parts['bytecode'])
    
    # Metadata
    output.extend(parts['metadata'])
    
    return bytes(output)


def modify_string_in_table(string_data, old_string, new_string):
    """Replace a string in a string table"""
    # Find the old string
    old_bytes = old_string.encode('ascii') + b'\x00'
    new_bytes = new_string.encode('ascii') + b'\x00'
    
    if old_bytes in string_data:
        # Simple replacement (only works if new string is same length or shorter)
        if len(new_bytes) <= len(old_bytes):
            return string_data.replace(old_bytes, new_bytes.ljust(len(old_bytes), b'\x00'))
        else:
            print(f"Warning: '{new_string}' is longer than '{old_string}', skipping")
    
    return string_data


def main():
    if len(sys.argv) < 3:
        print("CSO Recompiler V3 - Hybrid Approach")
        print()
        print("Usage:")
        print("  1. Test mode (just copy original):")
        print("     python3 cso_recompiler_v3.py original.cso test_output.cso")
        print()
        print("  2. Modify mode (replace strings):")
        print("     python3 cso_recompiler_v3.py original.cso output.cso OLD_STR NEW_STR")
        print()
        sys.exit(1)
    
    original_file = sys.argv[1]
    output_file = sys.argv[2]
    
    print(f"Loading {original_file}...")
    parts = extract_cso_parts(original_file)
    
    print(f"Version: {parts['version']}")
    print(f"Global strings: {len(parts['global_strings'])} bytes")
    print(f"Function strings: {len(parts['function_strings'])} bytes")
    print(f"Bytecode: {len(parts['bytecode'])} bytes")
    print(f"Metadata: {len(parts['metadata'])} bytes")
    
    # If user provided string replacements
    if len(sys.argv) >= 5:
        old_str = sys.argv[3]
        new_str = sys.argv[4]
        
        print(f"\nReplacing '{old_str}' with '{new_str}'...")
        
        # Try to replace in both string tables
        parts['global_strings'] = modify_string_in_table(
            parts['global_strings'], old_str, new_str
        )
        parts['function_strings'] = modify_string_in_table(
            parts['function_strings'], old_str, new_str
        )
    
    # Rebuild
    print(f"\nRebuilding {output_file}...")
    output_data = rebuild_cso(parts)
    
    with open(output_file, 'wb') as f:
        f.write(output_data)
    
    print(f"Done! Output size: {len(output_data)} bytes")
    
    # Verify it's identical (in test mode)
    if len(sys.argv) == 3:
        with open(original_file, 'rb') as f:
            orig_data = f.read()
        
        if output_data == orig_data:
            print("✓ Perfect match - file is identical to original")
        else:
            print("✗ Files differ!")
            print(f"  Original: {len(orig_data)} bytes")
            print(f"  Output: {len(output_data)} bytes")


if __name__ == "__main__":
    main()
