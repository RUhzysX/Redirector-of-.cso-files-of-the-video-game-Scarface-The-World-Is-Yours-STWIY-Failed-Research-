#!/usr/bin/env python3
"""
CSO Recompiler for Torque3D (Scarface: The World Is Yours)
Compiles decompiled .cs script files back into .cso binary format

Usage: python3 cso_compiler.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple

# Opcode definitions from CodeBlock.h
OP_FUNC_DECL = 0
OP_CREATE_OBJECT = 1
OP_ADD_OBJECT = 4
OP_END_OBJECT = 5
OP_JMPIFFNOT = 6
OP_JMPIFNOT = 7
OP_JMPIFF = 8
OP_JMPIF = 9
OP_JMPIFNOT_NP = 10
OP_JMPIF_NP = 11
OP_JMP = 12
OP_RETURN = 13
OP_SETCURVAR = 36
OP_SETCURVAR_CREATE = 37
OP_SETCURVAR_ARRAY = 40
OP_SETCURVAR_ARRAY_CREATE = 41
OP_LOADVAR_UINT = 44
OP_LOADVAR_FLT = 45
OP_LOADVAR_STR = 46
OP_SAVEVAR_UINT = 47
OP_SAVEVAR_FLT = 48
OP_SAVEVAR_STR = 49
OP_SETCUROBJECT = 50
OP_SETCUROBJECT_NEW = 51
OP_SETCURFIELD = 52
OP_SETCURFIELD_ARRAY = 53
OP_LOADFIELD_UINT = 54
OP_LOADFIELD_FLT = 55
OP_LOADFIELD_STR = 56
OP_SAVEFIELD_UINT = 57
OP_SAVEFIELD_FLT = 58
OP_SAVEFIELD_STR = 59
OP_STR_TO_UINT = 60
OP_STR_TO_FLT = 61
OP_STR_TO_NONE = 62
OP_FLT_TO_UINT = 63
OP_FLT_TO_STR = 64
OP_FLT_TO_NONE = 65
OP_UINT_TO_FLT = 66
OP_UINT_TO_STR = 67
OP_UINT_TO_NONE = 68
OP_LOADIMMED_UINT = 69
OP_LOADIMMED_FLT = 70
OP_LOADIMMED_STR = 71
OP_LOADIMMED_IDENT = 72
OP_TAG_TO_STR = 73
OP_CALLFUNC_RESOLVE = 74
OP_CALLFUNC = 75
OP_ADVANCE_STR = 77
OP_ADVANCE_STR_APPENDCHAR = 78
OP_ADVANCE_STR_COMMA = 79
OP_ADVANCE_STR_NUL = 80
OP_REWIND_STR = 81
OP_TERMINATE_REWIND_STR = 82
OP_COMPARE_STR = 83
OP_PUSH = 84
OP_PUSH_FRAME = 85

# Call types
FUNC_CALL = 0
METHOD_CALL = 1
PARENT_CALL = 2


class StringTable:
    """Manages string tables for CSO files"""
    def __init__(self):
        self.strings = []
        self.string_map = {}  # string -> offset mapping
        
    def add(self, string: str) -> int:
        """Add a string and return its offset"""
        if string in self.string_map:
            return self.string_map[string]
        
        offset = sum(len(s) + 1 for s in self.strings)  # +1 for null terminator
        self.strings.append(string)
        self.string_map[string] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        """Convert string table to bytes"""
        return b''.join(s.encode('ascii') + b'\x00' for s in self.strings)


class CSO Compiler:
    """Compiles TorqueScript to CSO binary format"""
    
    def __init__(self):
        self.global_strings = StringTable()
        self.function_strings = StringTable()
        self.bytecode = []
        
    def compile_file(self, source_code: str) -> bytes:
        """Compile a complete .cs file to CSO binary"""
        
        # Parse the source code
        functions = self.parse_functions(source_code)
        
        # Compile each function
        for func_name, func_body in functions:
            self.compile_function(func_name, func_body)
        
        # Build the CSO binary
        return self.build_cso()
    
    def parse_functions(self, source: str) -> List[Tuple[str, str]]:
        """Parse function definitions from source code"""
        functions = []
        
        # Match function definitions: function name() { ... }
        pattern = r'function\s+(\w+)\s*\([^)]*\)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}'
        
        for match in re.finditer(pattern, source, re.MULTILINE | re.DOTALL):
            func_name = match.group(1)
            func_body = match.group(2)
            functions.append((func_name, func_body))
        
        return functions
    
    def compile_function(self, func_name: str, func_body: str):
        """Compile a single function"""
        
        # Add function name to global strings
        fn_name_offset = self.global_strings.add(func_name)
        fn_namespace_offset = 0  # Empty namespace
        fn_package_offset = 0  # Empty package
        
        # OP_FUNC_DECL
        self.bytecode.append(OP_FUNC_DECL)
        self.bytecode.append(fn_name_offset)
        self.bytecode.append(fn_namespace_offset)
        self.bytecode.append(fn_package_offset)
        self.bytecode.append(1)  # has_body = true
        
        # Calculate IP after function declaration (we'll update this)
        func_start_ip = len(self.bytecode) + 2  # +2 for newip and argc
        self.bytecode.append(0)  # newip placeholder
        self.bytecode.append(0)  # argc = 0 (no arguments for now)
        
        # Compile function body
        body_start_ip = len(self.bytecode)
        self.compile_statements(func_body)
        
        # Add return at end if not present
        if not self.bytecode or self.bytecode[-1] != OP_RETURN:
            self.bytecode.append(OP_RETURN)
        
        # Update the newip to point after the function
        func_end_ip = len(self.bytecode)
        self.bytecode[func_start_ip - 2] = func_end_ip
    
    def compile_statements(self, body: str):
        """Compile statements in function body"""
        
        # Split into statements (simplified - just by semicolons and newlines)
        statements = [s.strip() for s in body.split(';') if s.strip()]
        
        for stmt in statements:
            self.compile_statement(stmt)
    
    def compile_statement(self, stmt: str):
        """Compile a single statement"""
        stmt = stmt.strip()
        
        if not stmt:
            return
        
        # Variable assignment: %var = ...
        if '=' in stmt and stmt.startswith('%'):
            self.compile_assignment(stmt)
        
        # Object creation: %var = new ClassName(...)
        elif 'new ' in stmt:
            self.compile_object_creation(stmt)
        
        # Method call: %obj.method(...)
        elif '.' in stmt and '(' in stmt:
            self.compile_method_call(stmt)
        
        # Function call: functionName(...)
        elif '(' in stmt:
            self.compile_function_call(stmt)
        
        # Return statement
        elif stmt.startswith('return'):
            self.bytecode.append(OP_RETURN)
        
        # If statement
        elif stmt.startswith('if'):
            self.compile_if_statement(stmt)
    
    def compile_assignment(self, stmt: str):
        """Compile variable assignment"""
        parts = stmt.split('=', 1)
        var_name = parts[0].strip()
        value = parts[1].strip() if len(parts) > 1 else ""
        
        # Add variable name to global strings
        var_offset = self.global_strings.add(var_name)
        
        # SETCURVAR_CREATE (creates if doesn't exist)
        self.bytecode.append(OP_SETCURVAR_CREATE)
        self.bytecode.append(var_offset)
        
        # Compile the value expression
        if value:
            self.compile_expression(value)
            # SAVEVAR_STR (assuming string for now)
            self.bytecode.append(OP_SAVEVAR_STR)
    
    def compile_object_creation(self, stmt: str):
        """Compile object creation: %var = new ClassName(...)"""
        
        # Parse: %var = new ClassName(Name : "value", ...)
        match = re.search(r'%(\w+)\s*=\s*new\s+(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        var_name = '%' + match.group(1)
        class_name = match.group(2)
        args = match.group(3)
        
        # Add class name to global strings
        class_offset = self.global_strings.add(class_name)
        
        # OP_CREATE_OBJECT
        self.bytecode.append(OP_CREATE_OBJECT)
        self.bytecode.append(class_offset)  # obj_parent
        self.bytecode.append(0)  # is_datablock
        self.bytecode.append(0)  # is_internal
        self.bytecode.append(0)  # is_singleton
        self.bytecode.append(0)  # line_number
        self.bytecode.append(0)  # fail_jump (placeholder)
        
        # Parse and compile object properties
        if args.strip():
            self.compile_object_properties(args)
        
        # OP_ADD_OBJECT
        self.bytecode.append(OP_ADD_OBJECT)
        self.bytecode.append(0)  # place_at_root
        
        # OP_END_OBJECT  
        self.bytecode.append(OP_END_OBJECT)
        self.bytecode.append(0)  # place_at_root
        
        # Set current object to new
        self.bytecode.append(OP_SETCUROBJECT_NEW)
        
        # Assign to variable
        var_offset = self.global_strings.add(var_name)
        self.bytecode.append(OP_SETCURVAR_CREATE)
        self.bytecode.append(var_offset)
        self.bytecode.append(OP_SAVEVAR_STR)
    
    def compile_object_properties(self, args: str):
        """Compile object properties: Name : "value", ..."""
        # This is simplified - real implementation would parse properly
        pass
    
    def compile_method_call(self, stmt: str):
        """Compile method call: %obj.method(arg1, arg2, ...)"""
        
        # Parse: %obj.method(args)
        match = re.search(r'%(\w+)\.(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        obj_var = '%' + match.group(1)
        method_name = match.group(2)
        args = match.group(3)
        
        # Load the object variable
        obj_offset = self.global_strings.add(obj_var)
        self.bytecode.append(OP_SETCURVAR)
        self.bytecode.append(obj_offset)
        self.bytecode.append(OP_LOADVAR_STR)
        self.bytecode.append(OP_SETCUROBJECT)
        
        # Push arguments
        if args.strip():
            arg_list = [a.strip() for a in args.split(',')]
            for arg in arg_list:
                self.compile_expression(arg)
                self.bytecode.append(OP_PUSH)
        
        # Call the method
        method_offset = self.global_strings.add(method_name)
        self.bytecode.append(OP_CALLFUNC)
        self.bytecode.append(method_offset)
        self.bytecode.append(0)  # namespace
        self.bytecode.append(METHOD_CALL)
    
    def compile_function_call(self, stmt: str):
        """Compile function call: functionName(arg1, arg2, ...)"""
        
        # Parse: functionName(args)
        match = re.search(r'(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        func_name = match.group(1)
        args = match.group(2)
        
        # Push arguments
        if args.strip():
            arg_list = [a.strip() for a in args.split(',')]
            for arg in arg_list:
                self.compile_expression(arg)
                self.bytecode.append(OP_PUSH)
        
        # Call the function
        func_offset = self.global_strings.add(func_name)
        self.bytecode.append(OP_CALLFUNC)
        self.bytecode.append(func_offset)
        self.bytecode.append(0)  # namespace
        self.bytecode.append(FUNC_CALL)
    
    def compile_expression(self, expr: str):
        """Compile an expression"""
        expr = expr.strip()
        
        # String literal
        if expr.startswith('"') and expr.endswith('"'):
            string_value = expr[1:-1]
            str_offset = self.function_strings.add(string_value)
            self.bytecode.append(OP_LOADIMMED_STR)
            self.bytecode.append(str_offset)
        
        # Integer literal
        elif expr.isdigit():
            value = int(expr)
            self.bytecode.append(OP_LOADIMMED_UINT)
            self.bytecode.append(value)
        
        # Variable reference
        elif expr.startswith('%'):
            var_offset = self.global_strings.add(expr)
            self.bytecode.append(OP_SETCURVAR)
            self.bytecode.append(var_offset)
            self.bytecode.append(OP_LOADVAR_STR)
        
        # Identifier
        else:
            ident_offset = self.global_strings.add(expr)
            self.bytecode.append(OP_LOADIMMED_IDENT)
            self.bytecode.append(ident_offset)
    
    def compile_if_statement(self, stmt: str):
        """Compile if statement (simplified)"""
        # This would need proper parsing - just a placeholder
        pass
    
    def build_cso(self) -> bytes:
        """Build the final CSO binary"""
        output = bytearray()
        
        # Header
        output.extend(struct.pack('<I', 1))  # Version
        
        # Global string table
        global_strings_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(global_strings_bytes)))
        output.extend(global_strings_bytes)
        
        # Function string table marker and size
        function_strings_bytes = self.function_strings.to_bytes()
        output.extend(struct.pack('<I', 0))  # Marker
        output.extend(struct.pack('<I', len(function_strings_bytes)))
        output.extend(function_strings_bytes)
        
        # Code size
        output.extend(struct.pack('<I', len(self.bytecode)))
        
        # Bytecode
        for opcode in self.bytecode:
            output.extend(struct.pack('<I', opcode))
        
        return bytes(output)


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_compiler.py input.cs output.cso")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # Read source code
    with open(input_file, 'r') as f:
        source_code = f.read()
    
    # Compile
    compiler = CSOCompiler()
    cso_data = compiler.compile_file(source_code)
    
    # Write output
    with open(output_file, 'wb') as f:
        f.write(cso_data)
    
    print(f"Compiled {input_file} -> {output_file}")
    print(f"Output size: {len(cso_data)} bytes")


if __name__ == "__main__":
    main()
