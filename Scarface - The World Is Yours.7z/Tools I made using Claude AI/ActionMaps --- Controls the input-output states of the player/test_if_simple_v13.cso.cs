// Decompiled file: test_if_simple_v13.cso;
function testIf()
{
	if (!(someFunc(%var)))
	{
		new "Name"(Name : "TestMap")
		{
			%obj = "TestMap";
		}
	}
}
return "key".bind("action");
