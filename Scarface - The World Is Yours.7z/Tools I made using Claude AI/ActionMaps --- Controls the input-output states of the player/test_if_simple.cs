function testIf() {
    if (!(someFunc(%var))) {
        %obj = new ActionMap(Name : "TestMap");
        %obj.bind("key", "action");
    }
    return;
}
