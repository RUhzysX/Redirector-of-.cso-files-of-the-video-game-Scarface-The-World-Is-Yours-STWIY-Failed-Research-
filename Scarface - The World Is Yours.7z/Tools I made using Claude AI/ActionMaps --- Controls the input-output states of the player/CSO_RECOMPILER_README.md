# CSO Recompiler for Scarface: The World Is Yours (Torque3D Engine)

## Project Overview

This project aims to create a recompiler for `.cso` (Compiled Script Object) files used in Scarface: The World Is Yours. The game uses a variant of the Torque3D engine, and while character scripts are dynamically compiled, other game elements (vehicles, world objects, etc.) use pre-compiled `.cso` files.

## File Format Analysis

### CSO Binary Structure

Based on analysis of `actionmaps_Win32.cso`, the format is:

```
Offset  | Size    | Description
--------|---------|--------------------------------------------------
0x0000  | 4 bytes | Version (uint32, value: 1)
0x0004  | 4 bytes | Global String Table Size (uint32)
0x0008  | N bytes | Global String Table (null-terminated strings)
+N      | 4 bytes | Marker (uint32, value: 0)
+4      | 4 bytes | Function String Table Size (uint32)
+8      | M bytes | Function String Table (null-terminated strings)
+M      | 4 bytes | Code Size Field (uint32, appears to be 0)
+4      | 4 bytes | Actual Bytecode Size in bytes (uint32)
+8      | X bytes | Bytecode (series of uint32 values)
```

### String Tables

**Global String Table**: Contains obfuscated function/variable names used in the decompiled script
- Examples: `stxlagdgapl`, `stxilbjjlhp`, `stxkeipamak`

**Function String Table**: Contains actual game strings and identifiers
- Examples: `GlobalActionMap`, `Joystick`, `DPadDown R3`, `ToggleDebugMode();`

### Bytecode Format

The bytecode section contains opcodes and their arguments as a continuous stream of uint32 values.

## Opcode Reference

From `CodeBlock.h`, here are the key opcodes:

| Opcode | Name | Args | Description |
|--------|------|------|-------------|
| 0 | OP_FUNC_DECL | 6+ | Function declaration |
| 1 | OP_CREATE_OBJECT | 6 | Create new object |
| 4 | OP_ADD_OBJECT | 1 | Add object to scene |
| 5 | OP_END_OBJECT | 1 | End object definition |
| 13 | OP_RETURN | 0 | Return from function |
| 36 | OP_SETCURVAR | 1 | Set current variable |
| 37 | OP_SETCURVAR_CREATE | 1 | Set/create variable |
| 50 | OP_SETCUROBJECT | 0 | Set current object |
| 51 | OP_SETCUROBJECT_NEW | 0 | Set to newly created object |
| 52 | OP_SETCURFIELD | 1 | Set current field |
| 69 | OP_LOADIMMED_UINT | 1 | Load immediate uint |
| 71 | OP_LOADIMMED_STR | 1 | Load immediate string |
| 72 | OP_LOADIMMED_IDENT | 1 | Load identifier |
| 74 | OP_CALLFUNC_RESOLVE | 3 | Resolve and call function |
| 75 | OP_CALLFUNC | 3 | Call function |
| 84 | OP_PUSH | 0 | Push to stack |

### Opcode Argument Details

**OP_FUNC_DECL** (6+ args):
1. Function name offset (in global strings)
2. Namespace offset (in global strings)
3. Package offset (in global strings)
4. Has body flag (1/0)
5. New IP (instruction pointer after function)
6. Argument count
7-N. Argument identifiers (if argc > 0)

**OP_CREATE_OBJECT** (6 args):
1. Parent class offset (in global strings)
2. Is datablock flag
3. Is internal flag
4. Is singleton flag
5. Line number
6. Fail jump address

**OP_CALLFUNC** (3 args):
1. Function name offset
2. Namespace offset
3. Call type (0=Function, 1=Method, 2=Parent)

## Implementation Strategy

### Phase 1: Parser (COMPLETED)
- Parse decompiled `.cs` files
- Extract function definitions
- Identify method calls and object creations
- Build AST (Abstract Syntax Tree)

### Phase 2: String Table Builder (IN PROGRESS)
- Collect all identifiers from source
- Build global string table (function/variable names)
- Build function string table (literals, method names)
- Generate offset mappings

### Phase 3: Bytecode Generator (TODO)
- Traverse AST and emit opcodes
- Handle:
  - Function declarations
  - Variable assignments  
  - Object creation (new ClassName())
  - Method calls (obj.method())
  - Function calls
  - Control flow (if/while/for)
  - Return statements

### Phase 4: Binary Writer (TODO)
- Write CSO header
- Write string tables
- Write bytecode section
- Calculate and update all offsets

## Usage Example

```python
from cso_compiler import CSOCompiler

# Read decompiled source
with open('actionmaps_Win32_cso.cs', 'r') as f:
    source = f.read()

# Compile to CSO
compiler = CSOCompiler()
cso_binary = compiler.compile(source)

# Write output
with open('actionmaps_Win32_NEW.cso', 'wb') as f:
    f.write(cso_binary)
```

## Known Limitations

1. **Obfuscation**: The decompiled scripts use obfuscated names (stxlagdgapl, etc.). These must match exactly for the game to recognize functions/variables.

2. **String Table Ordering**: The order of strings in the tables matters. The original CSO uses specific ordering that may be significant.

3. **Opcode Variants**: Some opcodes have variants (e.g., OP_SETCURVAR_KURVA, OP_SETCURVAR_ANYAD) whose exact behavior is unknown.

4. **Metadata**: There may be additional metadata (line number tables, debug info) that we haven't fully reverse-engineered.

## Next Steps

1. **Complete string table builder** with exact ordering logic
2. **Implement bytecode generator** for basic constructs
3. **Test with simple scripts** before tackling ActionMaps
4. **Verify binary output** matches original structure
5. **Test in-game** to confirm functionality

## Contributing

Since you're a student with time to work on this incrementally, I recommend:

1. Start with the simplest possible script (single function, no objects)
2. Get that compiling and working in-game
3. Gradually add support for more complex constructs
4. Build unit tests comparing your output against original CSO files
5. Document any discoveries about unknown opcodes or behaviors

## Tools Needed

- Python 3.7+
- Hex editor (HxD, 010 Editor) for binary inspection
- The game for testing
- Patience and debugging skills!

## Resources

- Original CodeBlock.h and CodeBlock.cpp (provided)
- Decompiled .cs files as reference
- Original .cso files for comparison
- Torque3D documentation (some concepts carry over)

Good luck with your modding project! Feel free to reach out if you discover new information about the file format.
