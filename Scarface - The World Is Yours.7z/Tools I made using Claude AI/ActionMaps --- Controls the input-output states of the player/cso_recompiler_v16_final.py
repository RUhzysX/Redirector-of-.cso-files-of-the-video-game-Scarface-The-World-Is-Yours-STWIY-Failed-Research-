#!/usr/bin/env python3
"""
CSO Recompiler V16 - THE REAL FIX

CRITICAL FIX: Proper separation of OPCODES vs DATA
- Only OPCODES increment code_count
- Data bytes (string offsets, flags, etc.) are just bytes
- code_count = number of opcodes, NOT total bytes

Usage: python3 cso_recompiler_v16_final.py input.cs output.cso
"""

import sys
import struct
import re
from typing import List, Dict, Tuple, Optional, Any

# Opcodes
OP_FUNC_DECL = 0x00
OP_CREATE_OBJECT = 0x01
OP_ADD_OBJECT = 0x04
OP_END_OBJECT = 0x05
OP_JMPIFNOT = 0x07
OP_JMPIF = 0x09
OP_JMPIFNOT_NP = 0x0A
OP_JMPIF_NP = 0x0B
OP_JMP = 0x0C
OP_RETURN = 0x0D
OP_CMPEQ = 0x0E
OP_CMPLT = 0x0F
OP_CMPLE = 0x10
OP_CMPGR = 0x11
OP_CMPGE = 0x12
OP_CMPNE = 0x13
OP_NOT = 0x18
OP_AND = 0x1D
OP_OR = 0x1E
OP_SETCURVAR = 0x24
OP_SETCURVAR_CREATE = 0x25
OP_LOADVAR_STR = 0x2E
OP_SAVEVAR_STR = 0x31
OP_SETCUROBJECT = 0x32
OP_SETCURFIELD = 0x36
OP_SETCURFIELD_ARRAY = 0x37
OP_STR_TO_UINT = 0x3C
OP_LOADIMMED_STR = 0x47
OP_LOADIMMED_IDENT = 0x48
OP_CALLFUNC = 0x4B
OP_PUSH = 0x54
OP_PUSHFRAME = 0x55

EXT_CTRL_CODE = 0xFF

CALL_FUNCTION = 0x00
CALL_METHOD = 0x01

class StringTable:
    def __init__(self):
        self.strings = []
        self.offsets = {}
    
    def add(self, s: str) -> int:
        if s in self.offsets:
            return self.offsets[s]
        offset = sum(len(string) + 1 for string in self.strings)
        self.strings.append(s)
        self.offsets[s] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)

class CodeBuilder:
    """
    CRITICAL: Separates OPCODES from DATA
    - emit_opcode(): Increments code_count (these are the actual instructions)
    - emit_data_*(): Just adds bytes (parameters/arguments for opcodes)
    """
    def __init__(self):
        self.bytes = []           # Byte stream
        self.code_count = 0       # Number of OPCODES only
        self.jump_patches = {}    # label -> list of byte positions
        self.labels = {}          # label -> code index
    
    def emit_opcode(self, opcode: int):
        """Emit an opcode - counts as 1 or 3 codes depending on if extended"""
        if opcode >= 0xFF or opcode < 0:
            # Extended opcode: 3 bytes = 3 codes
            self.bytes.append(EXT_CTRL_CODE)
            self.bytes.append((opcode >> 8) & 0xFF)
            self.bytes.append(opcode & 0xFF)
            self.code_count += 3
        else:
            # Regular opcode: 1 byte = 1 code
            self.bytes.append(opcode & 0xFF)
            self.code_count += 1
    
    def emit_data_u8(self, value: int):
        """Emit 1 byte of data - counts as 1 code!"""
        self.bytes.append(value & 0xFF)
        self.code_count += 1
    
    def emit_data_u16(self, value: int):
        """Emit 2 bytes of data - counts as 2 codes!"""
        high = (value >> 8) & 0xFF
        low = value & 0xFF
        self.bytes.append(high)
        self.bytes.append(low)
        self.code_count += 2
    
    def emit_data_u32(self, value: int):
        """Emit 4 bytes of data as big-endian (NOT codes)"""
        self.bytes.append((value >> 24) & 0xFF)
        self.bytes.append((value >> 16) & 0xFF)
        self.bytes.append((value >> 8) & 0xFF)
        self.bytes.append(value & 0xFF)
    
    def emit_jump_placeholder(self, label: str):
        """Emit placeholder for jump target (1 byte of data)"""
        byte_pos = len(self.bytes)
        if label not in self.jump_patches:
            self.jump_patches[label] = []
        self.jump_patches[label].append(byte_pos)
        self.bytes.append(0x00)  # Placeholder
    
    def place_label(self, label: str):
        """Place label at current CODE position"""
        self.labels[label] = self.code_count
    
    def patch_jumps(self):
        """Patch jump targets with actual code indices"""
        for label, byte_positions in self.jump_patches.items():
            if label not in self.labels:
                print(f"WARNING: Label {label} not found!")
                continue
            
            target_code_idx = self.labels[label]
            
            for byte_pos in byte_positions:
                if target_code_idx > 255:
                    print(f"WARNING: Jump target {target_code_idx} > 255, using modulo")
                    self.bytes[byte_pos] = target_code_idx & 0xFF
                else:
                    self.bytes[byte_pos] = target_code_idx
    
    def get_code_index(self) -> int:
        """Return current code index (number of opcodes emitted)"""
        return self.code_count
    
    def to_bytes(self) -> bytes:
        """Return the complete byte stream"""
        return bytes(self.bytes)

class IdentTable:
    """Maps global string offsets to code indices where they're referenced"""
    def __init__(self):
        self.entries = {}  # string_offset -> [code_indices...]
    
    def add(self, string_offset: int, code_index: int):
        """Add a reference: string at offset is used at this code index"""
        if string_offset not in self.entries:
            self.entries[string_offset] = []
        self.entries[string_offset].append(code_index)
    
    def to_bytes(self) -> bytes:
        output = bytearray()
        output.extend(struct.pack('<I', len(self.entries)))
        for offset in sorted(self.entries.keys()):
            indices = self.entries[offset]
            output.extend(struct.pack('<H', offset & 0xFFFF))
            output.extend(b'\x00\x00')  # padding
            output.extend(struct.pack('<I', len(indices)))
            for idx in indices:
                output.extend(struct.pack('<I', idx))
        return bytes(output)

# AST Nodes (same as before)
class ASTNode:
    pass

class ObjectCreation(ASTNode):
    def __init__(self, var: str, class_name: str, properties: Dict[str, str]):
        self.var = var
        self.class_name = class_name
        self.properties = properties

class MethodCall(ASTNode):
    def __init__(self, obj: str, method: str, args: List[str]):
        self.obj = obj
        self.method = method
        self.args = args

class FunctionCall(ASTNode):
    def __init__(self, func: str, args: List[Any]):
        self.func = func
        self.args = args

class Assignment(ASTNode):
    def __init__(self, var: str, value: str):
        self.var = var
        self.value = value

class ReturnStmt(ASTNode):
    def __init__(self, value: Optional[str] = None):
        self.value = value

class IfStatement(ASTNode):
    def __init__(self, condition: Any, then_body: List[ASTNode], else_body: List[ASTNode] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body or []

class WhileLoop(ASTNode):
    def __init__(self, condition: Any, body: List[ASTNode]):
        self.condition = condition
        self.body = body

class NotExpr(ASTNode):
    def __init__(self, expr: Any):
        self.expr = expr

class BinaryOp(ASTNode):
    def __init__(self, op: str, left: Any, right: Any):
        self.op = op
        self.left = left
        self.right = right

class VarRef(ASTNode):
    def __init__(self, name: str):
        self.name = name

class Literal(ASTNode):
    def __init__(self, value: str):
        self.value = value

# Parser (same as V15, but included for completeness)
class Parser:
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')
        self.lines = self.source.split('\n')
        self.pos = 0
    
    def parse(self) -> List[Tuple[str, List[str], List[ASTNode]]]:
        functions = []
        while self.pos < len(self.lines):
            line = self.lines[self.pos].strip()
            if line.startswith('function '):
                func = self.parse_function()
                if func:
                    functions.append(func)
            else:
                self.pos += 1
        return functions
    
    def parse_function(self) -> Optional[Tuple[str, List[str], List[ASTNode]]]:
        line = self.lines[self.pos].strip()
        match = re.match(r'function\s+(\w+)\s*\((.*?)\)', line)
        if not match:
            self.pos += 1
            return None
        
        name = match.group(1)
        params_str = match.group(2)
        params = [p.strip() for p in params_str.split(',') if p.strip()]
        
        while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
            self.pos += 1
        self.pos += 1
        
        body = self.parse_block()
        return (name, params, body)
    
    def parse_block(self) -> List[ASTNode]:
        statements = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            
            if '}' in line:
                brace_count -= 1
                self.pos += 1
                if brace_count == 0:
                    break
                continue
            
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    statements.append(stmt)
            elif line.startswith('while '):
                stmt = self.parse_while_loop()
                if stmt:
                    statements.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    statements.append(stmt)
                self.pos += 1
        
        return statements
    
    def parse_if_statement(self) -> Optional[IfStatement]:
        line = self.lines[self.pos].strip()
        match = re.match(r'if\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        self.pos += 1
        then_body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            if line.startswith('if '):
                stmt = self.parse_if_statement()
                if stmt:
                    then_body.append(stmt)
            else:
                stmt = self.parse_statement(line)
                if stmt:
                    then_body.append(stmt)
                self.pos += 1
        
        else_body = []
        if self.pos < len(self.lines):
            next_line = self.lines[self.pos].strip()
            if next_line.startswith('else'):
                self.pos += 1
                while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                    self.pos += 1
                self.pos += 1
                brace_count = 1
                while self.pos < len(self.lines) and brace_count > 0:
                    line = self.lines[self.pos].strip()
                    if '}' in line:
                        brace_count -= 1
                        if brace_count == 0:
                            self.pos += 1
                            break
                        self.pos += 1
                        continue
                    if '{' in line:
                        brace_count += 1
                        self.pos += 1
                        continue
                    if not line or line.startswith('//'):
                        self.pos += 1
                        continue
                    stmt = self.parse_statement(line)
                    if stmt:
                        else_body.append(stmt)
                    self.pos += 1
        
        return IfStatement(condition, then_body, else_body)
    
    def parse_while_loop(self) -> Optional[WhileLoop]:
        line = self.lines[self.pos].strip()
        match = re.match(r'while\s*\((.*)\)', line)
        if not match:
            self.pos += 1
            return None
        
        condition_str = match.group(1).strip()
        condition = self.parse_condition(condition_str)
        
        has_brace_on_line = '{' in line
        if not has_brace_on_line:
            self.pos += 1
            while self.pos < len(self.lines) and '{' not in self.lines[self.pos]:
                self.pos += 1
        
        self.pos += 1
        body = []
        brace_count = 1
        
        while self.pos < len(self.lines) and brace_count > 0:
            line = self.lines[self.pos].strip()
            if '}' in line:
                brace_count -= 1
                if brace_count == 0:
                    self.pos += 1
                    break
                self.pos += 1
                continue
            if '{' in line:
                brace_count += 1
                self.pos += 1
                continue
            if not line or line.startswith('//'):
                self.pos += 1
                continue
            stmt = self.parse_statement(line)
            if stmt:
                body.append(stmt)
            self.pos += 1
        
        return WhileLoop(condition, body)
    
    def parse_condition(self, cond_str: str) -> Any:
        cond_str = cond_str.strip()
        
        if cond_str.startswith('!(') and cond_str.endswith(')'):
            inner = cond_str[2:-1].strip()
            inner_expr = self.parse_condition(inner)
            return NotExpr(inner_expr)
        
        for op in ['==', '!=', '<=', '>=', '<', '>']:
            if op in cond_str:
                parts = cond_str.split(op, 1)
                if len(parts) == 2:
                    left = self.parse_condition(parts[0].strip())
                    right = self.parse_condition(parts[1].strip())
                    return BinaryOp(op, left, right)
        
        if '&&' in cond_str:
            parts = cond_str.split('&&', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('&&', left, right)
        
        if '||' in cond_str:
            parts = cond_str.split('||', 1)
            if len(parts) == 2:
                left = self.parse_condition(parts[0].strip())
                right = self.parse_condition(parts[1].strip())
                return BinaryOp('||', left, right)
        
        match = re.match(r'(\w+)\s*\((.*)\)', cond_str)
        if match:
            func_name = match.group(1)
            args_str = match.group(2)
            args = []
            for arg in args_str.split(','):
                arg = arg.strip()
                if arg.startswith('%'):
                    args.append(VarRef(arg[1:]))
                else:
                    args.append(Literal(arg.strip('"')))
            return FunctionCall(func_name, args)
        
        if cond_str.startswith('%'):
            return VarRef(cond_str[1:])
        
        return Literal(cond_str.strip('"'))
    
    def parse_statement(self, line: str) -> Optional[ASTNode]:
        line = line.rstrip(';').strip()
        
        if not line or line.startswith('//'):
            return None
        
        if line.startswith('return'):
            rest = line[6:].strip()
            return ReturnStmt(rest if rest else None)
        
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\((.*)\)', line)
        if match:
            var = match.group(1)
            class_name = match.group(2)
            props_str = match.group(3)
            properties = {}
            for prop in re.finditer(r'(\w+)\s*:\s*"([^"]*)"', props_str):
                properties[prop.group(1)] = prop.group(2)
            return ObjectCreation(var, class_name, properties)
        
        match = re.match(r'(%\w+)\.(\w+)\((.*)\)', line)
        if match:
            obj = match.group(1)
            method = match.group(2)
            args_str = match.group(3)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return MethodCall(obj, method, args)
        
        match = re.match(r'(\w+)\((.*)\)', line)
        if match:
            func = match.group(1)
            args_str = match.group(2)
            args = [a.strip().strip('"') for a in args_str.split(',') if a.strip()]
            return FunctionCall(func, args)
        
        match = re.match(r'(%\w+)\s*=\s*(.+)', line)
        if match:
            var = match.group(1)
            value = match.group(2).strip().strip('"')
            return Assignment(var, value)
        
        return None

# Compiler with proper opcode/data separation
class Compiler:
    def __init__(self):
        self.global_strings = StringTable()
        self.func_strings = StringTable()
        self.code = CodeBuilder()
        self.ident_table = IdentTable()
        self.label_counter = 0
    
    def add_identifier(self, name: str) -> int:
        return self.global_strings.add(name)
    
    def add_value(self, value: str) -> int:
        return self.func_strings.add(value)
    
    def gen_label(self) -> str:
        self.label_counter += 1
        return f"L{self.label_counter}"
    
    def compile_function(self, name: str, params: List[str], statements: List[ASTNode]):
        """
        OP_FUNC_DECL structure (1 opcode):
          - fnName offset (2 bytes data)
          - namespace offset (2 bytes data)
          - package offset (2 bytes data)
          - hasBody (1 byte data)
          - end_ip (1 byte data)
          - argc (1 byte data)
          - for each arg: param offset (2 bytes data)
        """
        fn_offset = self.add_identifier(name)
        
        func_start_code_idx = self.code.get_code_index()
        
        # Emit OP_FUNC_DECL opcode
        self.code.emit_opcode(OP_FUNC_DECL)
        
        # Now at code index func_start_code_idx + 1
        # The string reference is at THIS code index
        self.ident_table.add(fn_offset, func_start_code_idx + 1)
        
        # Emit function name offset (data)
        self.code.emit_data_u16(fn_offset)
        
        # Emit namespace offset (data) - always 0 for now
        self.code.emit_data_u16(0x0000)
        
        # Emit package offset (data) - always 0 for now
        self.code.emit_data_u16(0x0000)
        
        # Emit hasBody flag (data)
        self.code.emit_data_u8(0x01)
        
        # Remember where we need to patch end_ip
        end_ip_byte_pos = len(self.code.bytes)
        self.code.emit_data_u8(0x00)  # Placeholder for end_ip
        
        # Emit argc (data)
        self.code.emit_data_u8(len(params))
        
        # Emit parameter names (data)
        for param in params:
            param_name = param[1:] if param.startswith('%') else param
            param_offset = self.add_identifier(param_name)
            
            # The param reference is at current code index
            self.ident_table.add(param_offset, self.code.get_code_index())
            self.code.emit_data_u16(param_offset)
        
        # Compile function body
        for stmt in statements:
            self.compile_statement(stmt)
        
        # Calculate end_ip (code index after last instruction)
        end_ip = self.code.get_code_index()
        
        # Patch end_ip
        if end_ip > 255:
            print(f"  WARNING: end_ip {end_ip} > 255, using modulo")
            self.code.bytes[end_ip_byte_pos] = end_ip & 0xFF
        else:
            self.code.bytes[end_ip_byte_pos] = end_ip
    
    def compile_statement(self, stmt: ASTNode):
        if isinstance(stmt, IfStatement):
            self.compile_if(stmt)
        elif isinstance(stmt, WhileLoop):
            self.compile_while(stmt)
        elif isinstance(stmt, ObjectCreation):
            self.compile_object_creation(stmt)
        elif isinstance(stmt, MethodCall):
            self.compile_method_call(stmt)
        elif isinstance(stmt, FunctionCall):
            self.compile_function_call(stmt)
        elif isinstance(stmt, Assignment):
            self.compile_assignment(stmt)
        elif isinstance(stmt, ReturnStmt):
            self.compile_return(stmt)
    
    def compile_if(self, stmt: IfStatement):
        else_label = self.gen_label() if stmt.else_body else None
        end_label = self.gen_label()
        
        # Evaluate condition (pushes result to stack)
        self.compile_condition(stmt.condition)
        
        # Jump if false
        self.code.emit_opcode(OP_JMPIFNOT)
        if stmt.else_body:
            self.code.emit_jump_placeholder(else_label)
        else:
            self.code.emit_jump_placeholder(end_label)
        
        # Then body
        for s in stmt.then_body:
            self.compile_statement(s)
        
        if stmt.else_body:
            # Jump over else
            self.code.emit_opcode(OP_JMP)
            self.code.emit_jump_placeholder(end_label)
            
            # Else body
            self.code.place_label(else_label)
            for s in stmt.else_body:
                self.compile_statement(s)
        
        self.code.place_label(end_label)
    
    def compile_while(self, stmt: WhileLoop):
        start_label = self.gen_label()
        end_label = self.gen_label()
        
        # Loop start
        self.code.place_label(start_label)
        
        # Evaluate condition
        self.compile_condition(stmt.condition)
        
        # Jump if false (exit loop)
        self.code.emit_opcode(OP_JMPIFNOT)
        self.code.emit_jump_placeholder(end_label)
        
        # Loop body
        for s in stmt.body:
            self.compile_statement(s)
        
        # Jump back to start
        self.code.emit_opcode(OP_JMP)
        self.code.emit_jump_placeholder(start_label)
        
        self.code.place_label(end_label)
    
    def compile_condition(self, cond: Any):
        if isinstance(cond, NotExpr):
            self.compile_condition(cond.expr)
            self.code.emit_opcode(OP_NOT)
        
        elif isinstance(cond, BinaryOp):
            if cond.op == '&&':
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit_opcode(OP_JMPIFNOT_NP)
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit_opcode(OP_AND)
                self.code.place_label(skip_label)
            
            elif cond.op == '||':
                skip_label = self.gen_label()
                self.compile_condition(cond.left)
                self.code.emit_opcode(OP_JMPIF_NP)
                self.code.emit_jump_placeholder(skip_label)
                self.compile_condition(cond.right)
                self.code.emit_opcode(OP_OR)
                self.code.place_label(skip_label)
            
            elif cond.op in ['==', '!=', '<', '>', '<=', '>=']:
                self.compile_condition(cond.left)
                self.compile_condition(cond.right)
                if cond.op == '==':
                    self.code.emit_opcode(OP_CMPEQ)
                elif cond.op == '!=':
                    self.code.emit_opcode(OP_CMPNE)
                elif cond.op == '<':
                    self.code.emit_opcode(OP_CMPLT)
                elif cond.op == '>':
                    self.code.emit_opcode(OP_CMPGR)
                elif cond.op == '<=':
                    self.code.emit_opcode(OP_CMPLE)
                elif cond.op == '>=':
                    self.code.emit_opcode(OP_CMPGE)
        
        elif isinstance(cond, FunctionCall):
            # OP_PUSHFRAME (opcode)
            self.code.emit_opcode(OP_PUSHFRAME)
            
            # Push arguments
            for arg in cond.args:
                if isinstance(arg, VarRef):
                    var_offset = self.add_identifier(arg.name)
                    self.code.emit_opcode(OP_SETCURVAR)
                    self.ident_table.add(var_offset, self.code.get_code_index())
                    self.code.emit_data_u16(var_offset)
                    self.code.emit_opcode(OP_LOADVAR_STR)
                elif isinstance(arg, Literal):
                    arg_offset = self.add_value(arg.value)
                    self.code.emit_opcode(OP_LOADIMMED_STR)
                    self.code.emit_data_u16(arg_offset)
                self.code.emit_opcode(OP_PUSH)
            
            # Call function
            func_offset = self.add_identifier(cond.func)
            self.code.emit_opcode(OP_CALLFUNC)
            self.ident_table.add(func_offset, self.code.get_code_index())
            self.code.emit_data_u16(func_offset)
            self.code.emit_data_u16(0x0000)  # namespace
            self.code.emit_data_u8(CALL_FUNCTION)
            
            # Convert result to boolean
            self.code.emit_opcode(OP_STR_TO_UINT)
        
        elif isinstance(cond, VarRef):
            var_offset = self.add_identifier(cond.name)
            self.code.emit_opcode(OP_SETCURVAR)
            self.ident_table.add(var_offset, self.code.get_code_index())
            self.code.emit_data_u16(var_offset)
            self.code.emit_opcode(OP_LOADVAR_STR)
            self.code.emit_opcode(OP_STR_TO_UINT)
        
        elif isinstance(cond, Literal):
            lit_offset = self.add_value(cond.value)
            self.code.emit_opcode(OP_LOADIMMED_STR)
            self.code.emit_data_u16(lit_offset)
            self.code.emit_opcode(OP_STR_TO_UINT)
    
    def compile_object_creation(self, stmt: ObjectCreation):
        # OP_PUSHFRAME
        self.code.emit_opcode(OP_PUSHFRAME)
        
        # Push properties
        for prop_name, prop_value in stmt.properties.items():
            prop_offset = self.add_value(prop_name)
            self.code.emit_opcode(OP_LOADIMMED_IDENT)
            self.code.emit_data_u16(prop_offset)
            self.code.emit_opcode(OP_PUSH)
            
            val_offset = self.add_value(prop_value)
            self.code.emit_opcode(OP_LOADIMMED_STR)
            self.code.emit_data_u16(val_offset)
            self.code.emit_opcode(OP_PUSH)
        
        # OP_CREATE_OBJECT
        class_offset = self.add_identifier(stmt.class_name)
        self.code.emit_opcode(OP_CREATE_OBJECT)
        self.ident_table.add(class_offset, self.code.get_code_index())
        self.code.emit_data_u16(class_offset)
        self.code.emit_data_u8(0x00)  # isDataBlock
        self.code.emit_data_u8(0x01)  # isInternal
        
        # OP_ADD_OBJECT
        self.code.emit_opcode(OP_ADD_OBJECT)
        self.code.emit_data_u8(0x00)  # placeAtRoot
        
        # Save to variable
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit_opcode(OP_SETCURVAR_CREATE)
        self.ident_table.add(var_offset, self.code.get_code_index())
        self.code.emit_data_u16(var_offset)
        self.code.emit_opcode(OP_SAVEVAR_STR)
        
        # OP_END_OBJECT
        self.code.emit_opcode(OP_END_OBJECT)
        self.code.emit_data_u8(0x00)  # placeAtRoot
    
    def compile_method_call(self, stmt: MethodCall):
        # Set current object
        obj_name = stmt.obj[1:] if stmt.obj.startswith('%') else stmt.obj
        obj_offset = self.add_identifier(obj_name)
        self.code.emit_opcode(OP_SETCURVAR)
        self.ident_table.add(obj_offset, self.code.get_code_index())
        self.code.emit_data_u16(obj_offset)
        self.code.emit_opcode(OP_SETCUROBJECT)
        
        # OP_PUSHFRAME
        self.code.emit_opcode(OP_PUSHFRAME)
        
        # Push arguments
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit_opcode(OP_LOADIMMED_STR)
            self.code.emit_data_u16(arg_offset)
            self.code.emit_opcode(OP_PUSH)
        
        # Call method
        method_offset = self.add_identifier(stmt.method)
        self.code.emit_opcode(OP_CALLFUNC)
        self.ident_table.add(method_offset, self.code.get_code_index())
        self.code.emit_data_u16(method_offset)
        self.code.emit_data_u16(0x0000)  # namespace
        self.code.emit_data_u8(CALL_METHOD)
    
    def compile_function_call(self, stmt: FunctionCall):
        # OP_PUSHFRAME
        self.code.emit_opcode(OP_PUSHFRAME)
        
        # Push arguments
        for arg in stmt.args:
            arg_offset = self.add_value(str(arg))
            self.code.emit_opcode(OP_LOADIMMED_STR)
            self.code.emit_data_u16(arg_offset)
            self.code.emit_opcode(OP_PUSH)
        
        # Call function
        func_offset = self.add_identifier(stmt.func)
        self.code.emit_opcode(OP_CALLFUNC)
        self.ident_table.add(func_offset, self.code.get_code_index())
        self.code.emit_data_u16(func_offset)
        self.code.emit_data_u16(0x0000)  # namespace
        self.code.emit_data_u8(CALL_FUNCTION)
    
    def compile_assignment(self, stmt: Assignment):
        # Load value
        val_offset = self.add_value(str(stmt.value))
        self.code.emit_opcode(OP_LOADIMMED_STR)
        self.code.emit_data_u16(val_offset)
        
        # Save to variable
        var_name = stmt.var[1:] if stmt.var.startswith('%') else stmt.var
        var_offset = self.add_identifier(var_name)
        self.code.emit_opcode(OP_SETCURVAR_CREATE)
        self.ident_table.add(var_offset, self.code.get_code_index())
        self.code.emit_data_u16(var_offset)
        self.code.emit_opcode(OP_SAVEVAR_STR)
    
    def compile_return(self, stmt: ReturnStmt):
        if stmt.value:
            if isinstance(stmt.value, str) and stmt.value.startswith('%'):
                var_name = stmt.value[1:]
                var_offset = self.add_identifier(var_name)
                self.code.emit_opcode(OP_SETCURVAR)
                self.ident_table.add(var_offset, self.code.get_code_index())
                self.code.emit_data_u16(var_offset)
                self.code.emit_opcode(OP_LOADVAR_STR)
        self.code.emit_opcode(OP_RETURN)
    
    def write_cso(self, output_path: str):
        """Write CSO file"""
        # Patch jumps first
        self.code.patch_jumps()
        
        with open(output_path, 'wb') as f:
            # Version
            f.write(struct.pack('<I', 1))
            
            # Global strings
            global_str_bytes = self.global_strings.to_bytes()
            f.write(struct.pack('<I', len(global_str_bytes)))
            f.write(global_str_bytes)
            
            # Global floats (none)
            f.write(struct.pack('<I', 0))
            
            # Function strings
            func_str_bytes = self.func_strings.to_bytes()
            f.write(struct.pack('<I', len(func_str_bytes)))
            f.write(func_str_bytes)
            
            # Function floats (none)
            f.write(struct.pack('<I', 0))
            
            # Code section
            # CRITICAL: Write OPCODE count, not byte count!
            f.write(struct.pack('<I', self.code.code_count))
            f.write(self.code.to_bytes())
            
            # IdentTable
            f.write(self.ident_table.to_bytes())

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 cso_recompiler_v16_final.py input.cs output.cso")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r') as f:
        source = f.read()
    
    parser = Parser(source)
    functions = parser.parse()
    
    print(f"Parsed {len(functions)} functions")
    
    compiler = Compiler()
    for name, params, statements in functions:
        print(f"Compiling: {name}({', '.join(params)}) - {len(statements)} statements")
        compiler.compile_function(name, params, statements)
    
    compiler.write_cso(output_path)
    
    print(f"\n✅ Compiled to {output_path} (V16 - THE REAL FIX)")
    print(f"  Code count (opcodes): {compiler.code.code_count}")
    print(f"  Byte count: {len(compiler.code.bytes)}")
    print(f"  Ratio: {len(compiler.code.bytes) / compiler.code.code_count:.2f} bytes/opcode")
    print(f"  Global strings: {len(compiler.global_strings.strings)}")
    print(f"  Function strings: {len(compiler.func_strings.strings)}")
    print(f"  IdentTable entries: {len(compiler.ident_table.entries)}")

if __name__ == '__main__':
    main()
