# Critical Discovery - Broken Face Decompiler Analysis

## The Real Problem

After analyzing the Broken Face decompiler source code, I've discovered the EXACT requirements for CSO files:

### String Table Usage by Opcode

From `brokenface/core/codec.py`:

```python
# Line 317 - OP_FUNC_DECL
funcName = self.getGlobalString()  # Function name from GLOBAL table
# Line 321 - OP_FUNC_DECL namespace  
namespace = self.getGlobalStringByOffset(offset)  # GLOBAL table
# Line 325 - OP_FUNC_DECL package
package = self.getGlobalString()  # GLOBAL table
# Line 341 - OP_FUNC_DECL parameters
string = self.getGlobalStringByOffset(offset)  # GLOBAL table

# Line 373 - OP_CREATE_OBJECT parent
parent = self.getString()  # Context-sensitive (function table if in function)

# Line 1057 - OP_SETCURFIELD
self.curfield = self.getGlobalString()  # GLOBAL table

# Line 1331 - OP_LOADIMMED_IDENT
self.strStack.load(self.getGlobalString())  # GLOBAL table

# Line 1341 - OP_CALLFUNC funcName
funcName = self.getGlobalString()  # GLOBAL table!!!
# Line 1349 - OP_CALLFUNC namespace
namespace = self.getGlobalStringByOffset(offset)  # GLOBAL table
```

### The Rule

**GLOBAL String Table:**
- Function names (OP_FUNC_DECL)
- Function parameters (OP_FUNC_DECL)
- Called function names (OP_CALLFUNC)
- Method names (OP_CALLFUNC with call type)
- Property/field names (OP_LOADIMMED_IDENT, OP_SETCURFIELD)
- Namespaces

**FUNCTION String Table:**
- Local variable names
- String literals
- Object class names (OP_CREATE_OBJECT)
- Property VALUES (not names)

### Verified from Original Files

Checked `actionmaps_test.cso`:
- **50 strings in GLOBAL** - including:
  - Function names: "stxlagdgapl", "stxilbjjlhp", etc.
  - Property names: "Name", etc.
  - Variable names used in function declarations
  
- **184 strings in FUNCTION** - including:
  - Class names: "GlobalActionMap", "ActionMap"
  - Device names: "Joystick", "Keyboard0", "Mouse0"
  - Key names: "DPadDown", "Enter", "Button_0"
  - Object names (property values)

## Why Our Compiler Failed

### V8 & V9 Issues:
- Put ALL strings in FUNCTION table
- No GLOBAL strings except empty
- OP_CALLFUNC tried to read from GLOBAL → KeyError!

### V10 Issues:
- Put function names and params in GLOBAL ✅
- BUT put method names in FUNCTION ❌
- OP_CALLFUNC(method) tried to read from GLOBAL → KeyError!

## The Fix for V11

ALL identifiers (names of things) must be in GLOBAL:
- Function names
- Method names  
- Property names
- Variable names (at least those used as parameters)

Only VALUES go in FUNCTION:
- String literals
- Class names
- Object names
- Key/button names

## Implementation Strategy

```python
class Compiler:
    def __init__(self):
        self.global_strings = StringTable()   # Identifiers
        self.func_strings = StringTable()     # Values
    
    def add_identifier(self, name: str) -> int:
        """Add identifier to GLOBAL table"""
        return self.global_strings.add(name)
    
    def add_value(self, value: str) -> int:
        """Add value to FUNCTION table"""
        return self.func_strings.add(value)
```

### Examples:

```javascript
// Function declaration
function myFunc(%param) { ... }
// myFunc → GLOBAL
// param → GLOBAL

// Method call
%obj.bind("keyboard", "escape", "quit");
// bind → GLOBAL (it's a method NAME)
// obj → GLOBAL (it's a variable NAME)
// keyboard, escape, quit → FUNCTION (they're VALUES)

// Object creation
%map = new ActionMap(Name: "MyMap");
// map → GLOBAL (variable NAME)
// Name → GLOBAL (property NAME)
// ActionMap → FUNCTION (class name is a VALUE)
// MyMap → FUNCTION (object name is a VALUE)
```

## Next Steps

Create V11 with:
1. Function names → GLOBAL
2. Method names → GLOBAL
3. Parameter names → GLOBAL
4. Variable names → GLOBAL
5. Property names → GLOBAL
6. Everything else → FUNCTION

This should finally match what the decompiler expects!

---

## Why This Matters

The Broken Face decompiler is the ONLY tool that can verify our CSO files are correct. If it can successfully decompile our output, then our compiler is producing valid Scarface CSO files!

Once we get this working, we can:
1. Compile any TorqueScript
2. Test in-game
3. Verify round-trip (source → CSO → decompiled source)
4. Confidently mod Scarface!

---

*Status: Need to implement V11 with correct string table usage*
*Priority: HIGH - This is the final blocker!*
