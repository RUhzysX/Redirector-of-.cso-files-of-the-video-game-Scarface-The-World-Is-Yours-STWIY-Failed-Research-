#!/usr/bin/env python3
"""
CSO Recompiler V4 - FINAL VERSION
Combines V2's compilation with proper metadata handling

Usage: python3 cso_recompiler_v4.py input.cs output.cso [reference.cso]
  
  input.cs     - Source file to compile
  output.cso   - Output CSO file
  reference.cso - (Optional) Use metadata from this file
"""

import sys
import struct
import re
from typing import List, Dict, Optional

# Opcode definitions
OP_FUNC_DECL = 0
OP_CREATE_OBJECT = 1
OP_ADD_OBJECT = 4
OP_END_OBJECT = 5
OP_RETURN = 13
OP_SETCURVAR = 36
OP_SETCURVAR_CREATE = 37
OP_SETCUROBJECT = 50
OP_SETCUROBJECT_NEW = 51
OP_SETCURFIELD = 52
OP_LOADIMMED_STR = 71
OP_LOADIMMED_IDENT = 72
OP_CALLFUNC = 75
OP_PUSH = 84

# String entry types
STR_TYPE_GLOBAL = 0x01
STR_TYPE_FUNC = 0x00


def encode_string_entry(offset: int, entry_type: int = STR_TYPE_GLOBAL) -> int:
    """Encode string table offset as StringTableEntry"""
    if offset > 0xFFFFFF:
        raise ValueError(f"Offset {offset} too large")
    
    offset_bytes = struct.pack('>I', offset)[1:]  # 3 bytes, big-endian
    full_bytes = offset_bytes + bytes([entry_type])
    return struct.unpack('<I', full_bytes)[0]


def extract_metadata_from_reference(filepath):
    """Extract metadata from a reference CSO file"""
    with open(filepath, 'rb') as f:
        data = f.read()
    
    offset = 0
    offset += 4  # version
    
    global_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4 + global_str_size
    
    offset += 4  # marker
    
    func_str_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4 + func_str_size
    
    offset += 4  # code_size_field
    
    bytecode_size = struct.unpack_from('<I', data, offset)[0]
    offset += 4 + bytecode_size
    
    # Everything else is metadata
    return data[offset:]


class StringTable:
    def __init__(self, name: str = ""):
        self.name = name
        self.strings: List[str] = []
        self.offsets: Dict[str, int] = {}
    
    def add(self, string: str) -> int:
        if string in self.offsets:
            return self.offsets[string]
        
        offset = sum(len(s) + 1 for s in self.strings)
        self.strings.append(string)
        self.offsets[string] = offset
        return offset
    
    def to_bytes(self) -> bytes:
        return b''.join(s.encode('ascii', errors='replace') + b'\x00' 
                       for s in self.strings)


class BytecodeBuilder:
    def __init__(self, global_strings: StringTable, func_strings: StringTable):
        self.code: List[int] = []
        self.global_strings = global_strings
        self.func_strings = func_strings
    
    def emit(self, *values: int):
        self.code.extend(values)
    
    def emit_global_string_ref(self, string: str):
        offset = self.global_strings.add(string)
        encoded = encode_string_entry(offset, STR_TYPE_GLOBAL)
        self.emit(encoded)
    
    def emit_func_string_ref(self, string: str):
        offset = self.func_strings.add(string)
        encoded = encode_string_entry(offset, STR_TYPE_FUNC)
        self.emit(encoded)
    
    def get_ip(self) -> int:
        return len(self.code)
    
    def patch(self, index: int, value: int):
        if 0 <= index < len(self.code):
            self.code[index] = value
    
    def to_bytes(self) -> bytes:
        return b''.join(struct.pack('<I', val) for val in self.code)


class Parser:
    def __init__(self, source: str):
        self.source = source
        self.functions = []
    
    def parse(self):
        """Parse all functions - improved to handle ALL functions"""
        lines = self.source.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Find function declaration
            if line.startswith('function '):
                func_match = re.match(r'function\s+(\w+)\s*\(([^)]*)\)', line)
                if func_match:
                    func_name = func_match.group(1)
                    params = func_match.group(2).strip()
                    
                    # Find opening brace
                    if '{' not in line:
                        i += 1
                        while i < len(lines) and '{' not in lines[i]:
                            i += 1
                    
                    # Collect function body
                    brace_count = 0
                    body_lines = []
                    found_open = False
                    
                    while i < len(lines):
                        current = lines[i]
                        
                        # Count braces
                        for char in current:
                            if char == '{':
                                brace_count += 1
                                found_open = True
                            elif char == '}':
                                brace_count -= 1
                        
                        if found_open:
                            body_lines.append(current)
                        
                        if found_open and brace_count == 0:
                            break
                        
                        i += 1
                    
                    # Extract body (remove outer braces)
                    body = '\n'.join(body_lines)
                    # Remove the function signature and outer braces
                    body = re.sub(r'function\s+\w+\s*\([^)]*\)\s*\{', '', body, count=1)
                    body = body.rstrip().rstrip('}')
                    
                    self.functions.append((func_name, params, body))
            
            i += 1
        
        return self.functions


class CSOCompiler:
    def __init__(self):
        self.global_strings = StringTable("global")
        self.func_strings = StringTable("function")
        self.bytecode = None
    
    def compile_file(self, source: str, reference_metadata: Optional[bytes] = None) -> bytes:
        parser = Parser(source)
        functions = parser.parse()
        
        print(f"Parsed {len(functions)} functions:")
        for name, params, _ in functions:
            param_str = f"({params})" if params else "()"
            print(f"  - {name}{param_str}")
        
        self.bytecode = BytecodeBuilder(self.global_strings, self.func_strings)
        
        for func_name, params, func_body in functions:
            self.compile_function(func_name, params, func_body)
        
        return self.build_cso(reference_metadata)
    
    def compile_function(self, func_name: str, params: str, func_body: str):
        # OP_FUNC_DECL
        self.bytecode.emit(OP_FUNC_DECL)
        self.bytecode.emit_global_string_ref(func_name)
        self.bytecode.emit_global_string_ref("")  # namespace
        self.bytecode.emit_global_string_ref("")  # package
        self.bytecode.emit(1)  # has_body
        
        newip_index = self.bytecode.get_ip()
        self.bytecode.emit(0)  # newip (will patch)
        
        # argc - count parameters
        param_count = 0
        if params.strip():
            param_count = len([p.strip() for p in params.split(',') if p.strip()])
        self.bytecode.emit(param_count)
        
        # Emit parameter names
        if param_count > 0:
            for param in params.split(','):
                param = param.strip()
                if param:
                    self.bytecode.emit_global_string_ref(param)
        
        # Compile body
        self.compile_statements(func_body)
        
        # Return
        self.bytecode.emit(OP_RETURN)
        
        # Patch newip
        func_end_ip = self.bytecode.get_ip()
        self.bytecode.patch(newip_index, func_end_ip)
    
    def compile_statements(self, body: str):
        statements = [s.strip() for s in body.split(';') if s.strip()]
        
        for stmt in statements:
            self.compile_statement(stmt)
    
    def compile_statement(self, stmt: str):
        stmt = stmt.strip()
        
        if not stmt or stmt.startswith('//'):
            return
        
        # Return statement
        if stmt.startswith('return'):
            if '%' in stmt:
                var_name = stmt.split()[1].rstrip(';')
                self.bytecode.emit(OP_SETCURVAR)
                self.bytecode.emit_global_string_ref(var_name)
            self.bytecode.emit(OP_RETURN)
        
        # Object creation
        elif '=' in stmt and 'new ' in stmt:
            self.compile_object_creation(stmt)
        
        # Method call
        elif '.' in stmt and '(' in stmt:
            self.compile_method_call(stmt)
        
        # If statement - basic support
        elif stmt.startswith('if'):
            pass  # Skip for now
    
    def compile_object_creation(self, stmt: str):
        match = re.match(r'(%\w+)\s*=\s*new\s+(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        var_name = match.group(1)
        class_name = match.group(2)
        args_str = match.group(3)
        
        # CREATE_OBJECT
        self.bytecode.emit(OP_CREATE_OBJECT)
        self.bytecode.emit_global_string_ref(class_name)
        self.bytecode.emit(0, 0, 0, 0, 0)
        
        # Properties
        if args_str.strip():
            for prop_match in re.finditer(r'(\w+)\s*:\s*"([^"]*)"', args_str):
                prop_name = prop_match.group(1)
                prop_value = prop_match.group(2)
                
                self.bytecode.emit(OP_SETCURFIELD)
                self.bytecode.emit_global_string_ref(prop_name)
                self.bytecode.emit(OP_LOADIMMED_STR)
                self.bytecode.emit_func_string_ref(prop_value)
        
        self.bytecode.emit(OP_ADD_OBJECT)
        self.bytecode.emit(0)
        self.bytecode.emit(OP_END_OBJECT)
        self.bytecode.emit(0)
        self.bytecode.emit(OP_SETCUROBJECT_NEW)
        self.bytecode.emit(OP_SETCURVAR_CREATE)
        self.bytecode.emit_global_string_ref(var_name)
    
    def compile_method_call(self, stmt: str):
        match = re.match(r'(%\w+)\.(\w+)\s*\(([^)]*)\)', stmt)
        if not match:
            return
        
        obj_var = match.group(1)
        method_name = match.group(2)
        args_str = match.group(3)
        
        self.bytecode.emit(OP_SETCURVAR)
        self.bytecode.emit_global_string_ref(obj_var)
        self.bytecode.emit(OP_SETCUROBJECT)
        
        if args_str.strip():
            for arg in [a.strip() for a in args_str.split(',')]:
                self.compile_argument(arg)
                self.bytecode.emit(OP_PUSH)
        
        self.bytecode.emit(OP_CALLFUNC)
        self.bytecode.emit_global_string_ref(method_name)
        self.bytecode.emit_global_string_ref("")
        self.bytecode.emit(1)  # METHOD_CALL
    
    def compile_argument(self, arg: str):
        arg = arg.strip()
        
        if arg.startswith('"') and arg.endswith('"'):
            self.bytecode.emit(OP_LOADIMMED_STR)
            self.bytecode.emit_func_string_ref(arg[1:-1])
        elif arg.startswith('%'):
            self.bytecode.emit(OP_SETCURVAR)
            self.bytecode.emit_global_string_ref(arg)
        else:
            self.bytecode.emit(OP_LOADIMMED_IDENT)
            self.bytecode.emit_global_string_ref(arg)
    
    def build_cso(self, metadata: Optional[bytes] = None) -> bytes:
        output = bytearray()
        
        # Version
        output.extend(struct.pack('<I', 1))
        
        # Global strings
        global_strings_bytes = self.global_strings.to_bytes()
        output.extend(struct.pack('<I', len(global_strings_bytes)))
        output.extend(global_strings_bytes)
        
        # Function strings
        output.extend(struct.pack('<I', 0))
        function_strings_bytes = self.func_strings.to_bytes()
        output.extend(struct.pack('<I', len(function_strings_bytes)))
        output.extend(function_strings_bytes)
        
        # Code
        output.extend(struct.pack('<I', 0))
        bytecode_bytes = self.bytecode.to_bytes()
        output.extend(struct.pack('<I', len(bytecode_bytes)))
        output.extend(bytecode_bytes)
        
        # Metadata
        if metadata:
            print(f"Using reference metadata: {len(metadata)} bytes")
            output.extend(metadata)
        else:
            print("Warning: No metadata - file may not work properly")
            # Generate minimal stub metadata
            # Just zeros for now
            stub_size = 100
            output.extend(b'\x00' * stub_size)
        
        return bytes(output)


def main():
    if len(sys.argv) < 3:
        print("CSO Recompiler V4 - Final Version")
        print()
        print("Usage:")
        print("  python3 cso_recompiler_v4.py input.cs output.cso")
        print("  python3 cso_recompiler_v4.py input.cs output.cso reference.cso")
        print()
        print("Options:")
        print("  input.cs      - TorqueScript source file")
        print("  output.cso    - Output compiled CSO file")
        print("  reference.cso - (Optional) Copy metadata from this file")
        print()
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    reference_file = sys.argv[3] if len(sys.argv) > 3 else None
    
    print(f"Compiling {input_file}...")
    
    with open(input_file, 'r') as f:
        source = f.read()
    
    # Extract metadata from reference if provided
    metadata = None
    if reference_file:
        print(f"Loading metadata from {reference_file}...")
        metadata = extract_metadata_from_reference(reference_file)
    
    compiler = CSOCompiler()
    cso_data = compiler.compile_file(source, metadata)
    
    with open(output_file, 'wb') as f:
        f.write(cso_data)
    
    print(f"\nCompilation complete!")
    print(f"Output: {output_file} ({len(cso_data)} bytes)")
    print(f"Global strings: {len(compiler.global_strings.strings)}")
    print(f"Function strings: {len(compiler.func_strings.strings)}")
    print(f"Bytecode: {len(compiler.bytecode.code)} instructions")


if __name__ == "__main__":
    main()
