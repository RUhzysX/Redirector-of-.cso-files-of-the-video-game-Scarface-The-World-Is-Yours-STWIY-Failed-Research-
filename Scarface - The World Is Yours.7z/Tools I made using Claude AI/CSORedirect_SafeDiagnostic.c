/* CSORedirect_SafeDiagnostic.c
 * Super safe diagnostic with error handling
 */

#include <windows.h>
#include <stdio.h>

#define LOG_FILE "CSORedirect_SAFE.log"

static FILE* g_log = NULL;

void SafeLog(const char* format, ...)
{
    va_list args;
    
    if (!g_log)
    {
        g_log = fopen(LOG_FILE, "w");
        if (!g_log) return;
    }
    
    va_start(args, format);
    vfprintf(g_log, format, args);
    va_end(args);
    
    /* FORCE flush after EVERY write */
    fflush(g_log);
    fclose(g_log);
    g_log = fopen(LOG_FILE, "a");
}

void SafeDumpImports(void)
{
    HMODULE hModule;
    PIMAGE_DOS_HEADER pDosHeader;
    PIMAGE_NT_HEADERS pNTHeaders;
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc;
    int dllCount = 0;
    
    SafeLog("=== STARTING IMPORT SCAN ===\n\n");
    
    hModule = GetModuleHandle(NULL);
    if (!hModule)
    {
        SafeLog("ERROR: GetModuleHandle failed!\n");
        return;
    }
    SafeLog("Module handle: 0x%p\n", hModule);
    
    pDosHeader = (PIMAGE_DOS_HEADER)hModule;
    if (pDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
    {
        SafeLog("ERROR: Invalid DOS signature!\n");
        return;
    }
    SafeLog("DOS header OK\n");
    
    pNTHeaders = (PIMAGE_NT_HEADERS)((BYTE*)hModule + pDosHeader->e_lfanew);
    if (pNTHeaders->Signature != IMAGE_NT_SIGNATURE)
    {
        SafeLog("ERROR: Invalid NT signature!\n");
        return;
    }
    SafeLog("NT headers OK\n");
    
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    if (!pImportDesc)
    {
        SafeLog("ERROR: No import directory!\n");
        return;
    }
    SafeLog("Import directory: 0x%p\n\n", pImportDesc);
    
    SafeLog("=== IMPORTED DLLs ===\n\n");
    
    /* Count DLLs first */
    for (; pImportDesc->Name; pImportDesc++)
    {
        dllCount++;
    }
    SafeLog("Total DLLs: %d\n\n", dllCount);
    
    /* Reset pointer */
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    /* Now scan each DLL */
    for (; pImportDesc->Name; pImportDesc++)
    {
        const char* dllName;
        int funcCount = 0;
        PIMAGE_THUNK_DATA pThunk;
        PIMAGE_THUNK_DATA pOrigThunk;
        
        __try
        {
            dllName = (const char*)((BYTE*)hModule + pImportDesc->Name);
            SafeLog("DLL: %s\n", dllName);
            
            pThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
            pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
            
            /* Count functions */
            for (; pOrigThunk->u1.Function; pThunk++, pOrigThunk++)
            {
                funcCount++;
            }
            SafeLog("  Functions: %d\n", funcCount);
            
            /* Reset */
            pThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
            pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
            
            /* List functions - but CAREFULLY */
            for (; pOrigThunk->u1.Function; pThunk++, pOrigThunk++)
            {
                __try
                {
                    if (pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)
                    {
                        SafeLog("    [ORD:%d]\n", pOrigThunk->u1.Ordinal & 0xFFFF);
                    }
                    else
                    {
                        PIMAGE_IMPORT_BY_NAME pImport = (PIMAGE_IMPORT_BY_NAME)((BYTE*)hModule + pOrigThunk->u1.AddressOfData);
                        SafeLog("    %s\n", pImport->Name);
                    }
                }
                __except(EXCEPTION_EXECUTE_HANDLER)
                {
                    SafeLog("    [ERROR reading function name]\n");
                }
            }
            
            SafeLog("\n");
        }
        __except(EXCEPTION_EXECUTE_HANDLER)
        {
            SafeLog("  [ERROR scanning this DLL]\n\n");
        }
    }
    
    SafeLog("=== SCAN COMPLETE ===\n\n");
    
    /* Now specifically look for file functions */
    SafeLog("=== CHECKING FOR FILE FUNCTIONS ===\n\n");
    
    pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)((BYTE*)hModule +
        pNTHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
    
    for (; pImportDesc->Name; pImportDesc++)
    {
        const char* dllName = (const char*)((BYTE*)hModule + pImportDesc->Name);
        
        if (_stricmp(dllName, "kernel32.dll") == 0)
        {
            PIMAGE_THUNK_DATA pThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->FirstThunk);
            PIMAGE_THUNK_DATA pOrigThunk = (PIMAGE_THUNK_DATA)((BYTE*)hModule + pImportDesc->OriginalFirstThunk);
            
            SafeLog("Checking kernel32.dll for file functions:\n");
            
            for (; pOrigThunk->u1.Function; pThunk++, pOrigThunk++)
            {
                if (!(pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG))
                {
                    PIMAGE_IMPORT_BY_NAME pImport = (PIMAGE_IMPORT_BY_NAME)((BYTE*)hModule + pOrigThunk->u1.AddressOfData);
                    const char* funcName = (const char*)pImport->Name;
                    
                    /* Check if it's a file function */
                    if (strstr(funcName, "File") || 
                        strstr(funcName, "Read") || 
                        strstr(funcName, "Write") ||
                        strstr(funcName, "Find"))
                    {
                        SafeLog("  FOUND: %s\n", funcName);
                    }
                }
            }
            
            SafeLog("\n");
            break;
        }
    }
    
    SafeLog("=== ANALYSIS COMPLETE ===\n");
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    if (fdwReason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hinstDLL);
        
        SafeLog("=== SAFE DIAGNOSTIC v2.0 ===\n\n");
        
        __try
        {
            SafeDumpImports();
        }
        __except(EXCEPTION_EXECUTE_HANDLER)
        {
            SafeLog("\nFATAL ERROR during scan!\n");
        }
        
        if (g_log)
        {
            fclose(g_log);
            g_log = NULL;
        }
        
        MessageBoxA(NULL,
            "Diagnostic complete!\n\n"
            "Check CSORedirect_SAFE.log for results.",
            "Safe Diagnostic Done", 
            MB_OK);
    }
    
    return TRUE;
}

/*
COMPILE:
gcc -shared -O2 -o CSORedirect_Safe.asi CSORedirect_SafeDiagnostic.c -lkernel32

This version:
- Flushes after EVERY write
- Uses exception handling
- Won't crash even if memory is bad
- Counts things before listing them
*/
